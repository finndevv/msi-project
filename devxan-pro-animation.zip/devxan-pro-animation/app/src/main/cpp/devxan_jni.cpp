#include <jni.h>
#include <android/native_window_jni.h>
#include <android/asset_manager_jni.h>
#include <android/log.h>

#include "gl/Renderer.h"
#include "gl/Shader.h"
#include "gl/Mesh.h"
#include "gl/PathTessellator.h"
#include "audio/AudioMixer.h"
#include "audio/AudioDecoder.h"

#include <memory>
#include <vector>
#include <cstring>

#define LOG_TAG "DevxanJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using namespace devxan;

namespace {
    std::unique_ptr<gl::Renderer> g_renderer;
    std::unique_ptr<audio::AudioMixer> g_audioMixer;
    std::vector<std::unique_ptr<gl::Mesh>> g_meshPool;
    std::vector<std::unique_ptr<gl::Shader>> g_shaderCache;
}

// ─────────────────────────────────────────────────────────────────────────────
// Renderer lifecycle
// ─────────────────────────────────────────────────────────────────────────────

extern "C" JNIEXPORT jlong JNICALL
Java_com_devxan_proanimation_engine_render_NativeRenderer_nativeCreate(
        JNIEnv* env, jclass, jobject surface, jint width, jint height) {
    ANativeWindow* window = ANativeWindow_fromSurface(env, surface);
    if (!window) {
        LOGE("ANativeWindow_fromSurface returned null");
        return 0;
    }
    g_renderer = std::make_unique<gl::Renderer>();
    if (!g_renderer->init(window, width, height)) {
        LOGE("Renderer init failed");
        g_renderer.reset();
        return 0;
    }
    return reinterpret_cast<jlong>(g_renderer.get());
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_render_NativeRenderer_nativeDestroy(
        JNIEnv*, jclass, jlong handle) {
    g_renderer.reset();
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_render_NativeRenderer_nativeResize(
        JNIEnv*, jclass, jlong handle, jint width, jint height) {
    if (g_renderer) g_renderer->requestViewport(width, height);
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_render_NativeRenderer_nativeSetPostFx(
        JNIEnv*, jclass, jlong handle,
        jfloat brightness, jfloat contrast, jfloat hue, jfloat saturation) {
    if (g_renderer) g_renderer->setPostFx(brightness, contrast, hue, saturation);
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_render_NativeRenderer_nativeRenderFrame(
        JNIEnv* env, jclass, jlong handle) {
    if (!g_renderer) return;
    g_renderer->renderFrame();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_devxan_proanimation_engine_render_NativeRenderer_nativeFps(
        JNIEnv*, jclass, jlong handle) {
    if (!g_renderer) return 0;
    return g_renderer->fps();
}

// ─────────────────────────────────────────────────────────────────────────────
// Mesh pool management
// ─────────────────────────────────────────────────────────────────────────────

extern "C" JNIEXPORT jint JNICALL
Java_com_devxan_proanimation_engine_render_NativeRenderer_nativeCreateMesh(
        JNIEnv*, jclass, jlong handle) {
    g_meshPool.push_back(std::make_unique<gl::Mesh>());
    return static_cast<jint>(g_meshPool.size() - 1);
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_render_NativeRenderer_nativeMeshClear(
        JNIEnv*, jclass, jlong handle, jint meshId) {
    if (meshId >= 0 && meshId < (jint)g_meshPool.size() && g_meshPool[meshId])
        g_meshPool[meshId]->clear();
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_render_NativeRenderer_nativeMeshAddRect(
        JNIEnv* env, jclass, jlong handle, jint meshId,
        jfloat x0, jfloat y0, jfloat x1, jfloat y1,
        jfloat r, jfloat g, jfloat b, jfloat a) {
    if (meshId < 0 || meshId >= (jint)g_meshPool.size() || !g_meshPool[meshId]) return;
    g_meshPool[meshId]->addRect(x0, y0, x1, y1, r, g, b, a);
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_render_NativeRenderer_nativeMeshAddEllipse(
        JNIEnv* env, jclass, jlong handle, jint meshId,
        jfloat cx, jfloat cy, jfloat rx, jfloat ry, jint segments,
        jfloat r, jfloat g, jfloat b, jfloat a) {
    if (meshId < 0 || meshId >= (jint)g_meshPool.size() || !g_meshPool[meshId]) return;
    g_meshPool[meshId]->addEllipse(cx, cy, rx, ry, segments, r, g, b, a);
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_render_NativeRenderer_nativeMeshUpload(
        JNIEnv*, jclass, jlong handle, jint meshId, jboolean dynamic) {
    if (meshId < 0 || meshId >= (jint)g_meshPool.size() || !g_meshPool[meshId]) return;
    g_meshPool[meshId]->upload(dynamic);
}

// ─────────────────────────────────────────────────────────────────────────────
// Audio mixer bridge
// ─────────────────────────────────────────────────────────────────────────────

extern "C" JNIEXPORT jlong JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativeCreate(
        JNIEnv*, jclass) {
    g_audioMixer = std::make_unique<audio::AudioMixer>();
    return reinterpret_cast<jlong>(g_audioMixer.get());
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativeStart(
        JNIEnv*, jclass, jlong handle, jint sampleRate, jint channels) {
    if (!g_audioMixer) return JNI_FALSE;
    return g_audioMixer->start(sampleRate, channels) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativeStop(
        JNIEnv*, jclass, jlong handle) {
    if (g_audioMixer) g_audioMixer->stop();
}

extern "C" JNIEXPORT jint JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativeAddTrack(
        JNIEnv* env, jclass, jlong handle,
        jfloatArray pcmArr, jint channels, jint sampleRate,
        jlong startFrame, jfloat volume, jboolean loop) {
    if (!g_audioMixer) return -1;
    jsize len = env->GetArrayLength(pcmArr);
    std::vector<float> pcm(len);
    env->GetFloatArrayRegion(pcmArr, 0, len, pcm.data());
    return g_audioMixer->addTrack(std::move(pcm), channels, sampleRate,
                                  startFrame, volume, loop == JNI_TRUE);
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativeRemoveTrack(
        JNIEnv*, jclass, jlong handle, jint trackId) {
    if (g_audioMixer) g_audioMixer->removeTrack(trackId);
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativeSetTrackVolume(
        JNIEnv*, jclass, jlong handle, jint trackId, jfloat volume) {
    if (g_audioMixer) g_audioMixer->setTrackVolume(trackId, volume);
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativeSetMasterVolume(
        JNIEnv*, jclass, jlong handle, jfloat volume) {
    if (g_audioMixer) g_audioMixer->setMasterVolume(volume);
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativePlay(
        JNIEnv*, jclass, jlong handle) {
    if (g_audioMixer) g_audioMixer->play();
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativePause(
        JNIEnv*, jclass, jlong handle) {
    if (g_audioMixer) g_audioMixer->pause();
}

extern "C" JNIEXPORT void JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativeSeek(
        JNIEnv*, jclass, jlong handle, jlong frame) {
    if (g_audioMixer) g_audioMixer->seekTo(frame);
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativeCurrentFrame(
        JNIEnv*, jclass, jlong handle) {
    if (!g_audioMixer) return 0;
    return g_audioMixer->currentFrame();
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativeRms(
        JNIEnv*, jclass, jlong handle) {
    if (!g_audioMixer) return 0.0f;
    return g_audioMixer->currentRmsLoudness();
}

// ─────────────────────────────────────────────────────────────────────────────
// FFT / lip-sync analyzer
// ─────────────────────────────────────────────────────────────────────────────

extern "C" JNIEXPORT jint JNICALL
Java_com_devxan_proanimation_engine_audio_NativeAudioEngine_nativeClassifyPhoneme(
        JNIEnv* env, jclass, jlong handle, jfloatArray samplesArr, jint sampleRate) {
    jsize len = env->GetArrayLength(samplesArr);
    std::vector<float> mono(len);
    env->GetFloatArrayRegion(samplesArr, 0, len, mono.data());
    auto mag = audio::AudioDecoder::fftMagnitude(mono, 1024);
    return static_cast<jint>(audio::AudioDecoder::classifyPhoneme(mag, sampleRate));
}
