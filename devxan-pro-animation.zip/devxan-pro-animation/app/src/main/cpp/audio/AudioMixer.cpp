#include "AudioMixer.h"
#include <android/log.h>
#include <cmath>
#include <algorithm>

#define LOG_TAG "DevxanAudio"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

namespace devxan::audio {

AudioMixer::AudioMixer() = default;
AudioMixer::~AudioMixer() { stop(); }

bool AudioMixer::start(int32_t sampleRate, int32_t channels) {
    oboe::AudioStreamBuilder builder;
    builder.setPerformanceMode(oboe::PerformanceMode::LowLatency)
            .setSharingMode(oboe::SharingMode::Exclusive)
            .setFormat(oboe::AudioFormat::Float)
            .setChannelCount(channels)
            .setSampleRate(sampleRate)
            .setDataCallback(this)
            .setErrorCallback(this);

    oboe::Result result = builder.openStream(stream_);
    if (result != oboe::Result::OK) {
        LOGE("Failed to open audio stream: %s", oboe::convertToText(result));
        return false;
    }
    LOGI("Audio stream opened: %d Hz, %d ch, %s",
         stream_->getSampleRate(),
         stream_->getChannelCount(),
         oboe::convertToText(stream_->getFormat()));

    oboe::Result startResult = stream_->requestStart();
    if (startResult != oboe::Result::OK) {
        LOGE("Failed to start stream: %s", oboe::convertToText(startResult));
        return false;
    }
    return true;
}

void AudioMixer::stop() {
    if (stream_) {
        stream_->stop();
        stream_->close();
        stream_.reset();
    }
}

int32_t AudioMixer::addTrack(std::vector<float> pcm, int32_t channels, int32_t sampleRate,
                             int64_t startFrame, float volume, bool loop) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto t = std::make_unique<AudioTrack>();
    t->samples = std::move(pcm);
    t->channels = channels;
    t->sampleRate = sampleRate;
    t->startFrame = startFrame;
    t->volume = volume;
    t->loop = loop;
    int32_t id = static_cast<int32_t>(tracks_.size());
    tracks_.push_back(std::move(t));
    LOGI("Added track id=%d (%.1fs, %dch @ %dHz)", id,
         (double)t->samples.size() / std::max(1, t->channels * t->sampleRate),
         t->channels, t->sampleRate);
    return id;
}

void AudioMixer::removeTrack(int32_t trackId) {
    std::lock_guard<std::mutex> lk(mutex_);
    if (trackId >= 0 && trackId < (int32_t)tracks_.size()) {
        tracks_[trackId].reset();
    }
}

void AudioMixer::setTrackVolume(int32_t trackId, float volume) {
    std::lock_guard<std::mutex> lk(mutex_);
    if (trackId >= 0 && trackId < (int32_t)tracks_.size() && tracks_[trackId]) {
        tracks_[trackId]->volume = volume;
    }
}

void AudioMixer::setTrackMute(int32_t trackId, bool muted) {
    std::lock_guard<std::mutex> lk(mutex_);
    if (trackId >= 0 && trackId < (int32_t)tracks_.size() && tracks_[trackId]) {
        tracks_[trackId]->muted = muted;
    }
}

void AudioMixer::setMasterVolume(float v) { masterVolume_ = v; }

void AudioMixer::seekTo(int64_t frame) {
    currentFrame_.store(frame, std::memory_order_relaxed);
    std::lock_guard<std::mutex> lk(mutex_);
    for (auto& t : tracks_) {
        if (t) {
            int64_t trackFrame = frame - t->startFrame;
            if (trackFrame < 0) trackFrame = 0;
            t->playCursor = trackFrame * t->channels;
        }
    }
}

void AudioMixer::play() { playing_.store(true,  std::memory_order_relaxed); }
void AudioMixer::pause(){ playing_.store(false, std::memory_order_relaxed); }

oboe::DataCallbackResult AudioMixer::onAudioReady(oboe::AudioStream* stream,
                                                  void* audioData,
                                                  int32_t numFrames) {
    auto* out = static_cast<float*>(audioData);
    int32_t outChannels = stream->getChannelCount();
    bool playing = playing_.load(std::memory_order_relaxed);
    int64_t curFrame = currentFrame_.load(std::memory_order_relaxed);

    // Zero output buffer
    std::memset(out, 0, numFrames * outChannels * sizeof(float));

    float sumRms = 0;
    int rmsCount = 0;

    {
        std::lock_guard<std::mutex> lk(mutex_);
        for (auto& t : tracks_) {
            if (!t || t->muted) continue;
            int64_t trackStartFrame = t->startFrame;
            int64_t endFrame = curFrame + numFrames;

            for (int32_t i = 0; i < numFrames; ++i) {
                int64_t absFrame = curFrame + i;
                int64_t relFrame = absFrame - trackStartFrame;
                if (relFrame < 0) continue;
                if (!playing) break;

                // Resample to output rate (nearest for simplicity in low-latency path)
                int64_t srcFrame = relFrame * t->sampleRate / stream->getSampleRate();
                if (srcFrame * t->channels + (t->channels - 1) >= (int64_t)t->samples.size()) {
                    if (t->loop) {
                        srcFrame %= std::max<int64_t>(1LL, (int64_t)t->samples.size() / t->channels);
                    } else {
                        continue;
                    }
                }
                int64_t idx = srcFrame * t->channels;
                float vL = t->samples[idx] * t->volume;
                float vR = (t->channels > 1) ? t->samples[idx + 1] * t->volume : vL;

                out[i * outChannels]     += vL;
                if (outChannels > 1) {
                    out[i * outChannels + 1] += vR;
                }

                sumRms += (vL * vL + vR * vR);
                rmsCount += 2;
            }
        }
    }

    if (playing) {
        currentFrame_.fetch_add(numFrames, std::memory_order_relaxed);
    }

    // Apply master volume + soft clip limiter
    for (int32_t i = 0; i < numFrames * outChannels; ++i) {
        float s = out[i] * masterVolume_;
        // Soft clip
        out[i] = std::tanh(s);
    }

    if (rmsCount > 0) {
        rmsLoudness_.store(std::sqrt(sumRms / rmsCount), std::memory_order_relaxed);
    }

    return oboe::DataCallbackResult::Continue;
}

void AudioMixer::onErrorAfterClose(oboe::AudioStream* stream, oboe::Result error) {
    LOGE("Audio stream error: %s", oboe::convertToText(error));
}

} // namespace devxan::audio
