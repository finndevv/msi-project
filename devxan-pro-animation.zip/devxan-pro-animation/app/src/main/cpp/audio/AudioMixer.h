#pragma once

#include <oboe/Oboe.h>
#include <android/asset_manager.h>
#include <memory>
#include <vector>
#include <mutex>
#include <atomic>
#include <cstdint>
#include <string>

namespace devxan::audio {

/**
 * A simple ring buffer of PCM float samples for one audio track.
 * Multiple tracks are mixed by summing sample-by-sample at output time.
 */
struct AudioTrack {
    std::vector<float> samples; // interleaved stereo L,R,L,R,...
    int32_t channels   = 2;
    int32_t sampleRate = 48000;
    int64_t startFrame  = 0;     // offset from project start, in frames at sampleRate
    float   volume      = 1.0f;
    bool    loop        = false;
    bool    muted       = false;
    int64_t playCursor  = 0;     // current position in this track (samples, not frames)
};

/**
 * Real-time audio mixer driven by Oboe. Output format: stereo float @ 48 kHz.
 *
 * Each AudioTrack holds a decoded PCM float buffer. Mixing is straightforward
 * accumulate at the playhead; we apply a soft limiter on the master bus to
 * avoid clipping distortion when many tracks sum simultaneously.
 */
class AudioMixer : public oboe::AudioStreamCallback {
public:
    AudioMixer();
    ~AudioMixer();

    bool start(int32_t sampleRate = 48000, int32_t channels = 2);
    void stop();

    int32_t addTrack(std::vector<float> pcm, int32_t channels, int32_t sampleRate,
                     int64_t startFrame, float volume, bool loop);
    void removeTrack(int32_t trackId);
    void setTrackVolume(int32_t trackId, float volume);
    void setTrackMute(int32_t trackId, bool muted);
    void setMasterVolume(float v);
    void seekTo(int64_t frame);

    /** Called from playback loop to drive transport position. */
    void play(); void pause();
    bool isPlaying() const { return playing_.load(std::memory_order_relaxed); }
    int64_t currentFrame() const { return currentFrame_.load(std::memory_order_relaxed); }
    int32_t fps() const { return fps_; }
    void setFps(int32_t fps) { fps_ = fps; }

    // oboe::AudioStreamCallback
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream* stream,
                                          void* audioData,
                                          int32_t numFrames) override;
    void onErrorAfterClose(oboe::AudioStream* stream, oboe::Result error) override;

    /** Compute the loudness (RMS) of a 1024-sample FFT window for lip-sync. */
    float currentRmsLoudness() const { return rmsLoudness_.load(std::memory_order_relaxed); }

private:
    std::shared_ptr<oboe::AudioStream> stream_;
    std::vector<std::unique_ptr<AudioTrack>> tracks_;
    mutable std::mutex mutex_;
    std::atomic<bool>   playing_{false};
    std::atomic<int64_t> currentFrame_{0};
    std::atomic<float>  rmsLoudness_{0.0f};
    int32_t fps_ = 24;
    float   masterVolume_ = 1.0f;
};

} // namespace devxan::audio
