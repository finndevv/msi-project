#include "AudioDecoder.h"
#include <android/log.h>
#include <cmath>
#include <algorithm>

#define LOG_TAG "DevxanAudioDecoder"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

namespace devxan::audio {

// Note: file decoding itself is done by Kotlin's MediaExtractor/MediaCodec
// (see AudioEngine.kt). The C++ side is only responsible for analysis.

std::unique_ptr<DecodedAudio> AudioDecoder::decodeFile(const std::string& absolutePath) {
    // Stub for C++ side; real decoding happens via Kotlin MediaCodec pipeline.
    LOGE("decodeFile must be called via Kotlin MediaCodec bridge, not C++. Path=%s",
         absolutePath.c_str());
    return nullptr;
}

std::unique_ptr<DecodedAudio> AudioDecoder::decodeRange(const std::string& path,
                                                       int64_t startFrame,
                                                       int64_t endFrame) {
    (void)path; (void)startFrame; (void)endFrame;
    return nullptr;
}

// Iterative radix-2 Cooley-Tukey FFT. Requires N to be a power of two.
static void fft(std::vector<std::complex<float>>& a) {
    size_t N = a.size();
    // Bit-reversal permutation
    for (size_t i = 1, j = 0; i < N; ++i) {
        size_t bit = N >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
    for (size_t len = 2; len <= N; len <<= 1) {
        float ang = -2.0f * 3.14159265358979323846f / float(len);
        std::complex<float> wlen(std::cos(ang), std::sin(ang));
        for (size_t i = 0; i < N; i += len) {
            std::complex<float> w(1, 0);
            for (size_t j = 0; j < len / 2; ++j) {
                auto u = a[i + j];
                auto v = a[i + j + len / 2] * w;
                a[i + j]           = u + v;
                a[i + j + len / 2] = u - v;
                w *= wlen;
            }
        }
    }
}

std::vector<float> AudioDecoder::fftMagnitude(const std::vector<float>& mono, size_t N) {
    // Pad N up to next power of two
    size_t pow2 = 1;
    while (pow2 < N) pow2 <<= 1;
    N = pow2;

    std::vector<std::complex<float>> buf(N, {0, 0});
    for (size_t i = 0; i < std::min(N, mono.size()); ++i) {
        // Hann window
        float w = 0.5f * (1.0f - std::cos(2.0f * 3.14159265358979f * float(i) / float(N - 1)));
        buf[i] = std::complex<float>(mono[i] * w, 0.0f);
    }

    fft(buf);

    std::vector<float> mag(N / 2 + 1);
    for (size_t i = 0; i <= N / 2; ++i) {
        mag[i] = std::abs(buf[i]) / float(N);
    }
    return mag;
}

AudioDecoder::Phoneme AudioDecoder::classifyPhoneme(const std::vector<float>& mag, int sampleRate) {
    if (mag.empty()) return Phoneme::Rest;

    // Compute band energy
    float lowFreq = 500.0f;   // vowels concentrated here
    float midFreq = 2000.0f;  // voiced consonants
    float hiFreq  = 6000.0f; // sibilants

    size_t binLow = (size_t)(lowFreq * mag.size() * 2 / sampleRate);
    size_t binMid = (size_t)(midFreq * mag.size() * 2 / sampleRate);
    size_t binHi  = (size_t)(hiFreq  * mag.size() * 2 / sampleRate);

    float eLow = 0, eMid = 0, eHi = 0;
    for (size_t i = 0; i < binLow && i < mag.size(); ++i) eLow += mag[i] * mag[i];
    for (size_t i = binLow; i < binMid && i < mag.size(); ++i) eMid += mag[i] * mag[i];
    for (size_t i = binMid; i < binHi  && i < mag.size(); ++i) eHi  += mag[i] * mag[i];

    float total = eLow + eMid + eHi + 1e-9f;
    float pLow = eLow / total;
    float pMid = eMid / total;
    float pHi  = eHi  / total;

    // Very low overall energy => silence
    if (std::sqrt(total) < 0.01f) return Phoneme::Rest;

    if (pHi > 0.4f) {
        if (pHi > 0.55f) return Phoneme::S_TH;   // strong sibilance
        return Phoneme::F_V;
    }
    if (pMid > 0.3f) {
        if (pLow < 0.4f) return Phoneme::K_G;   // bursty mid energy
        return Phoneme::L_N_D_T;
    }
    if (pLow > 0.85f && eLow < 0.05f) return Phoneme::M_B_P; // very muffled
    if (pLow > 0.6f) {
        // Vowel-like; differentiate W_OO from A_E_I_O_U by low-frequency flatness
        return Phoneme::A_E_I_O_U;
    }
    return Phoneme::W_OO;
}

} // namespace devxan::audio
