#pragma once

#include <string>
#include <vector>
#include <cstdint>
#include <memory>

namespace devxan::audio {

/**
 * Audio decoder interface for OPUS/MP3/AAC. On Android we use MediaExtractor
 * + MediaCodec from the Kotlin side; this interface is exposed so the C++
 * mixer can request a freshly-decoded PCM buffer of a given file URI.
 *
 * The JNI layer uses callbacks back into Kotlin for MediaCodec-based decoding.
 */
struct DecodedAudio {
    std::vector<float> pcm;        // interleaved stereo float, normalized [-1,1]
    int32_t channels     = 2;
    int32_t sampleRate   = 48000;
    int64_t totalFrames  = 0;
    std::string codec    = "unknown";
};

class AudioDecoder {
public:
    /** Decode an entire file to float PCM. Returns null on failure. */
    static std::unique_ptr<DecodedAudio> decodeFile(const std::string& absolutePath);

    /**
     * Decode a frame range (startFrame..endFrame) - used for streaming when
     * the source file is too large to fit in memory.
     */
    static std::unique_ptr<DecodedAudio> decodeRange(const std::string& path,
                                                    int64_t startFrame,
                                                    int64_t endFrame);

    /**
     * Run a 1024-point FFT (radix-2 Cooley-Tukey) on a window of samples.
     * Returns the magnitude spectrum of length N/2+1.
     */
    static std::vector<float> fftMagnitude(const std::vector<float>& mono, size_t N = 1024);

    /** Detect phonemes from FFT magnitudes - simplified lip-sync analyzer. */
    enum class Phoneme {
        Rest, A_E_I_O_U, M_B_P, F_V, S_TH, L_N_D_T, K_G, W_OO
    };
    static Phoneme classifyPhoneme(const std::vector<float>& magnitudes, int sampleRate);
};

} // namespace devxan::audio
