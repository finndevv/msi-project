#include "Shader.h"

#include <android/log.h>
#include <vector>

#define LOG_TAG "DevxanShader"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

namespace devxan::gl {

Shader::Shader(const std::string& vertexSource, const std::string& fragmentSource) {
    GLuint vs = compileStage(GL_VERTEX_SHADER, vertexSource);
    if (vs == 0) return;
    GLuint fs = compileStage(GL_FRAGMENT_SHADER, fragmentSource);
    if (fs == 0) {
        glDeleteShader(vs);
        return;
    }
    program_ = linkProgram(vs, fs);
    glDeleteShader(vs);
    glDeleteShader(fs);
    if (program_ != 0) {
        LOGI("Linked shader program %u", program_);
    }
}

Shader::~Shader() { release(); }

Shader::Shader(Shader&& other) noexcept : program_(other.program_) {
    other.program_ = 0;
}

Shader& Shader::operator=(Shader&& other) noexcept {
    if (this != &other) {
        release();
        program_ = other.program_;
        other.program_ = 0;
    }
    return *this;
}

void Shader::release() {
    if (program_ != 0) {
        glDeleteProgram(program_);
        program_ = 0;
    }
}

void Shader::use() const {
    if (program_ != 0) glUseProgram(program_);
}

GLint Shader::attribute(const char* name) const {
    return glGetAttribLocation(program_, name);
}

GLint Shader::uniform(const char* name) const {
    return glGetUniformLocation(program_, name);
}

void Shader::setMat4(const char* name, const float* v) const {
    GLint loc = uniform(name);
    if (loc >= 0) glUniformMatrix4fv(loc, 1, GL_FALSE, v);
}

void Shader::setMat3(const char* name, const float* v) const {
    GLint loc = uniform(name);
    if (loc >= 0) glUniformMatrix3fv(loc, 1, GL_FALSE, v);
}

void Shader::setVec4(const char* name, float x, float y, float z, float w) const {
    GLint loc = uniform(name);
    if (loc >= 0) glUniform4f(loc, x, y, z, w);
}

void Shader::setVec3(const char* name, float x, float y, float z) const {
    GLint loc = uniform(name);
    if (loc >= 0) glUniform3f(loc, x, y, z);
}

void Shader::setVec2(const char* name, float x, float y) const {
    GLint loc = uniform(name);
    if (loc >= 0) glUniform2f(loc, x, y);
}

void Shader::setFloat(const char* name, float v) const {
    GLint loc = uniform(name);
    if (loc >= 0) glUniform1f(loc, v);
}

void Shader::setInt(const char* name, int v) const {
    GLint loc = uniform(name);
    if (loc >= 0) glUniform1i(loc, v);
}

GLuint Shader::compileStage(GLenum type, const std::string& src) {
    GLuint shader = glCreateShader(type);
    const char* srcPtr = src.c_str();
    GLint length = static_cast<GLint>(src.size());
    glShaderSource(shader, 1, &srcPtr, &length);
    glCompileShader(shader);

    GLint success = GL_FALSE;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (success != GL_TRUE) {
        GLint logLen = 0;
        glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &logLen);
        std::vector<char> logBuf(logLen + 1, 0);
        glGetShaderInfoLog(shader, logLen, nullptr, logBuf.data());
        LOGE("Shader compile failed: %s", logBuf.data());
        LOGE("Source:\n%s", src.c_str());
        glDeleteShader(shader);
        return 0;
    }
    return shader;
}

GLuint Shader::linkProgram(GLuint vs, GLuint fs) {
    GLuint prog = glCreateProgram();
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glBindAttribLocation(prog, 0, "aPosition");
    glBindAttribLocation(prog, 1, "aColor");
    glBindAttribLocation(prog, 2, "aTexCoord");
    glBindAttribLocation(prog, 3, "aNormal");
    glLinkProgram(prog);

    GLint success = GL_FALSE;
    glGetProgramiv(prog, GL_LINK_STATUS, &success);
    if (success != GL_TRUE) {
        GLint logLen = 0;
        glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &logLen);
        std::vector<char> logBuf(logLen + 1, 0);
        glGetProgramInfoLog(prog, logLen, nullptr, logBuf.data());
        LOGE("Program link failed: %s", logBuf.data());
        glDeleteProgram(prog);
        return 0;
    }
    return prog;
}

// ─────────────────────────────────────────────────────────────────────────────
// Shader source code (GLSL ES 3.00)
// ─────────────────────────────────────────────────────────────────────────────

namespace sources {

const char* kSolidColorVS = R"GLSL(#version 300 es
layout(location = 0) in vec2 aPosition;
uniform mat4 uMVP;
void main() {
    gl_Position = uMVP * vec4(aPosition, 0.0, 1.0);
}
)GLSL";

const char* kSolidColorFS = R"GLSL(#version 300 es
precision highp float;
uniform vec4 uColor;
out vec4 fragColor;
void main() {
    fragColor = uColor;
}
)GLSL";

const char* kGradientLinearVS = R"GLSL(#version 300 es
layout(location = 0) in vec2 aPosition;
layout(location = 2) in vec2 aTexCoord;
uniform mat4 uMVP;
out vec2 vLocal;
void main() {
    vLocal = aPosition;
    gl_Position = uMVP * vec4(aPosition, 0.0, 1.0);
}
)GLSL";

const char* kGradientLinearFS = R"GLSL(#version 300 es
precision highp float;
in vec2 vLocal;
uniform vec2  uStart;
uniform vec2  uEnd;
uniform vec4  uColor0;
uniform vec4  uColor1;
uniform float uAlpha;
out vec4 fragColor;
void main() {
    vec2 d = uEnd - uStart;
    float len2 = max(dot(d, d), 1e-7);
    float t = clamp(dot(vLocal - uStart, d) / len2, 0.0, 1.0);
    fragColor = vec4(mix(uColor0.rgb, uColor1.rgb, t), uAlpha * mix(uColor0.a, uColor1.a, t));
}
)GLSL";

const char* kGradientRadialVS = R"GLSL(#version 300 es
layout(location = 0) in vec2 aPosition;
uniform mat4 uMVP;
out vec2 vLocal;
void main() {
    vLocal = aPosition;
    gl_Position = uMVP * vec4(aPosition, 0.0, 1.0);
}
)GLSL";

const char* kGradientRadialFS = R"GLSL(#version 300 es
precision highp float;
in vec2 vLocal;
uniform vec2  uCenter;
uniform float uRadius;
uniform vec4  uColor0;
uniform vec4  uColor1;
uniform float uAlpha;
out vec4 fragColor;
void main() {
    float d = distance(vLocal, uCenter);
    float t = clamp(d / max(uRadius, 1e-3), 0.0, 1.0);
    fragColor = vec4(mix(uColor0.rgb, uColor1.rgb, t), uAlpha * mix(uColor0.a, uColor1.a, t));
}
)GLSL";

const char* kTexturedVS = R"GLSL(#version 300 es
layout(location = 0) in vec2 aPosition;
layout(location = 2) in vec2 aTexCoord;
uniform mat4 uMVP;
out vec2 vTexCoord;
void main() {
    vTexCoord = aTexCoord;
    gl_Position = uMVP * vec4(aPosition, 0.0, 1.0);
}
)GLSL";

const char* kTexturedFS = R"GLSL(#version 300 es
precision highp float;
in vec2 vTexCoord;
uniform sampler2D uTexture;
uniform float uAlpha;
out vec4 fragColor;
void main() {
    vec4 c = texture(uTexture, vTexCoord);
    fragColor = vec4(c.rgb, c.a * uAlpha);
}
)GLSL";

const char* kPostProcessVS = R"GLSL(#version 300 es
layout(location = 0) in vec2 aPosition;
layout(location = 2) in vec2 aTexCoord;
out vec2 vTexCoord;
void main() {
    vTexCoord = aTexCoord;
    gl_Position = vec4(aPosition, 0.0, 1.0);
}
)GLSL";

const char* kPostProcessFS = R"GLSL(#version 300 es
precision highp float;
in vec2 vTexCoord;
uniform sampler2D uScene;
uniform float uBrightness;
uniform float uContrast;
uniform float uSaturation;
uniform float uHueShift;
out vec4 fragColor;

vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

vec3 hsv2rgb(vec3 c) {
    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}

void main() {
    vec4 col = texture(uScene, vTexCoord);
    vec3 c = col.rgb;
    c *= uBrightness;
    c = (c - 0.5) * uContrast + 0.5;
    vec3 hsv = rgb2hsv(c);
    hsv.x = fract(hsv.x + uHueShift);
    hsv.y *= uSaturation;
    c = hsv2rgb(hsv);
    fragColor = vec4(c, col.a);
}
)GLSL";

} // namespace sources

} // namespace devxan::gl
