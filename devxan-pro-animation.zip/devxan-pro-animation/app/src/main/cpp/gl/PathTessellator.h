#pragma once

#include "Mesh.h"
#include <vector>

namespace devxan::gl {

/**
 * CPU-side tessellation of Bezier paths into triangle meshes with
 * miter/round/bevel joins, dashed strokes, and filled triangle fans.
 *
 * Used by the renderer's CPU prepass before uploading Mesh data.
 */
struct PathSegment {
    enum Type : int {
        MoveTo  = 0,
        LineTo  = 1,
        QuadTo  = 2,
        CubicTo = 3,
        Close   = 4,
    } type = MoveTo;

    // Control points (only the relevant ones used per type)
    float x1 = 0, y1 = 0;
    float x2 = 0, y2 = 0;
    float x3 = 0, y3 = 0;
};

enum class Join : int { Miter = 0, Round = 1, Bevel = 2 };
enum class Cap   : int { Butt  = 0, Round = 1, Square = 2 };

struct PathStyle {
    float   strokeWidth   = 4.0f;
    Join    lineJoin      = Join::Miter;
    Cap     lineCap       = Cap::Round;
    bool    dashed        = false;
    float   dashLength    = 10.0f;
    float   dashGap       = 6.0f;
    bool    hasFill       = true;
    float   fillColor[4]  = {1, 1, 1, 1};
    bool    hasStroke     = true;
    float   strokeColor[4] = {0, 0, 0, 1};
};

class PathTessellator {
public:
    static void tessellate(Mesh& mesh,
                           const std::vector<PathSegment>& path,
                           const PathStyle& style);

private:
    static void flatten(const std::vector<PathSegment>& path,
                        std::vector<std::pair<float, float>>& outPoints,
                        std::vector<int>& outContours,
                        float tol = 0.5f);

    static void fillFan(Mesh& mesh,
                        const std::vector<std::pair<float, float>>& pts,
                        const std::vector<int>& contours,
                        const float color[4]);

    static void strokeOutline(Mesh& mesh,
                              const std::vector<std::pair<float, float>>& pts,
                              const std::vector<int>& contours,
                              const PathStyle& style);
};

} // namespace devxan::gl
