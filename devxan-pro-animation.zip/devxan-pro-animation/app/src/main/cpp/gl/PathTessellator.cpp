#include "PathTessellator.h"

#include <cmath>
#include <algorithm>

namespace devxan::gl {

namespace {

inline float dist2(float ax, float ay, float bx, float by) {
    float dx = bx - ax, dy = by - ay;
    return dx * dx + dy * dy;
}

void quadBezier(const std::vector<std::pair<float, float>>& p,
                std::vector<std::pair<float, float>>& out, float tol) {
    // p[0]=start, p[1]=control, p[2]=end. Adaptive subdivision.
    auto& p0 = p[0];
    auto& p1 = p[1];
    auto& p2 = p[2];
    // Flatness test
    float ux = 2.0f * p1.first  - p0.first  - p2.first;
    float uy = 2.0f * p1.second - p0.second - p2.second;
    if (ux * ux + uy * uy <= tol * tol * 16.0f) {
        out.emplace_back(p2.first, p2.second);
        return;
    }
    // Subdivide via de Casteljau
    float m01x = (p0.first  + p1.first)  * 0.5f;
    float m01y = (p0.second + p1.second) * 0.5f;
    float m12x = (p1.first  + p2.first)  * 0.5f;
    float m12y = (p1.second + p2.second) * 0.5f;
    float mx   = (m01x + m12x) * 0.5f;
    float my   = (m01y + m12y) * 0.5f;
    std::vector<std::pair<float, float>> left  = {p0, {m01x, m01y}, {mx, my}};
    std::vector<std::pair<float, float>> right = {{mx, my}, {m12x, m12y}, p2};
    quadBezier(left,  out, tol);
    quadBezier(right, out, tol);
}

void cubicBezier(const std::vector<std::pair<float, float>>& p,
                 std::vector<std::pair<float, float>>& out, float tol) {
    auto& p0 = p[0]; auto& p1 = p[1]; auto& p2 = p[2]; auto& p3 = p[3];
    float ux = 3.0f * (p1.first  - p0.first)  - 3.0f * (p2.first  - p1.first)  + (p3.first  - p2.first);
    float uy = 3.0f * (p1.second - p0.second) - 3.0f * (p2.second - p1.second) + (p3.second - p2.second);
    if (ux * ux + uy * uy <= tol * tol * 16.0f) {
        out.emplace_back(p3.first, p3.second);
        return;
    }
    float m01x = (p0.first  + p1.first)  * 0.5f;
    float m01y = (p0.second + p1.second) * 0.5f;
    float m12x = (p1.first  + p2.first)  * 0.5f;
    float m12y = (p1.second + p2.second) * 0.5f;
    float m23x = (p2.first  + p3.first)  * 0.5f;
    float m23y = (p2.second + p3.second) * 0.5f;
    float m012x = (m01x + m12x) * 0.5f;
    float m012y = (m01y + m12y) * 0.5f;
    float m123x = (m12x + m23x) * 0.5f;
    float m123y = (m12y + m23y) * 0.5f;
    float mx = (m012x + m123x) * 0.5f;
    float my = (m012y + m123y) * 0.5f;
    std::vector<std::pair<float, float>> left  = {p0, {m01x, m01y}, {m012x, m012y}, {mx, my}};
    std::vector<std::pair<float, float>> right = {{mx, my}, {m123x, m123y}, {m23x, m23y}, p3};
    cubicBezier(left,  out, tol);
    cubicBezier(right, out, tol);
}

void strokeSegment(Mesh& mesh, float x0, float y0, float x1, float y1,
                   float halfW, const float color[4]) {
    float dx = x1 - x0, dy = y1 - y0;
    float len = std::sqrt(dx * dx + dy * dy);
    if (len < 1e-6f) return;
    float nx = -dy / len * halfW;
    float ny =  dx / len * halfW;

    uint32_t base = static_cast<uint32_t>(mesh.vertices().size());
    mesh.addVertex(x0 + nx, y0 + ny, color[0], color[1], color[2], color[3]);
    mesh.addVertex(x1 + nx, y1 + ny, color[0], color[1], color[2], color[3]);
    mesh.addVertex(x1 - nx, y1 - ny, color[0], color[1], color[2], color[3]);
    mesh.addVertex(x0 - nx, y0 - ny, color[0], color[1], color[2], color[3]);
    mesh.addTriangle(base + 0, base + 1, base + 2);
    mesh.addTriangle(base + 0, base + 2, base + 3);
}

void strokeRoundJoin(Mesh& mesh, float cx, float cy,
                     float dxIn, float dyIn, float dxOut, float dyOut,
                     float halfW, const float color[4], int segments = 6) {
    float lenIn  = std::sqrt(dxIn * dxIn + dyIn * dyIn);
    float lenOut = std::sqrt(dxOut * dxOut + dyOut * dyOut);
    if (lenIn < 1e-6f || lenOut < 1e-6f) return;

    float nxIn  = -dyIn  / lenIn  * halfW;
    float nyIn  =  dxIn  / lenIn  * halfW;
    float nxOut = -dyOut / lenOut * halfW;
    float nyOut =  dxOut / lenOut * halfW;

    // Determine turn direction (cross product sign)
    float cross = dxIn * dyOut - dyIn * dxOut;
    bool ccw = cross > 0;
    if (!ccw) { std::swap(nxIn, nyIn); std::swap(nxOut, nyOut); }

    float ang0 = std::atan2(nyIn, nxIn);
    float ang1 = std::atan2(nyOut, nxOut);
    if (ccw && ang1 < ang0) ang1 += 2.0f * 3.14159265358979f;
    if (!ccw && ang1 > ang0) ang1 -= 2.0f * 3.14159265358979f;

    uint32_t centerIdx = mesh.addVertex(cx, cy, color[0], color[1], color[2], color[3]);
    std::vector<uint32_t> ring;
    ring.push_back(centerIdx);
    for (int i = 0; i <= segments; ++i) {
        float t = float(i) / float(segments);
        float ang = ang0 + (ang1 - ang0) * t;
        float x = cx + std::cos(ang) * halfW;
        float y = cy + std::sin(ang) * halfW;
        ring.push_back(mesh.addVertex(x, y, color[0], color[1], color[2], color[3]));
    }
    mesh.addTriangleFan(ring);
}

} // namespace

void PathTessellator::tessellate(Mesh& mesh,
                                 const std::vector<PathSegment>& path,
                                 const PathStyle& style) {
    std::vector<std::pair<float, float>> pts;
    std::vector<int> contours;
    float tol = 0.5f;

    flatten(path, pts, contours, tol);
    if (pts.empty()) return;

    if (style.hasFill) fillFan(mesh, pts, contours, style.fillColor);
    if (style.hasStroke) strokeOutline(mesh, pts, contours, style);
}

void PathTessellator::flatten(const std::vector<PathSegment>& path,
                              std::vector<std::pair<float, float>>& out,
                              std::vector<int>& outContours,
                              float tol) {
    bool started = false;
    for (auto& seg : path) {
        switch (seg.type) {
            case PathSegment::MoveTo:
                if (started) outContours.push_back(static_cast<int>(out.size()));
                out.emplace_back(seg.x1, seg.y1);
                started = true;
                break;
            case PathSegment::LineTo:
                out.emplace_back(seg.x1, seg.y1);
                break;
            case PathSegment::QuadTo: {
                std::vector<std::pair<float, float>> ctrl = {
                        out.empty() ? std::make_pair(seg.x1, seg.y1) : out.back(),
                        {seg.x1, seg.y1},
                        {seg.x2, seg.y2}
                };
                quadBezier(ctrl, out, tol);
                break;
            }
            case PathSegment::CubicTo: {
                std::vector<std::pair<float, float>> ctrl = {
                        out.empty() ? std::make_pair(seg.x1, seg.y1) : out.back(),
                        {seg.x1, seg.y1},
                        {seg.x2, seg.y2},
                        {seg.x3, seg.y3}
                };
                cubicBezier(ctrl, out, tol);
                break;
            }
            case PathSegment::Close:
                outContours.push_back(static_cast<int>(out.size()));
                started = false;
                break;
        }
    }
    if (started) outContours.push_back(static_cast<int>(out.size()));
}

void PathTessellator::fillFan(Mesh& mesh,
                              const std::vector<std::pair<float, float>>& pts,
                              const std::vector<int>& contours,
                              const float color[4]) {
    size_t start = 0;
    for (int endIdx : contours) {
        int end = endIdx;
        int count = end - static_cast<int>(start);
        if (count < 3) { start = end; continue; }

        // Centroid
        float cx = 0, cy = 0;
        for (size_t i = start; i < static_cast<size_t>(end); ++i) {
            cx += pts[i].first;
            cy += pts[i].second;
        }
        cx /= count; cy /= count;
        uint32_t centerIdx = mesh.addVertex(cx, cy, color[0], color[1], color[2], color[3]);
        std::vector<uint32_t> ring;
        ring.push_back(centerIdx);
        for (size_t i = start; i < static_cast<size_t>(end); ++i) {
            ring.push_back(mesh.addVertex(pts[i].first, pts[i].second,
                                          color[0], color[1], color[2], color[3]));
        }
        // Close the ring
        ring.push_back(mesh.addVertex(pts[start].first, pts[start].second,
                                       color[0], color[1], color[2], color[3]));
        mesh.addTriangleFan(ring);
        start = end;
    }
}

void PathTessellator::strokeOutline(Mesh& mesh,
                                    const std::vector<std::pair<float, float>>& pts,
                                    const std::vector<int>& contours,
                                    const PathStyle& style) {
    float hw = style.strokeWidth * 0.5f;
    size_t start = 0;
    for (int endIdx : contours) {
        int end = endIdx;
        int count = end - static_cast<int>(start);
        if (count < 2) { start = end; continue; }

        for (int i = 0; i < count - 1; ++i) {
            auto& a = pts[start + i];
            auto& b = pts[start + i + 1];
            strokeSegment(mesh, a.first, a.second, b.first, b.second, hw, style.strokeColor);
            if (style.lineJoin == Join::Round && i + 2 < count) {
                auto& c = pts[start + i + 2];
                strokeRoundJoin(mesh, b.first, b.second,
                                b.first - a.first, b.second - a.second,
                                c.first - b.first, c.second - b.second,
                                hw, style.strokeColor, 6);
            }
        }
        start = end;
    }
}

} // namespace devxan::gl
