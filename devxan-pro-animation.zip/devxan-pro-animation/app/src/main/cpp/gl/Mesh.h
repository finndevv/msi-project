#pragma once

#include <GLES3/gl3.h>
#include <vector>
#include <cstdint>

namespace devxan::gl {

/**
 * Vertex layout (interleaved, 8 floats / 32 bytes per vertex):
 *   vec2 aPosition
 *   vec4 aColor (per-vertex tint when vertex coloring is enabled)
 *   vec2 aTexCoord
 */
struct Vertex {
    float x, y;
    float r, g, b, a;
    float u, v;
};

static_assert(sizeof(Vertex) == 32, "Vertex must be 32 bytes (8 floats)");

/**
 * Mesh holds a CPU-side vertex / index buffer that can be uploaded to the GPU
 * as either a static VAO or a streaming dynamic VBO. Drawn via glDrawElements.
 */
class Mesh {
public:
    Mesh();
    ~Mesh();

    Mesh(const Mesh&) = delete;
    Mesh& operator=(const Mesh&) = delete;

    /** Resets the mesh to an empty vertex/index buffer. */
    void clear();

    void reserve(size_t vertexCount, size_t indexCount);

    /** Adds a vertex, returns its index for use by addTriangle / addLine. */
    uint32_t addVertex(float x, float y,
                       float r = 1.0f, float g = 1.0f, float b = 1.0f, float a = 1.0f,
                       float u = 0.0f, float v = 0.0f);

    void addTriangle(uint32_t a, uint32_t b, uint32_t c);
    void addLine(uint32_t a, uint32_t b);

    /** Triangulated triangle fan for a closed polygon ring. */
    void addTriangleFan(const std::vector<uint32_t>& ring);

    /** Builds a triangle strip rectangle (4 verts, 6 indices). Returns base index. */
    uint32_t addRect(float x0, float y0, float x1, float y1,
                     float r, float g, float b, float a);

    /** Builds an axis-aligned ellipse. Returns base index. */
    uint32_t addEllipse(float cx, float cy, float rx, float ry,
                        int segments, float r, float g, float b, float a);

    void upload(bool dynamic = false);
    void draw(GLenum mode = GL_TRIANGLES) const;

    size_t vertexCount() const { return vertices_.size(); }
    size_t indexCount() const { return indices_.size(); }

    const std::vector<Vertex>& vertices() const { return vertices_; }
    const std::vector<uint32_t>& indices() const { return indices_; }

private:
    std::vector<Vertex>   vertices_;
    std::vector<uint32_t> indices_;
    GLuint vao_ = 0;
    GLuint vbo_ = 0;
    GLuint ibo_ = 0;
    bool   uploaded_ = false;
};

} // namespace devxan::gl
