#pragma once

#include <GLES3/gl3.h>
#include <string>

namespace devxan::gl {

/**
 * Compiles, links, and caches GLSL ES 3.00 shader programs.
 * Vertex + Fragment programs are loaded from raw string literals; the cache
 * is keyed on the (vertexSource, fragmentSource) pair so that multiple
 * draw paths can re-use the same compiled program.
 */
class Shader {
public:
    Shader() = default;
    Shader(const std::string& vertexSource, const std::string& fragmentSource);
    ~Shader();

    Shader(const Shader&) = delete;
    Shader& operator=(const Shader&) = delete;
    Shader(Shader&& other) noexcept;
    Shader& operator=(Shader&& other) noexcept;

    bool isValid() const { return program_ != 0; }
    GLuint program() const { return program_; }

    void use() const;

    GLint attribute(const char* name) const;
    GLint uniform(const char* name) const;

    void setMat4(const char* name, const float* value) const;
    void setMat3(const char* name, const float* value) const;
    void setVec4(const char* name, float x, float y, float z, float w) const;
    void setVec3(const char* name, float x, float y, float z) const;
    void setVec2(const char* name, float x, float y) const;
    void setFloat(const char* name, float v) const;
    void setInt(const char* name, int v) const;

private:
    GLuint program_ = 0;
    void release();
    static GLuint compileStage(GLenum type, const std::string& src);
    static GLuint linkProgram(GLuint vs, GLuint fs);
};

// Built-in shader sources used by the renderer pipeline.
namespace sources {

extern const char* kSolidColorVS;
extern const char* kSolidColorFS;

extern const char* kGradientLinearVS;
extern const char* kGradientLinearFS;

extern const char* kGradientRadialVS;
extern const char* kGradientRadialFS;

extern const char* kTexturedVS;
extern const char* kTexturedFS;

extern const char* kPostProcessVS;
extern const char* kPostProcessFS;

} // namespace sources

} // namespace devxan::gl
