#include "Mesh.h"

#include <android/log.h>

#define LOG_TAG "DevxanMesh"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace devxan::gl {

Mesh::Mesh() {
    glGenVertexArrays(1, &vao_);
    glGenBuffers(1, &vbo_);
    glGenBuffers(1, &ibo_);
}

Mesh::~Mesh() {
    if (vao_) glDeleteVertexArrays(1, &vao_);
    if (vbo_) glDeleteBuffers(1, &vbo_);
    if (ibo_) glDeleteBuffers(1, &ibo_);
}

void Mesh::clear() {
    vertices_.clear();
    indices_.clear();
    uploaded_ = false;
}

void Mesh::reserve(size_t vCount, size_t iCount) {
    vertices_.reserve(vCount);
    indices_.reserve(iCount);
}

uint32_t Mesh::addVertex(float x, float y, float r, float g, float b, float a, float u, float v) {
    Vertex vtx{x, y, r, g, b, a, u, v};
    uint32_t idx = static_cast<uint32_t>(vertices_.size());
    vertices_.push_back(vtx);
    uploaded_ = false;
    return idx;
}

void Mesh::addTriangle(uint32_t a, uint32_t b, uint32_t c) {
    indices_.push_back(a);
    indices_.push_back(b);
    indices_.push_back(c);
    uploaded_ = false;
}

void Mesh::addLine(uint32_t a, uint32_t b) {
    indices_.push_back(a);
    indices_.push_back(b);
    uploaded_ = false;
}

void Mesh::addTriangleFan(const std::vector<uint32_t>& ring) {
    if (ring.size() < 3) return;
    uint32_t center = ring[0];
    for (size_t i = 1; i + 1 < ring.size(); ++i) {
        indices_.push_back(center);
        indices_.push_back(ring[i]);
        indices_.push_back(ring[i + 1]);
    }
    // Close the fan
    indices_.push_back(center);
    indices_.push_back(ring.back());
    indices_.push_back(ring[1]);
    uploaded_ = false;
}

uint32_t Mesh::addRect(float x0, float y0, float x1, float y1, float r, float g, float b, float a) {
    uint32_t base = static_cast<uint32_t>(vertices_.size());
    addVertex(x0, y0, r, g, b, a, 0.0f, 0.0f);
    addVertex(x1, y0, r, g, b, a, 1.0f, 0.0f);
    addVertex(x1, y1, r, g, b, a, 1.0f, 1.0f);
    addVertex(x0, y1, r, g, b, a, 0.0f, 1.0f);
    indices_.push_back(base + 0);
    indices_.push_back(base + 1);
    indices_.push_back(base + 2);
    indices_.push_back(base + 0);
    indices_.push_back(base + 2);
    indices_.push_back(base + 3);
    uploaded_ = false;
    return base;
}

uint32_t Mesh::addEllipse(float cx, float cy, float rx, float ry,
                          int segments, float r, float g, float b, float a) {
    if (segments < 6) segments = 6;
    uint32_t base = static_cast<uint32_t>(vertices_.size());
    // Center vertex
    uint32_t centerIdx = addVertex(cx, cy, r, g, b, a, 0.5f, 0.5f);

    for (int i = 0; i <= segments; ++i) {
        float ang = 2.0f * 3.14159265358979323846f * float(i) / float(segments);
        float x = cx + rx * cosf(ang);
        float y = cy + ry * sinf(ang);
        float u = 0.5f + 0.5f * cosf(ang);
        float v = 0.5f + 0.5f * sinf(ang);
        addVertex(x, y, r, g, b, a, u, v);
    }

    // Triangle fan
    for (int i = 0; i < segments; ++i) {
        indices_.push_back(centerIdx);
        indices_.push_back(base + 1 + i);
        indices_.push_back(base + 1 + i + 1);
    }
    uploaded_ = false;
    return base;
}

void Mesh::upload(bool dynamic) {
    if (vertices_.empty()) return;
    GLenum usage = dynamic ? GL_DYNAMIC_DRAW : GL_STATIC_DRAW;

    glBindVertexArray(vao_);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER,
                 vertices_.size() * sizeof(Vertex),
                 vertices_.data(),
                 usage);

    if (!indices_.empty()) {
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo_);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                     indices_.size() * sizeof(uint32_t),
                     indices_.data(),
                     usage);
    }

    glEnableVertexAttribArray(0); // aPosition
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex),
                          reinterpret_cast<void*>(offsetof(Vertex, x)));
    glEnableVertexAttribArray(1); // aColor
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex),
                          reinterpret_cast<void*>(offsetof(Vertex, r)));
    glEnableVertexAttribArray(2); // aTexCoord
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex),
                          reinterpret_cast<void*>(offsetof(Vertex, u)));

    glBindVertexArray(0);
    uploaded_ = true;
}

void Mesh::draw(GLenum mode) const {
    if (!uploaded_) return;
    if (indices_.empty()) return;
    glBindVertexArray(vao_);
    glDrawElements(mode,
                   static_cast<GLsizei>(indices_.size()),
                   GL_UNSIGNED_INT,
                   nullptr);
    glBindVertexArray(0);
}

} // namespace devxan::gl
