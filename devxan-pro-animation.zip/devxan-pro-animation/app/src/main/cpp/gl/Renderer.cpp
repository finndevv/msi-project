#include "Renderer.h"
#include "PathTessellator.h"
#include <android/log.h>
#include <cstring>
#include <chrono>

#define LOG_TAG "DevxanRenderer"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

namespace devxan::gl {

Renderer::Renderer() = default;
Renderer::~Renderer() { deinit(); }

static const EGLint kConfigAttribs[] = {
        EGL_RED_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_BLUE_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 0,
        EGL_STENCIL_SIZE, 8,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_SAMPLE_BUFFERS, 1,
        EGL_SAMPLES, 4,
        EGL_NONE
};

static const EGLint kContextAttribs[] = {
        EGL_CONTEXT_CLIENT_VERSION, 3,
        EGL_NONE
};

static const EGLint kSurfaceAttribs[] = {
        EGL_RENDER_BUFFER, EGL_BACK_BUFFER,
        EGL_NONE
};

bool Renderer::init(ANativeWindow* window, int32_t width, int32_t height) {
    window_ = window;
    width_  = width;
    height_ = height;

    display_ = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display_ == EGL_NO_DISPLAY) {
        LOGE("eglGetDisplay failed");
        return false;
    }
    EGLint major = 0, minor = 0;
    if (!eglInitialize(display_, &major, &minor)) {
        LOGE("eglInitialize failed: 0x%x", eglGetError());
        return false;
    }
    LOGI("EGL %d.%d initialized", major, minor);

    EGLint numConfigs = 0;
    EGLConfig cfg = nullptr;
    if (!eglChooseConfig(display_, kConfigAttribs, &cfg, 1, &numConfigs) || numConfigs < 1) {
        LOGE("eglChooseConfig failed: 0x%x", eglGetError());
        return false;
    }
    config_ = cfg;

    EGLint format = 0;
    eglGetConfigAttrib(display_, config_, EGL_NATIVE_VISUAL_ID, &format);
    if (window_) ANativeWindow_setBuffersGeometry(window_, width_, height_, format);

    surface_ = eglCreateWindowSurface(display_, config_, window_, kSurfaceAttribs);
    if (surface_ == EGL_NO_SURFACE) {
        LOGE("eglCreateWindowSurface failed: 0x%x", eglGetError());
        return false;
    }

    context_ = eglCreateContext(display_, config_, EGL_NO_CONTEXT, kContextAttribs);
    if (context_ == EGL_NO_CONTEXT) {
        LOGE("eglCreateContext failed: 0x%x", eglGetError());
        return false;
    }

    if (!eglMakeCurrent(display_, surface_, surface_, context_)) {
        LOGE("eglMakeCurrent failed: 0x%x", eglGetError());
        return false;
    }

    eglSwapInterval(display_, 0); // uncapped; we throttle in Kotlin

    ensureShaders();
    ensureFbo();

    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    LOGI("Renderer initialized %dx%d", width_, height_);
    return true;
}

void Renderer::deinit() {
    std::lock_guard<std::mutex> lk(mutex_);
    shuttingDown_ = true;
    cv_.notify_all();

    releaseFbo();
    solidShader_.reset();
    linearGradientShader_.reset();
    radialGradientShader_.reset();
    texturedShader_.reset();
    postShader_.reset();
    fullscreenQuad_.reset();

    if (display_ != EGL_NO_DISPLAY) {
        eglMakeCurrent(display_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (surface_ != EGL_NO_SURFACE) eglDestroySurface(display_, surface_);
        if (context_ != EGL_NO_CONTEXT)  eglDestroyContext(display_, context_);
        eglTerminate(display_);
    }
    display_ = EGL_NO_DISPLAY;
    surface_ = EGL_NO_SURFACE;
    context_ = EGL_NO_CONTEXT;
    if (window_) {
        ANativeWindow_release(window_);
        window_ = nullptr;
    }
}

void Renderer::ensureShaders() {
    solidShader_          = std::make_unique<Shader>(sources::kSolidColorVS,        sources::kSolidColorFS);
    linearGradientShader_ = std::make_unique<Shader>(sources::kGradientLinearVS,   sources::kGradientLinearFS);
    radialGradientShader_ = std::make_unique<Shader>(sources::kGradientRadialVS,   sources::kGradientRadialFS);
    texturedShader_       = std::make_unique<Shader>(sources::kTexturedVS,          sources::kTexturedFS);
    postShader_           = std::make_unique<Shader>(sources::kPostProcessVS,      sources::kPostProcessFS);

    fullscreenQuad_ = std::make_unique<Mesh>();
    fullscreenQuad_->addRect(-1.0f, -1.0f, 1.0f, 1.0f, 1, 1, 1, 1);
    fullscreenQuad_->addRect(-1.0f, -1.0f, 1.0f, 1.0f, 1, 1, 1, 1);
    fullscreenQuad_->addTriangle(0, 1, 2);
    fullscreenQuad_->addTriangle(0, 2, 3);
    fullscreenQuad_->upload(false);
}

void Renderer::ensureFbo() {
    glGenFramebuffers(1, &fbo_);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo_);

    glGenTextures(1, &fboColorTex_);
    glBindTexture(GL_TEXTURE_2D, fboColorTex_);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width_, height_, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, fboColorTex_, 0);

    glGenRenderbuffers(1, &fboDepthRbo_);
    glBindRenderbuffer(GL_RENDERBUFFER, fboDepthRbo_);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH24_STENCIL8, width_, height_);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, fboDepthRbo_);

    GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    if (status != GL_FRAMEBUFFER_COMPLETE) {
        LOGE("FBO incomplete: 0x%x", status);
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void Renderer::releaseFbo() {
    if (fboDepthRbo_) glDeleteRenderbuffers(1, &fboDepthRbo_);
    if (fboColorTex_) glDeleteTextures(1, &fboColorTex_);
    if (fbo_)         glDeleteFramebuffers(1, &fbo_);
    fbo_ = 0; fboColorTex_ = 0; fboDepthRbo_ = 0;
}

void Renderer::submitFrame(std::vector<RenderCommand> commands, const float* viewProj) {
    {
        std::lock_guard<std::mutex> lk(mutex_);
        pending_ = std::move(commands);
        std::memcpy(pendingViewProj_, viewProj, sizeof(pendingViewProj_));
        hasPending_ = true;
    }
    cv_.notify_one();
}

void Renderer::setPostFx(float brightness, float contrast, float hue, float saturation) {
    std::lock_guard<std::mutex> lk(mutex_);
    brightness_ = brightness;
    contrast_   = contrast;
    hue_        = hue;
    saturation_ = saturation;
}

void Renderer::requestViewport(int width, int height) {
    std::lock_guard<std::mutex> lk(mutex_);
    if (width == width_ && height == height_) return;
    width_ = width;
    height_ = height;
    if (window_) ANativeWindow_setBuffersGeometry(window_, width, height, 0);
    releaseFbo();
    ensureFbo();
}

void Renderer::applyBlend(BlendMode m) {
    switch (m) {
        case BlendMode::Normal:
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            break;
        case BlendMode::Multiply:
            glBlendFunc(GL_DST_COLOR, GL_ONE_MINUS_SRC_ALPHA);
            break;
        case BlendMode::Screen:
            glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_COLOR);
            break;
        case BlendMode::Overlay:
            glBlendFunc(GL_SRC_ALPHA, GL_DST_COLOR);
            break;
        case BlendMode::Add:
            glBlendFunc(GL_SRC_ALPHA, GL_ONE);
            break;
        case BlendMode::Darken:
            glBlendFunc(GL_MIN, GL_ONE_MINUS_SRC_ALPHA);
            break;
        case BlendMode::Lighten:
            glBlendFunc(GL_MAX, GL_ONE_MINUS_SRC_ALPHA);
            break;
        case BlendMode::Difference:
            glBlendFunc(GL_SRC_ALPHA, GL_DST_ALPHA);
            break;
    }
}

bool Renderer::renderFrame() {
    std::vector<RenderCommand> cmds;
    float viewProj[16];
    float brightness, contrast, hue, saturation;
    {
        std::unique_lock<std::mutex> lk(mutex_);
        cv_.wait_for(lk, std::chrono::milliseconds(33),
                    [this](){ return hasPending_ || shuttingDown_; });
        if (shuttingDown_) return false;
        cmds = std::move(pending_);
        std::memcpy(viewProj, pendingViewProj_, sizeof(viewProj));
        brightness = brightness_;
        contrast   = contrast_;
        hue        = hue_;
        saturation = saturation_;
        hasPending_ = false;
    }

    if (display_ == EGL_NO_DISPLAY) return false;

    // 1. Render into FBO
    glBindFramebuffer(GL_FRAMEBUFFER, fbo_);
    glViewport(0, 0, width_, height_);
    glClearColor(0.058f, 0.066f, 0.082f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

    for (auto& cmd : cmds) {
        if (!cmd.shader || !cmd.mesh) continue;
        cmd.shader->use();
        cmd.shader->setMat4("uMVP", cmd.mvp);
        applyBlend(cmd.blend);

        // Set per-shader uniforms based on which shader is bound
        if (cmd.shader == solidShader_.get()) {
            cmd.shader->setVec4("uColor",
                                cmd.color[0], cmd.color[1], cmd.color[2], cmd.color[3] * cmd.alpha);
        } else if (cmd.shader == linearGradientShader_.get()) {
            cmd.shader->setVec2("uStart", cmd.gradStart[0], cmd.gradStart[1]);
            cmd.shader->setVec2("uEnd",   cmd.gradEnd[0],   cmd.gradEnd[1]);
            cmd.shader->setVec4("uColor0",
                                cmd.gradColor0[0], cmd.gradColor0[1],
                                cmd.gradColor0[2], cmd.gradColor0[3]);
            cmd.shader->setVec4("uColor1",
                                cmd.gradColor1[0], cmd.gradColor1[1],
                                cmd.gradColor1[2], cmd.gradColor1[3]);
            cmd.shader->setFloat("uAlpha", cmd.alpha);
        } else if (cmd.shader == radialGradientShader_.get()) {
            cmd.shader->setVec2("uCenter", cmd.gradCenter[0], cmd.gradCenter[1]);
            cmd.shader->setFloat("uRadius", cmd.gradRadius);
            cmd.shader->setVec4("uColor0",
                                cmd.gradColor0[0], cmd.gradColor0[1],
                                cmd.gradColor0[2], cmd.gradColor0[3]);
            cmd.shader->setVec4("uColor1",
                                cmd.gradColor1[0], cmd.gradColor1[1],
                                cmd.gradColor1[2], cmd.gradColor1[3]);
            cmd.shader->setFloat("uAlpha", cmd.alpha);
        } else if (cmd.shader == texturedShader_.get()) {
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, cmd.texture);
            cmd.shader->setInt("uTexture", 0);
            cmd.shader->setFloat("uAlpha", cmd.alpha);
        }

        cmd.mesh->upload(true);
        cmd.mesh->draw();
    }

    // 2. Post-process: blit FBO color -> screen via fullscreen quad
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, width_, height_);
    glDisable(GL_BLEND);
    postShader_->use();
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, fboColorTex_);
    postShader_->setInt("uScene", 0);
    postShader_->setFloat("uBrightness", brightness);
    postShader_->setFloat("uContrast",   contrast);
    postShader_->setFloat("uHueShift",   hue);
    postShader_->setFloat("uSaturation", saturation);
    fullscreenQuad_->draw();
    glEnable(GL_BLEND);

    // 3. Present
    EGLBoolean ok = eglSwapBuffers(display_, surface_);
    return ok == EGL_TRUE;
}

} // namespace devxan::gl
