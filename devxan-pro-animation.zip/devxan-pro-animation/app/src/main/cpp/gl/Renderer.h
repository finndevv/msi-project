#pragma once

#include "Shader.h"
#include "Mesh.h"
#include <EGL/egl.h>
#include <android/native_window.h>
#include <memory>
#include <vector>
#include <cstdint>
#include <atomic>
#include <thread>
#include <mutex>
#include <condition_variable>

namespace devxan::gl {

/** Blend mode enum mirroring compositing semantics across the engine. */
enum class BlendMode : int {
    Normal    = 0,
    Multiply  = 1,
    Screen    = 2,
    Overlay   = 3,
    Add       = 4,
    Darken    = 5,
    Lighten   = 6,
    Difference= 7,
};

/**
 * A single render command: a shader choice, mesh data, uniforms, and a blend
 * mode. The renderer consumes a batch of these per frame.
 */
struct RenderCommand {
    Shader*   shader      = nullptr;
    Mesh*     mesh        = nullptr;
    float     mvp[16]     = {1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1};
    float     color[4]    = {1,1,1,1};
    float     alpha        = 1.0f;
    BlendMode blend       = BlendMode::Normal;
    GLuint    texture     = 0;
    // For gradient shaders
    float     gradStart[2]    = {0, 0};
    float     gradEnd[2]      = {1, 1};
    float     gradCenter[2]  = {0.5f, 0.5f};
    float     gradRadius      = 1.0f;
    float     gradColor0[4]   = {1,1,1,1};
    float     gradColor1[4]   = {0,0,0,1};
};

/**
 * Renderer owns the EGL surface bound to the Android Surface passed from the
 * Compose-side SurfaceView. It runs a dedicated render thread that waits on
 * a frame-available condition variable, consumes a render queue, and presents.
 *
 * Post-FX pass: brightness / contrast / hue / saturation applied to the
 * offscreen frame buffer before eglSwapBuffers.
 */
class Renderer {
public:
    Renderer();
    ~Renderer();

    bool init(ANativeWindow* window, int32_t width, int32_t height);
    void deinit();

    /** Set the next frame's command list. Replaces any pending list. */
    void submitFrame(std::vector<RenderCommand> commands, const float* viewProj);

    void setPostFx(float brightness, float contrast, float hue, float saturation);
    void requestViewport(int width, int height);

    /** Blocking: render one frame. Returns false if renderer is shut down. */
    bool renderFrame();

    int fps() const { return fps_.load(std::memory_order_relaxed); }

private:
    void ensureShaders();
    void ensureFbo();
    void releaseFbo();

    EGLDisplay display_ = EGL_NO_DISPLAY;
    EGLContext context_ = EGL_NO_CONTEXT;
    EGLSurface surface_ = EGL_NO_SURFACE;
    EGLConfig  config_  = nullptr;
    ANativeWindow* window_ = nullptr;
    int32_t  width_  = 0;
    int32_t  height_ = 0;

    std::unique_ptr<Shader> solidShader_;
    std::unique_ptr<Shader> linearGradientShader_;
    std::unique_ptr<Shader> radialGradientShader_;
    std::unique_ptr<Shader> texturedShader_;
    std::unique_ptr<Shader> postShader_;

    std::unique_ptr<Mesh> fullscreenQuad_;

    GLuint fbo_         = 0;
    GLuint fboColorTex_ = 0;
    GLuint fboDepthRbo_ = 0;

    float brightness_ = 1.0f;
    float contrast_   = 1.0f;
    float hue_        = 0.0f;
    float saturation_ = 1.0f;

    std::mutex  mutex_;
    std::condition_variable cv_;
    std::vector<RenderCommand> pending_;
    float pendingViewProj_[16] = {1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1};
    bool hasPending_ = false;
    bool shuttingDown_ = false;

    std::atomic<int> fps_{60};

    void applyBlend(BlendMode m);
};

} // namespace devxan::gl
