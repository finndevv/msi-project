package com.devxan.proanimation.data.models

/**
 * Bezier path representation. Internally stores MoveTo/LineTo/Quad/Cubic/Close
 * segments. This is the unified primitive for both vector drawing and the
 * output of the .stk importer.
 *
 * Pivot .stk figures store stick-segment endpoints; the converter turns those
 * into a series of MoveTo + LineTo commands so the figure can be rendered
 * with the standard [Path] style pipeline.
 */
class BezierPath {

    enum class CommandType { MoveTo, LineTo, QuadTo, CubicTo, Close }

    data class Command(
        val type: CommandType,
        val x1: Float = 0f, val y1: Float = 0f,
        val x2: Float = 0f, val y2: Float = 0f,
        val x3: Float = 0f, val y3: Float = 0f,
    )

    private val commands = mutableListOf<Command>()

    fun isEmpty(): Boolean = commands.none { it.type != CommandType.MoveTo }
    fun size(): Int = commands.size

    fun moveTo(x: Float, y: Float) { commands.add(Command(CommandType.MoveTo, x, y)) }
    fun lineTo(x: Float, y: Float) { commands.add(Command(CommandType.LineTo, x, y)) }
    fun quadTo(cx: Float, cy: Float, x: Float, y: Float) =
        commands.add(Command(CommandType.QuadTo, cx, cy, x, y))
    fun cubicTo(c1x: Float, c1y: Float, c2x: Float, c2y: Float,
                x: Float, y: Float) =
        commands.add(Command(CommandType.CubicTo, c1x, c1y, c2x, c2y, x, y))
    fun close() { commands.add(Command(CommandType.Close)) }

    fun commands(): List<Command> = commands

    fun reset() { commands.clear() }

    fun add(other: BezierPath) {
        commands.addAll(other.commands)
    }

    /**
     * Apply an affine transform to every control point in this path.
     * Returns this (mutated).
     */
    fun applyTransform(t: AffineTransform): BezierPath {
        for (i in commands.indices) {
            val c = commands[i]
            commands[i] = when (c.type) {
                CommandType.MoveTo, CommandType.LineTo ->
                    c.copy(x1 = t.transformX(Vec2(c.x1, c.y1)), y1 = t.transformY(Vec2(c.x1, c.y1)))
                CommandType.QuadTo -> {
                    val p1 = Vec2(c.x1, c.y1); val p2 = Vec2(c.x2, c.y2)
                    c.copy(
                        x1 = t.transformX(p1), y1 = t.transformY(p1),
                        x2 = t.transformX(p2), y2 = t.transformY(p2)
                    )
                }
                CommandType.CubicTo -> {
                    val p1 = Vec2(c.x1, c.y1); val p2 = Vec2(c.x2, c.y2); val p3 = Vec2(c.x3, c.y3)
                    c.copy(
                        x1 = t.transformX(p1), y1 = t.transformY(p1),
                        x2 = t.transformX(p2), y2 = t.transformY(p2),
                        x3 = t.transformX(p3), y3 = t.transformY(p3)
                    )
                }
                CommandType.Close -> c
            }
        }
        return this
    }

    /** Bounding box of all control points (approximate). */
    fun bounds(): Rect {
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (c in commands) {
            when (c.type) {
                CommandType.MoveTo, CommandType.LineTo -> {
                    minX = minOf(minX, c.x1); maxX = maxOf(maxX, c.x1)
                    minY = minOf(minY, c.y1); maxY = maxOf(maxY, c.y1)
                }
                CommandType.QuadTo -> {
                    minX = minOf(minX, c.x1, c.x2); maxX = maxOf(maxX, c.x1, c.x2)
                    minY = minOf(minY, c.y1, c.y2); maxY = maxOf(maxY, c.y1, c.y2)
                }
                CommandType.CubicTo -> {
                    minX = minOf(minX, c.x1, c.x2, c.x3); maxX = maxOf(maxX, c.x1, c.x2, c.x3)
                    minY = minOf(minY, c.y1, c.y2, c.y3); maxY = maxOf(maxY, c.y1, c.y2, c.y3)
                }
                CommandType.Close -> { /* no-op */ }
            }
        }
        if (minX == Float.MAX_VALUE) return Rect.ZERO
        return Rect(minX, minY, maxX - minX, maxY - minY)
    }

    /**
     * Flatten this Bezier path to a list of contour polylines (lists of points).
     * Each MoveTo starts a new contour; Close terminates the current one.
     */
    fun flatten(tolerance: Float = 0.5f): List<List<Vec2>> {
        val contours = mutableListOf<MutableList<Vec2>>()
        var current: MutableList<Vec2>? = null
        for (c in commands) {
            when (c.type) {
                CommandType.MoveTo -> {
                    current = mutableListOf(Vec2(c.x1, c.y1))
                    contours.add(current)
                }
                CommandType.LineTo -> current?.add(Vec2(c.x1, c.y1))
                CommandType.QuadTo -> {
                    val p0 = current?.lastOrNull() ?: Vec2(c.x1, c.y1)
                    val p1 = Vec2(c.x1, c.y1)
                    val p2 = Vec2(c.x2, c.y2)
                    flattenQuad(p0, p1, p2, tolerance, current ?: mutableListOf<Vec2>().also { contours.add(it); current = it })
                }
                CommandType.CubicTo -> {
                    val p0 = current?.lastOrNull() ?: Vec2(c.x1, c.y1)
                    val p1 = Vec2(c.x1, c.y1)
                    val p2 = Vec2(c.x2, c.y2)
                    val p3 = Vec2(c.x3, c.y3)
                    flattenCubic(p0, p1, p2, p3, tolerance, current ?: mutableListOf<Vec2>().also { contours.add(it); current = it })
                }
                CommandType.Close -> { current = null }
            }
        }
        return contours
    }

    private fun flattenQuad(p0: Vec2, p1: Vec2, p2: Vec2, tol: Float, out: MutableList<Vec2>) {
        val ux = 2f * p1.x - p0.x - p2.x
        val uy = 2f * p1.y - p0.y - p2.y
        if (ux * ux + uy * uy <= 16f * tol * tol) {
            out.add(p2)
            return
        }
        val m01 = p0.lerp(p1, 0.5f)
        val m12 = p1.lerp(p2, 0.5f)
        val m = m01.lerp(m12, 0.5f)
        flattenQuad(p0, m01, m, tol, out)
        flattenQuad(m, m12, p2, tol, out)
    }

    private fun flattenCubic(p0: Vec2, p1: Vec2, p2: Vec2, p3: Vec2, tol: Float, out: MutableList<Vec2>) {
        val ux = 3f * (p1.x - p0.x) - 3f * (p2.x - p1.x) + (p3.x - p2.x)
        val uy = 3f * (p1.y - p0.y) - 3f * (p2.y - p1.y) + (p3.y - p2.y)
        if (ux * ux + uy * uy <= 16f * tol * tol) {
            out.add(p3)
            return
        }
        val m01 = p0.lerp(p1, 0.5f)
        val m12 = p1.lerp(p2, 0.5f)
        val m23 = p2.lerp(p3, 0.5f)
        val m012 = m01.lerp(m12, 0.5f)
        val m123 = m12.lerp(m23, 0.5f)
        val m = m012.lerp(m123, 0.5f)
        flattenCubic(p0, m01, m012, m, tol, out)
        flattenCubic(m, m123, m23, p3, tol, out)
    }

    fun copy(): BezierPath {
        val p = BezierPath()
        p.commands.addAll(commands)
        return p
    }
}

/**
 * Axis-aligned rectangle.
 */
data class Rect(val x: Float, val y: Float, val w: Float, val h: Float) {
    val left get() = x
    val top get() = y
    val right get() = x + w
    val bottom get() = y + h
    val centerX get() = x + w * 0.5f
    val centerY get() = y + h * 0.5f
    fun contains(px: Float, py: Float) = px in x..(x + w) && py in y..(y + h)
    fun contains(v: Vec2) = contains(v.x, v.y)
    fun expand(pad: Float) = Rect(x - pad, y - pad, w + pad * 2, h + pad * 2)
    fun union(o: Rect) = Rect(
        minOf(left, o.left), minOf(top, o.top),
        maxOf(right, o.right) - minOf(left, o.left),
        maxOf(bottom, o.bottom) - minOf(top, o.top)
    )
    companion object { val ZERO = Rect(0f, 0f, 0f, 0f) }
}

/**
 * RGBA color, normalized 0..1 with optional alpha.
 */
@JvmInline
value class Color(val argb: Int) {
    val r get() = ((argb shr 16) and 0xFF) / 255f
    val g get() = ((argb shr 8)  and 0xFF) / 255f
    val b get() = ( argb         and 0xFF) / 255f
    val a get() = ((argb ushr 24)         and 0xFF) / 255f

    fun toArray(out: FloatArray, offset: Int = 0) {
        out[offset] = r; out[offset + 1] = g; out[offset + 2] = b; out[offset + 3] = a
    }

    companion object {
        fun rgba(r: Int, g: Int, b: Int, a: Int = 255) =
            Color(((a and 0xFF) shl 24) or ((r and 0xFF) shl 16) or ((g and 0xFF) shl 8) or (b and 0xFF))
        fun rgba(r: Float, g: Float, b: Float, a: Float = 1f) =
            rgba((r * 255f).toInt(), (g * 255f).toInt(), (b * 255f).toInt(), (a * 255f).toInt())
        val Black = rgba(0, 0, 0, 255)
        val White = rgba(255, 255, 255, 255)
        val Transparent = rgba(0, 0, 0, 0)
        val Red = rgba(255, 0, 0, 255)
        val Green = rgba(0, 255, 0, 255)
        val Blue = rgba(0, 0, 255, 255)
        val Cyan = rgba(0x22, 0xD3, 0xEE, 255)
    }
}

/**
 * Fill specification for a path or layer.
 */
sealed class FillStyle {
    data class Solid(val color: Color) : FillStyle()
    data class LinearGradient(
        val start: Vec2, val end: Vec2,
        val color0: Color, val color1: Color
    ) : FillStyle()
    data class RadialGradient(
        val center: Vec2, val radius: Float,
        val color0: Color, val color1: Color
    ) : FillStyle()
    data class Pattern(val bitmapId: String, val tileMode: TileMode = TileMode.Repeat) : FillStyle()
    object None : FillStyle()

    enum class TileMode { Clamp, Repeat, Mirror }
}

/**
 * Stroke styling: variable width, dash pattern, line join / cap, arrowheads.
 */
data class StrokeStyle(
    val color: Color = Color.Black,
    val width: Float = 2f,
    val join: LineJoin = LineJoin.Miter,
    val cap: LineCap = LineCap.Round,
    val dashed: Boolean = false,
    val dashPattern: FloatArray = floatArrayOf(10f, 6f),
    val hasArrowHead: Boolean = false,
    val arrowHeadLength: Float = 12f,
    val arrowHeadWidth: Float = 8f,
) {
    enum class LineJoin { Miter, Round, Bevel }
    enum class LineCap { Butt, Round, Square }
}

/**
 * Layer-level effect chain (drop shadow, glow, outline).
 */
data class EffectStyle(
    val dropShadow: DropShadow? = null,
    val glow: Glow? = null,
    val outline: Outline? = null,
) {
    data class DropShadow(val offset: Vec2, val blur: Float, val color: Color, val opacity: Float = 1f)
    data class Glow(val blur: Float, val color: Color, val opacity: Float = 1f, val inner: Boolean = false)
    data class Outline(val width: Float, val color: Color, val opacity: Float = 1f)
}
