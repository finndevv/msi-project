package com.devxan.proanimation.ui.toolbar

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.devxan.proanimation.ui.theme.*
import com.devxan.proanimation.viewmodel.StudioViewModel

/**
 * The top toolbar: tool palette on the left, playback controls in the center,
 * and onion-skin / auto-keyframe toggles on the right.
 */
@Composable
fun Toolbar(
    selectedTool: StudioViewModel.Tool,
    onToolSelected: (StudioViewModel.Tool) -> Unit,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onStop: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onFirst: () -> Unit,
    onLast: () -> Unit,
    onionSkinEnabled: Boolean,
    onToggleOnionSkin: () -> Unit,
    autoKeyframe: Boolean,
    onToggleAutoKeyframe: () -> Unit
) {
    Surface(color = DarkSurfaceAlt, tonalElevation = 1.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tools (scrollable)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                items(toolList) { (tool, icon, label) ->
                    ToolButton(
                        icon = icon,
                        label = label,
                        selected = selectedTool == tool,
                        onClick = { onToolSelected(tool) }
                    )
                }
            }

            // Playback controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(onClick = onFirst) { Icon(Icons.Default.SkipPrevious, "First") }
                IconButton(onClick = onPrev)  { Icon(Icons.Default.KeyboardArrowLeft, "Prev") }
                IconButton(onClick = onPlayPause) {
                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play")
                }
                IconButton(onClick = onStop)  { Icon(Icons.Default.Stop, "Stop") }
                IconButton(onClick = onNext)  { Icon(Icons.Default.KeyboardArrowRight, "Next") }
                IconButton(onClick = onLast)  { Icon(Icons.Default.SkipNext, "Last") }
            }

            Spacer(Modifier.width(12.dp))

            // Toggles
            ToggleButton("Onion", Icons.Default.Layers, onionSkinEnabled, onToggleOnionSkin)
            ToggleButton("Auto-K", Icons.Default.Edit, autoKeyframe, onToggleAutoKeyframe)
        }
    }
}

@Composable
private fun ToolButton(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val color = if (selected) DarkPrimary else DarkMuted
    val bgColor = if (selected) DarkBackground else DarkSurfaceAlt
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(6.dp),
        tonalElevation = if (selected) 4.dp else 0.dp
    ) {
        Column(
            modifier = Modifier
                .clickable(onClick = onClick)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(18.dp))
            Text(label, color = color, fontSize = 9.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun ToggleButton(label: String, icon: ImageVector, enabled: Boolean, onClick: () -> Unit) {
    val color = if (enabled) DarkSecondary else DarkMuted
    Surface(
        color = if (enabled) DarkBackground else DarkSurfaceAlt,
        shape = RoundedCornerShape(6.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(label, color = color, fontSize = 10.sp)
        }
    }
}

private val toolList: List<Triple<StudioViewModel.Tool, ImageVector, String>> = listOf(
    Triple(StudioViewModel.Tool.Select,    Icons.Default.NearMe,       "Select"),
    Triple(StudioViewModel.Tool.Pen,       Icons.Default.Edit,         "Pen"),
    Triple(StudioViewModel.Tool.Brush,     Icons.Default.Brush,         "Brush"),
    Triple(StudioViewModel.Tool.Eraser,    Icons.Default.Cancel,       "Erase"),
    Triple(StudioViewModel.Tool.Rectangle,Icons.Default.Rectangle,     "Rect"),
    Triple(StudioViewModel.Tool.Ellipse,   Icons.Default.Circle,       "Ellipse"),
    Triple(StudioViewModel.Tool.Polygon,   Icons.Default.Star,         "Poly"),
    Triple(StudioViewModel.Tool.Star,      Icons.Default.Star,         "Star"),
    Triple(StudioViewModel.Tool.Spiral,    Icons.Default.Loop,         "Spiral"),
    Triple(StudioViewModel.Tool.NodeEdit,  Icons.Default.Tune,         "Node"),
    Triple(StudioViewModel.Tool.Eyedropper,Icons.Default.Colorize,     "Pick"),
    Triple(StudioViewModel.Tool.Bone,      Icons.Default.LinearScale, "Bone"),
    Triple(StudioViewModel.Tool.IK,        Icons.Default.GpsFixed,     "IK"),
    Triple(StudioViewModel.Tool.Hand,      Icons.Default.PanTool,      "Hand"),
    Triple(StudioViewModel.Tool.Zoom,      Icons.Default.Search,       "Zoom"),
)
