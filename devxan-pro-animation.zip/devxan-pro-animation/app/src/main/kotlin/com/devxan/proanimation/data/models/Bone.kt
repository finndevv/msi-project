package com.devxan.proanimation.data.models

/**
 * A bone is the atomic unit of the rigging system.
 *
 * - [head] and [tail] are the rest pose endpoints in skeleton-local space.
 * - [rotation] is the runtime rotation in radians (clockwise positive),
 *   relative to the parent bone's coordinate frame.
 * - [parentIndex] points to the parent bone index in the skeleton's
 *   flat bone array; -1 for a root bone.
 * - [scale] is the runtime length multiplier; bone stretching is normally
 *   locked but is allowed for squash-and-stretch effects.
 *
 * Constraints can be attached per-bone: angle limits, translation locks,
 * scale locks, spring/bounce/damping parameters.
 */
data class Bone(
    val name: String,
    val head: Vec2,
    val tail: Vec2,
    val parentIndex: Int = -1,
    val rotation: Float = 0f,
    val scale: Float = 1f,
    val color: Int = 0xFF22D3EE.toInt(),
    val constraints: Constraints = Constraints(),
    val dynamics: Dynamics = Dynamics(),
    val smartDriverTarget: Int = -1,        // index of the bone this smart-bone drives
    val smartDriverAmount: Float = 1f,
) {
    val restLength: Float
        get() = (tail - head).length()

    val restDirection: Vec2
        get() = (tail - head).normalized()

    val restAngle: Float
        get() = kotlin.math.atan2(restDirection.y, restDirection.x)
}

/**
 * Bone constraints.
 */
data class Constraints(
    /** Lock rotation entirely - used for prop-style bones (e.g., sword hilt). */
    val lockRotation: Boolean = false,
    /** Lock translation - bone cannot be moved from its rest position. */
    val lockTranslation: Boolean = false,
    /** Lock scale - prevent squash/stretch. */
    val lockScale: Boolean = false,
    /** Min/max rotation relative to parent. */
    val angleMin: Float = -Float.MAX_VALUE,
    val angleMax: Float =  Float.MAX_VALUE,
    /** Stretch limit (max length multiplier, even when scale is unlocked). */
    val stretchLimit: Float = 1.5f,
    /** IK target bone index, or -1 if this bone is the root of a non-IK chain. */
    val ikTarget: Int = -1,
    /** Pole vector for IK chain orientation. */
    val poleTarget: Int = -1,
    /** Strength radius - radius of automatic weight binding. */
    val strengthRadius: Float = 100f,
    /** Whether the bone is a "target" bone (no length, just a point). */
    val isTarget: Boolean = false,
)

/**
 * Spring-bone dynamics. When applied, the bone lags behind its animated
 * position by a critically damped spring with adjustable bounce & damping.
 */
data class Dynamics(
    val enabled: Boolean = false,
    val spring: Float = 0.5f,      // stiffness 0..1
    val damping: Float = 0.6f,      // damping ratio
    val bounce: Float = 0.2f,       // additional elasticity
    val gravity: Float = 0f,        // downward bias, world units / sec^2
    val mass: Float = 1f,           // mass for force-based models
)

/**
 * A skeleton is a flat array of bones. Parent bones must appear before
 * children (topological order) for the forward kinematics pass to be
 * correct. We expose both array access and a tree-walk for clarity.
 */
class Skeleton(
    val name: String = "skeleton",
    val bones: MutableList<Bone> = mutableListOf(),
) {
    fun add(bone: Bone): Int { bones.add(bone); return bones.size - 1 }
    operator fun get(i: Int) = bones[i]
    val size get() = bones.size

    fun childrenOf(boneIndex: Int): List<Int> =
        bones.indices.filter { bones[it].parentIndex == boneIndex }

    fun rootBones(): List<Int> =
        bones.indices.filter { bones[it].parentIndex == -1 }

    /** Returns a deep copy with the same name. */
    fun copy(): Skeleton = Skeleton(name, bones.map { it.copy() }.toMutableList())
}

/**
 * Result of a forward-kinematics pass: world-space head/tail positions
 * and accumulated transforms per bone.
 */
data class BoneWorldPose(
    val boneIndex: Int,
    val headWorld: Vec2,
    val tailWorld: Vec2,
    val worldAngle: Float,
    val worldTransform: AffineTransform,
)

/**
 * Forward kinematics solver. Walks the bone array in topological order,
 * accumulating parent transforms, applying per-bone rotation & scale,
 * applying angle constraints, and producing a world pose array.
 */
class ForwardKinematics(val skeleton: Skeleton) {

    /**
     * Resolve a runtime pose given a [rotationOverrides] map (boneIndex -> radians).
     * Bones not in the map use their default [Bone.rotation].
     */
    fun solve(rotationOverrides: Map<Int, Float> = emptyMap(),
              translationOverrides: Map<Int, Vec2> = emptyMap()): List<BoneWorldPose> {
        val poses = arrayOfNulls<BoneWorldPose>(skeleton.size)

        for (i in 0 until skeleton.size) {
            val bone = skeleton[i]
            val parentPose = if (bone.parentIndex >= 0) poses[bone.parentIndex] else null

            // Local transform: rotate around bone head, translate to head
            val rotRaw = rotationOverrides[i] ?: bone.rotation
            val rot = if (bone.constraints.lockRotation) 0f else
                rotRaw.coerceIn(bone.constraints.angleMin, bone.constraints.angleMax)

            val sc = if (bone.constraints.lockScale) 1f else bone.scale.coerceIn(0f, bone.constraints.stretchLimit)

            // World transform of head = parent_tail or parent's chain tip
            val headWorld: Vec2
            val headAngleWorld: Float

            if (parentPose == null) {
                val trans = translationOverrides[i] ?: Vec2.Zero
                headWorld = bone.head + trans
                headAngleWorld = bone.restAngle + rot
            } else {
                headWorld = parentPose.tailWorld
                headAngleWorld = parentPose.worldAngle + rot
            }

            val length = bone.restLength * sc
            val tailWorld = headWorld + Vec2.fromAngle(headAngleWorld, length)
            val transform = AffineTransform
                .translate(headWorld)
                .rotate(headAngleWorld - bone.restAngle)
                .scale(sc, sc)

            poses[i] = BoneWorldPose(i, headWorld, tailWorld, headAngleWorld, transform)
        }

        return poses.map { it!! }
    }
}
