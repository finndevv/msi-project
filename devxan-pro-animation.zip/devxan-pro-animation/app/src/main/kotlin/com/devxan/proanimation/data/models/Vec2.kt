package com.devxan.proanimation.data.models

import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Immutable 2D vector. Used across the entire engine for vertex positions,
 * joint positions, control points, transforms, IK targets, etc.
 */
data class Vec2(val x: Float, val y: Float) {

    operator fun plus(o: Vec2) = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
    operator fun times(s: Float) = Vec2(x * s, y * s)
    operator fun times(o: Vec2) = Vec2(x * o.x, y * o.y)
    operator fun div(s: Float) = if (s != 0f) Vec2(x / s, y / s) else Zero
    operator fun unaryMinus() = Vec2(-x, -y)

    fun dot(o: Vec2) = x * o.x + y * o.y
    fun cross(o: Vec2) = x * o.y - y * o.x
    fun lengthSquared() = x * x + y * y
    fun length() = hypot(x, y)
    fun distance(o: Vec2) = hypot(x - o.x, y - o.y)
    fun lerp(o: Vec2, t: Float) = Vec2(x + (o.x - x) * t, y + (o.y - y) * t)

    fun normalized(): Vec2 {
        val l = length()
        return if (l > 1e-6f) Vec2(x / l, y / l) else Zero
    }

    fun perpendicular() = Vec2(-y, x)
    fun rotated(radians: Float, pivot: Vec2 = Zero): Vec2 {
        val c = cos(radians)
        val s = sin(radians)
        val dx = x - pivot.x
        val dy = y - pivot.y
        return Vec2(pivot.x + dx * c - dy * s, pivot.y + dx * s + dy * c)
    }

    fun angleTo(o: Vec2): Float {
        val d = dot(o)
        val c = cross(o)
        return kotlin.math.atan2(c, d)
    }

    companion object {
        val Zero = Vec2(0f, 0f)
        val UnitX = Vec2(1f, 0f)
        val UnitY = Vec2(0f, 1f)
        fun fromAngle(rad: Float, len: Float = 1f) = Vec2(cos(rad) * len, sin(rad) * len)
    }
}

/**
 * Affine 2D transform: translate, rotate, scale, shear.
 * Represented as a 2x3 matrix:
 *   [a c tx]
 *   [b d ty]
 *   [0 0  1]
 */
data class AffineTransform(
    val a: Float = 1f,  // scaleX
    val b: Float = 0f,  // shearY
    val c: Float = 0f,  // shearX
    val d: Float = 1f,  // scaleY
    val tx: Float = 0f,
    val ty: Float = 0f,
) {
    fun translate(dx: Float, dy: Float) = AffineTransform(a, b, c, d, tx + dx, ty + dy)
    fun translate(v: Vec2) = translate(v.x, v.y)
    fun rotate(rad: Float): AffineTransform {
        val cos = kotlin.math.cos(rad)
        val sin = kotlin.math.sin(rad)
        return AffineTransform(
            a * cos - b * sin, a * sin + b * cos,
            c * cos - d * sin, c * sin + d * cos,
            tx * cos - ty * sin, tx * sin + ty * cos,
        )
    }
    fun scale(sx: Float, sy: Float = sx) = AffineTransform(a * sx, b * sx, c * sy, d * sy, tx * sx, ty * sy)
    fun transform(v: Vec2) = Vec2(a * v.x + c * v.y + tx, b * v.x + d * v.y + ty)
    fun transformX(v: Vec2) = a * v.x + c * v.y + tx
    fun transformY(v: Vec2) = b * v.x + d * v.y + ty
    fun concat(o: AffineTransform): AffineTransform {
        return AffineTransform(
            a = a * o.a + c * o.b,
            b = b * o.a + d * o.b,
            c = a * o.c + c * o.d,
            d = b * o.c + d * o.d,
            tx = a * o.tx + c * o.ty + tx,
            ty = b * o.tx + d * o.ty + ty
        )
    }
    fun inverse(): AffineTransform {
        val det = a * d - b * c
        if (kotlin.math.abs(det) < 1e-7f) return Identity
        val invDet = 1f / det
        return AffineTransform(
            a =  d * invDet,
            b = -b * invDet,
            c = -c * invDet,
            d =  a * invDet,
            tx = (c * ty - d * tx) * invDet,
            ty = (b * tx - a * ty) * invDet
        )
    }
    fun toMatrix4(): FloatArray = floatArrayOf(
        a,  b, 0f, 0f,
        c,  d, 0f, 0f,
        0f, 0f, 1f, 0f,
        tx, ty, 0f, 1f,
    )

    companion object {
        val Identity = AffineTransform()
        fun translate(x: Float, y: Float) = AffineTransform(tx = x, ty = y)
        fun translate(v: Vec2) = translate(v.x, v.y)
        fun rotate(rad: Float) = Identity.rotate(rad)
        fun scale(s: Float) = AffineTransform(d = s).scale(s)
        fun scale(sx: Float, sy: Float) = AffineTransform(a = sx, d = sy)
    }
}

/**
 * Standard "TRS" transform used for layers / bones / figures.
 * Translation is in world/local space (depends on context), rotation is
 * clockwise positive radians, scale is non-uniform.
 */
data class Transform(
    val position: Vec2 = Vec2.Zero,
    val rotation: Float = 0f,        // radians
    val scale: Vec2 = Vec2(1f, 1f),
    val shear: Vec2 = Vec2.Zero,
) {
    fun toAffine(): AffineTransform {
        val cosR = kotlin.math.cos(rotation)
        val sinR = kotlin.math.sin(rotation)
        val sx = scale.x; val sy = scale.y
        val shearX = shear.x; val shearY = shear.y
        return AffineTransform(
            a = cosR * sx,
            b = sinR * sx,
            c = -sinR * sy + shearX,
            d = cosR * sy + shearY,
            tx = position.x, ty = position.y
        )
    }

    fun lerp(o: Transform, t: Float): Transform = Transform(
        position = position.lerp(o.position, t),
        rotation = lerpAngle(rotation, o.rotation, t),
        scale = scale.lerp(o.scale, t),
        shear = shear.lerp(o.shear, t)
    )

    companion object {
        val Identity = Transform()

        fun lerpAngle(a: Float, b: Float, t: Float): Float {
            var diff = ((b - a + kotlin.math.PI) % (2 * kotlin.math.PI) + 2 * kotlin.math.PI) % (2 * kotlin.math.PI) - kotlin.math.PI
            return a + diff * t
        }
    }
}

/**
 * 4x4 column-major matrix used for GLSL MVP uniform uploads.
 */
data class Mat4(val m: FloatArray = FloatArray(16) { if (it % 5 == 0) 1f else 0f }) {

    init { require(m.size == 16) { "Mat4 must hold 16 floats" } }

    companion object {
        fun identity() = Mat4()

        fun ortho(left: Float, right: Float, bottom: Float, top: Float,
                  near: Float = -1f, far: Float = 1f): Mat4 {
            val r = Mat4(FloatArray(16))
            val rl = right - left; val tb = top - bottom; val fn = far - near
            r.m[0] = 2f / rl
            r.m[5] = 2f / tb
            r.m[10] = -2f / fn
            r.m[12] = -(right + left) / rl
            r.m[13] = -(top + bottom) / tb
            r.m[14] = -(far + near) / fn
            return r
        }

        fun multiply(a: Mat4, b: Mat4): Mat4 {
            val out = Mat4(FloatArray(16))
            for (col in 0 until 4) {
                for (row in 0 until 4) {
                    var s = 0f
                    for (k in 0 until 4) {
                        s += a.m[k * 4 + row] * b.m[col * 4 + k]
                    }
                    out.m[col * 4 + row] = s
                }
            }
            return out
        }
    }

    fun asFloatArray(): FloatArray = m
}
