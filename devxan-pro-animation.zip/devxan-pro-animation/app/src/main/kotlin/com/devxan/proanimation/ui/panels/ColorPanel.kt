package com.devxan.proanimation.ui.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.devxan.proanimation.ui.theme.*

/**
 * Color palette + picker panel. Renders the project palette as a grid of
 * swatches; tapping a swatch selects it for the next path / stroke / fill.
 */
@Composable
fun ColorPanel(palette: List<Int>) {
    var selected by remember { mutableStateOf(palette.firstOrNull() ?: 0xFF22D3EE.toInt()) }
    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        Text("Palette", color = DarkPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        // Current color preview
        Box(modifier = Modifier.fillMaxWidth().height(80.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(selected)))
        Spacer(Modifier.height(8.dp))
        // Palette swatches
        val rows = palette.chunked(3)
        rows.forEach { row ->
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.forEach { color ->
                    Box(modifier = Modifier.weight(1f).height(40.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(color))
                        .clickable { selected = color })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Eyedropper: tap anywhere on the canvas to sample a color.",
            color = DarkMuted, fontSize = 10.sp)
        Spacer(Modifier.height(8.dp))
        Text("Recent colors:", color = DarkMuted, fontSize = 10.sp)
        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            repeat(6) { _ ->
                Box(modifier = Modifier.weight(1f).height(24.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(DarkSurfaceAlt))
            }
        }
    }
}
