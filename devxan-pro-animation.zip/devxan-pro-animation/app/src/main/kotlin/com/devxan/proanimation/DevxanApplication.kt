package com.devxan.proanimation

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.devxan.proanimation.engine.audio.AudioEngine
import com.devxan.proanimation.engine.project.CrashRecoveryManager
import com.devxan.proanimation.engine.render.NativeRenderer

/**
 * DEVXAN application entry point. Initializes:
 *   - Notification channels for export / audio recording services
 *   - Crash recovery manager (auto-saves the project every minute)
 *   - Lazy singletons for the native renderer + audio engine
 */
class DevxanApplication : Application() {

    val crashRecovery: CrashRecoveryManager by lazy {
        CrashRecoveryManager(File(filesDir, "recovery").apply { mkdirs() })
    }

    val audioEngine: AudioEngine by lazy { AudioEngine(this) }

    override fun onCreate() {
        super.onCreate()
        instance = this
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(
                "export", "Export", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(
                "record", "Recording", NotificationManager.IMPORTANCE_HIGH))
            nm.createNotificationChannel(NotificationChannel(
                "audio_playback", "Playback", NotificationManager.IMPORTANCE_LOW))
        }
    }

    companion object {
        @Volatile lateinit var instance: DevxanApplication
            private set
    }
}
