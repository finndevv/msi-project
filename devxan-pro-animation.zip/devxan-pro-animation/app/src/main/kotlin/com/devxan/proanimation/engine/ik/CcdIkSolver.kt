package com.devxan.proanimation.engine.ik

import com.devxan.proanimation.data.models.Bone
import com.devxan.proanimation.data.models.Skeleton
import com.devxan.proanimation.data.models.Vec2
import com.devxan.proanimation.data.models.ForwardKinematics
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Cyclic Coordinate Descent IK solver.
 *
 * Iteratively rotates each joint in the chain so its tail moves closer
 * to the target. Works well for chains up to ~20 bones. For longer chains
 * prefer [FabrikSolver].
 *
 * Algorithm per iteration:
 *   1. Starting from the end-effector, walk backwards toward the root.
 *   2. For each bone, rotate it so the chain from that bone's head to the
 *      end-effector aligns with the chain from that bone's head to the target.
 *   3. Then walk forward and re-pin root to its original position.
 *
 * Multiple iterations converge to a solution; we use [iterations]=10.
 */
class CcdIkSolver(
    val skeleton: Skeleton,
    val iterations: Int = 10,
    val tolerance: Float = 0.5f
) {

    /**
     * Solve the IK chain ending at [endEffectorBoneIndex] to reach [target].
     * Mutates [skeleton] bone rotations in-place (local rotations).
     *
     * Returns the solved rotations per bone (only bones in the chain).
     */
    fun solve(endEffectorBoneIndex: Int, target: Vec2): Map<Int, Float> {
        // Collect chain from root to end-effector
        val chain = mutableListOf<Int>()
        var cur = endEffectorBoneIndex
        while (cur >= 0) {
            chain.add(0, cur)
            cur = skeleton[cur].parentIndex
        }
        if (chain.isEmpty()) return emptyMap()

        val fk = ForwardKinematics(skeleton)
        var rotations = (0 until skeleton.size).associate { it to skeleton[it].rotation }.toMutableMap()

        repeat(iterations) {
            // Backward pass: from end-effector down to root
            for (i in chain.size - 1 downTo 1) {
                val boneIndex = chain[i]
                val poses = fk.solve(rotations)
                val pose = poses[boneIndex]
                val headWorld = pose.headWorld
                val tailWorld = poses[endEffectorBoneIndex].tailWorld

                val toEnd = tailWorld - headWorld
                val toTarget = target - headWorld
                if (toEnd.lengthSquared() < 1e-4f || toTarget.lengthSquared() < 1e-4f) continue

                val angleDelta = atan2(
                    toEnd.x * toTarget.y - toEnd.y * toTarget.x,
                    toEnd.x * toTarget.x + toEnd.y * toTarget.y
                )

                val curRot = rotations[boneIndex] ?: 0f
                val bone = skeleton[boneIndex]
                val newRot = if (bone.constraints.lockRotation) curRot
                else (curRot + angleDelta).coerceIn(bone.constraints.angleMin, bone.constraints.angleMax)
                rotations[boneIndex] = newRot
            }

            // Check convergence
            val poses = fk.solve(rotations)
            val endPos = poses[endEffectorBoneIndex].tailWorld
            if (endPos.distance(target) <= tolerance) return rotations
        }
        return rotations
    }

    /**
     * Apply pole vector: after solve, if a pole target is provided, rotate the
     * middle bone of the chain so the chain "elbow" points toward the pole.
     */
    fun applyPoleVector(chain: List<Int>, poleTarget: Vec2, rotations: MutableMap<Int, Float>) {
        if (chain.size < 3) return
        val mid = chain[chain.size / 2]
        val fk = ForwardKinematics(skeleton)
        val poses = fk.solve(rotations)

        val rootHead = poses[chain[0]].headWorld
        val midHead  = poses[mid].headWorld
        val endPos   = poses[chain.last()].tailWorld

        val currentMidDir = (midHead - rootHead).normalized()
        val desiredMidDir = (poleTarget - rootHead).normalized()

        val delta = atan2(
            currentMidDir.x * desiredMidDir.y - currentMidDir.y * desiredMidDir.x,
            currentMidDir.x * desiredMidDir.x + currentMidDir.y * desiredMidDir.y
        )

        val parentIdx = skeleton[mid].parentIndex
        if (parentIdx >= 0) {
            rotations[parentIdx] = (rotations[parentIdx] ?: 0f) + delta
        }
    }
}

/**
 * FABRIK (Forward And Backward Reaching Inverse Kinematics) solver.
 * Handles chains with arbitrary length while keeping each segment's
 * length constant - the standard choice for long tentacle-like chains.
 */
class FabrikSolver(
    val skeleton: Skeleton,
    val iterations: Int = 10,
    val tolerance: Float = 0.5f
) {
    fun solve(endEffectorBoneIndex: Int, target: Vec2): Map<Int, Float> {
        val chain = mutableListOf<Int>()
        var cur = endEffectorBoneIndex
        while (cur >= 0) { chain.add(0, cur); cur = skeleton[cur].parentIndex }
        if (chain.isEmpty()) return emptyMap()

        val fk = ForwardKinematics(skeleton)
        val initPose = fk.solve()
        val positions = chain.map { initPose[it].headWorld }.toMutableList()
        val endPos = initPose[chain.last()].tailWorld
        positions.add(endPos)

        val lengths = (1 until positions.size).map { positions[it].distance(positions[it - 1]) }

        // Root position (will be re-pinned)
        val rootInit = positions.first()

        repeat(iterations) {
            // Backward: pull end to target
            positions[positions.lastIndex] = target
            for (i in positions.lastIndex - 1 downTo 0) {
                val dir = (positions[i] - positions[i + 1]).normalized()
                positions[i] = positions[i + 1] + dir * lengths[i]
            }
            // Forward: re-pin root
            positions[0] = rootInit
            for (i in 1 until positions.size) {
                val dir = (positions[i] - positions[i - 1]).normalized()
                positions[i] = positions[i - 1] + dir * lengths[i - 1]
            }

            val dist = positions.last().distance(target)
            if (dist <= tolerance) return@repeat
        }

        // Convert positions back to local rotations
        val rotations = (0 until skeleton.size).associate { it to skeleton[it].rotation }.toMutableMap()
        for (k in chain.indices) {
            val bone = skeleton[chain[k]]
            val head = positions[k]
            val tail = positions.getOrElse(k + 1) { head + Vec2(bone.restLength, 0f) }
            val worldAngle = atan2(tail.y - head.y, tail.x - head.x)
            val parentPose = if (bone.parentIndex >= 0) {
                val pHead = positions[chain.indexOf(bone.parentIndex).coerceAtLeast(0)]
                fk.solve()[bone.parentIndex].worldAngle
            } else 0f
            val localRot = worldAngle - parentPose - bone.restAngle
            rotations[chain[k]] = if (bone.constraints.lockRotation) 0f
                                   else localRot.coerceIn(bone.constraints.angleMin, bone.constraints.angleMax)
        }
        return rotations
    }
}
