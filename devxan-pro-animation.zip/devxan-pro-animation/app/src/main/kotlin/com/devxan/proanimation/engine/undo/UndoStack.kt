package com.devxan.proanimation.engine.undo

/**
 * Generic undo/redo command stack. Each command is an action that can be
 * executed, undone, and re-executed. The stack supports merging consecutive
 * edits of the same kind (e.g., dragging a slider).
 */
interface Command {
    val description: String
    fun execute()
    fun undo()
    /** If true, this command should be merged with the next command in the stack. */
    fun isMergeable(): Boolean = false
    /** Merge [next] into this command; returns true if successful. */
    fun merge(next: Command): Boolean = false
}

class UndoStack(
    private val capacity: Int = 100,
) {
    private val undoList = ArrayDeque<Command>()
    private val redoList = ArrayDeque<Command>()

    val canUndo: Boolean get() = undoList.isNotEmpty()
    val canRedo: Boolean get() = redoList.isNotEmpty()
    val undoCount: Int get() = undoList.size
    val redoCount: Int get() = redoList.size

    fun push(cmd: Command) {
        cmd.execute()
        if (undoList.isNotEmpty() && undoList.last().isMergeable()) {
            if (undoList.last().merge(cmd)) {
                return
            }
        }
        undoList.addLast(cmd)
        if (undoList.size > capacity) undoList.removeFirst()
        redoList.clear()
    }

    fun undo(): Boolean {
        val cmd = undoList.removeLastOrNull() ?: return false
        cmd.undo()
        redoList.addLast(cmd)
        return true
    }

    fun redo(): Boolean {
        val cmd = redoList.removeLastOrNull() ?: return false
        cmd.execute()
        undoList.addLast(cmd)
        return true
    }

    fun clear() {
        undoList.clear()
        redoList.clear()
    }

    fun historyDescriptions(): List<String> =
        undoList.map { it.description } + redoList.reversed().map { "(redo) ${it.description}" }
}

/**
 * Simple property-setter command. Snapshots old value, applies new value.
 */
class PropertyCommand<T>(
    override val description: String,
    private val getter: () -> T,
    private val setter: (T) -> Unit,
    private val newValue: T,
    private val mergeable: Boolean = false,
    private val shouldMerge: (T, T) -> Boolean = { _, _ -> false },
) : Command {
    private var oldValue: T? = null

    override fun execute() {
        oldValue = getter()
        setter(newValue)
    }

    override fun undo() { oldValue?.let(setter) }

    override fun isMergeable(): Boolean = mergeable

    @Suppress("UNCHECKED_CAST")
    override fun merge(next: Command): Boolean {
        if (next !is PropertyCommand<*>) return false
        next as PropertyCommand<T>
        if (next.description != description) return false
        return shouldMerge(newValue, next.newValue)
    }
}

/**
 * Batch command - groups multiple commands into a single undo entry.
 */
class BatchCommand(
    override val description: String,
    private val commands: List<Command>,
) : Command {
    override fun execute() { commands.forEach { it.execute() } }
    override fun undo() { commands.reversed().forEach { it.undo() } }
}
