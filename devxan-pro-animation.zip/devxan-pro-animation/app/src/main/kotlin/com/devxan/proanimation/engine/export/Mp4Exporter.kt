package com.devxan.proanimation.engine.export

import android.content.Context
import android.content.Intent
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.devxan.proanimation.data.models.DevxanProject
import com.devxan.proanimation.data.models.Layer
import com.devxan.proanimation.data.models.Transform
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * MP4 exporter using MediaCodec hardware H.264 encoder + MediaMuxer container.
 *
 * Workflow:
 *   1. Allocate an input Surface from MediaCodec (configured as encoder).
 *   2. For each frame in [frameRange], render the project's frame to a
 *      canvas-backed Bitmap, blit it into the encoder input surface.
 *   3. Drain the encoder output buffers, muxing each into the .mp4 file.
 *
 * Resolution & bitrate configurable; supports up to 4K (3840×2160).
 */
class Mp4Exporter(private val context: Context) {

    data class Config(
        val width: Int = 1280,
        val height: Int = 720,
        val fps: Int = 24,
        val bitrate: Int = 8_000_000,
        val iframeInterval: Int = 2,
        val profile: Int = MediaCodecInfo.CodecProfileLevel.AVCProfileHigh,
        val frameRange: IntRange = 0..239,
    ) {
        init { require(width in 320..4096 && height in 320..4096) { "Invalid resolution: ${width}x${height}" } }
    }

    private val _progress = MutableLiveData<Pair<Int, Int>>(0 to 0)
    val progress: LiveData<Pair<Int, Int>> = _progress

    private val _status = MutableLiveData<Status>(Status.Idle)
    val status: LiveData<Status> = _status

    sealed class Status {
        object Idle : Status()
        data class Encoding(val currentFrame: Int, val total: Int) : Status()
        data class Done(val file: File, val uri: Uri) : Status()
        data class Failed(val message: String) : Status()
        object Cancelled : Status()
    }

    private var encodingJob: Job? = null

    fun export(
        project: DevxanProject,
        renderFrame: suspend (frame: Int, width: Int, height: Int) -> android.graphics.Bitmap,
        outputFile: File,
        config: Config
    ) {
        encodingJob = CoroutineScope(Dispatchers.Main).launch {
            _status.value = Status.Encoding(0, config.frameRange.count())
            try {
                withContext(Dispatchers.IO) {
                    encodeInternal(project, renderFrame, outputFile, config)
                }
            } catch (e: Exception) {
                _status.value = Status.Failed(e.message ?: "Unknown error")
            }
        }
    }

    fun cancel() {
        encodingJob?.cancel()
        _status.value = Status.Cancelled
    }

    private suspend fun encodeInternal(
        project: DevxanProject,
        renderFrame: suspend (frame: Int, width: Int, height: Int) -> android.graphics.Bitmap,
        outputFile: File,
        config: Config
    ) {
        val format = MediaFormat.createVideoFormat("video/avc", config.width, config.height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, config.bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, config.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, config.iframeInterval)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                setInteger(MediaFormat.KEY_PROFILE, config.profile)
            }
        }

        val codec = MediaCodec.createEncoderByType("video/avc")
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inputSurface = codec.createInputSurface()
        codec.start()

        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val bufferInfo = MediaCodec.BufferInfo()
        var muxerTrack = -1
        var muxerStarted = false

        val frames = config.frameRange.toList()
        val total = frames.size
        for ((idx, frame) in frames.withIndex()) {
            val bitmap = renderFrame(frame, config.width, config.height)
            drainEncoder(codec, bufferInfo, muxer,
                getTrack = { muxerTrack },
                onStarted = { started -> if (started) muxerStarted = true },
                setTrack = { trackIdx -> muxerTrack = trackIdx }
            )

            pushBitmapToSurface(inputSurface, bitmap)
            _progress.postValue((idx + 1) to total)
            _status.postValue(Status.Encoding(idx + 1, total))
        }
        codec.signalEndOfInputStream()
        drainEncoder(codec, bufferInfo, muxer,
            getTrack = { muxerTrack },
            onStarted = { started -> if (started) muxerStarted = true },
            setTrack = { trackIdx -> muxerTrack = trackIdx }
        )

        codec.stop(); codec.release()
        if (muxerStarted) muxer.stop()
        muxer.release()
        inputSurface.release()

        val uri = FileProvider.getUriForFile(context,
            "${context.packageName}.fileprovider", outputFile)
        _status.postValue(Status.Done(outputFile, uri))
    }

    private fun drainEncoder(
        codec: MediaCodec,
        info: MediaCodec.BufferInfo,
        muxer: MediaMuxer,
        getTrack: () -> Int,
        onStarted: (Boolean) -> Unit,
        setTrack: (Int) -> Unit
    ) {
        while (true) {
            val outIdx = codec.dequeueOutputBuffer(info, 10_000L)
            when {
                outIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    return // Give other threads a chance
                }
                outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    val newFormat = codec.outputFormat
                    val track = muxer.addTrack(newFormat)
                    muxer.start()
                    setTrack(track)
                    onStarted(true)
                }
                outIdx >= 0 -> {
                    val buf = codec.getOutputBuffer(outIdx) ?: continue
                    if (info.size > 0) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        muxer.writeSampleData(getTrack(), buf, info)
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        }
    }

    /** Blit a Bitmap to the MediaCodec input Surface using EGL. */
    private fun pushBitmapToSurface(surface: android.view.Surface, bitmap: android.graphics.Bitmap) {
        val egl = DevxanEgl(surface)
        egl.makeCurrent()
        val tex = DevxanEgl.createTextureFromBitmap(bitmap)
        DevxanEgl.drawFullscreenQuad(tex)
        DevxanEgl.deleteTexture(tex)
        egl.swapBuffers()
        egl.release()
    }

    /**
     * Render an entire project as a PNG sequence into the given output directory.
     * Useful for sprite sheet generation or external NLE pipelines.
     */
    suspend fun exportPngSequence(
        project: DevxanProject,
        renderFrame: suspend (frame: Int, width: Int, height: Int) -> android.graphics.Bitmap,
        outputDir: File,
        width: Int,
        height: Int
    ): List<File> = withContext(Dispatchers.IO) {
        outputDir.mkdirs()
        val files = ArrayList<File>()
        for (frame in 0 until project.frameCount) {
            val bitmap = renderFrame(frame, width, height)
            val file = File(outputDir, "frame_%05d.png".format(frame))
            FileOutputStream(file).use {
                bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
            }
            files.add(file)
            _progress.postValue((frame + 1) to project.frameCount)
        }
        files
    }
}

/**
 * Minimal EGL helper for blitting bitmaps into MediaCodec input surfaces.
 */
private object DevxanEgl {
    operator fun invoke(target: android.view.Surface): DevxanEglHandle {
        val dpy = android.opengl.EGL14.eglGetDisplay(android.opengl.EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        android.opengl.EGL14.eglInitialize(dpy, ver, 0, ver, 1)
        val cfgAttrib = intArrayOf(
            android.opengl.EGL14.EGL_RED_SIZE, 8,
            android.opengl.EGL14.EGL_GREEN_SIZE, 8,
            android.opengl.EGL14.EGL_BLUE_SIZE, 8,
            android.opengl.EGL14.EGL_ALPHA_SIZE, 8,
            android.opengl.EGL14.EGL_RENDERABLE_TYPE, android.opengl.EGL14.EGL_OPENGL_ES2_BIT,
            android.opengl.EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<android.opengl.EGLConfig>(1)
        val numConfig = IntArray(1)
        android.opengl.EGL14.eglChooseConfig(dpy, cfgAttrib, 0, configs, 0, 1, numConfig, 0)
        val ctxAttrib = intArrayOf(
            android.opengl.EGL14.EGL_CONTEXT_CLIENT_VERSION, 2,
            android.opengl.EGL14.EGL_NONE
        )
        val ctx = android.opengl.EGL14.eglCreateContext(
            dpy, configs[0], android.opengl.EGL14.EGL_NO_CONTEXT, ctxAttrib, 0)
        val surfAttrib = intArrayOf(android.opengl.EGL14.EGL_NONE)
        val surf = android.opengl.EGL14.eglCreateWindowSurface(dpy, configs[0], target, surfAttrib, 0)
        return DevxanEglHandle(dpy, configs[0]!!, ctx, surf)
    }

    class DevxanEglHandle(
        private val dpy: android.opengl.EGLDisplay,
        private val cfg: android.opengl.EGLConfig,
        private val ctx: android.opengl.EGLContext,
        private val surf: android.opengl.EGLSurface
    ) {
        fun makeCurrent() {
            android.opengl.EGL14.eglMakeCurrent(dpy, surf, surf, ctx)
        }
        fun swapBuffers() { android.opengl.EGL14.eglSwapBuffers(dpy, surf) }
        fun release() {
            android.opengl.EGL14.eglDestroySurface(dpy, surf)
            android.opengl.EGL14.eglDestroyContext(dpy, ctx)
            android.opengl.EGL14.eglMakeCurrent(dpy,
                android.opengl.EGL14.EGL_NO_SURFACE,
                android.opengl.EGL14.EGL_NO_SURFACE,
                android.opengl.EGL14.EGL_NO_CONTEXT)
        }
    }

    fun createTextureFromBitmap(bitmap: android.graphics.Bitmap): Int {
        val tex = IntArray(1)
        android.opengl.GLES20.glGenTextures(1, tex, 0)
        android.opengl.GLES20.glBindTexture(android.opengl.GLES20.GL_TEXTURE_2D, tex[0])
        android.opengl.GLES20.glTexParameteri(android.opengl.GLES20.GL_TEXTURE_2D,
            android.opengl.GLES20.GL_TEXTURE_MIN_FILTER, android.opengl.GLES20.GL_LINEAR)
        android.opengl.GLES20.glTexParameteri(android.opengl.GLES20.GL_TEXTURE_2D,
            android.opengl.GLES20.GL_TEXTURE_MAG_FILTER, android.opengl.GLES20.GL_LINEAR)
        android.opengl.GLUtils.texImage2D(android.opengl.GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        return tex[0]
    }

    fun deleteTexture(tex: Int) {
        val arr = intArrayOf(tex)
        android.opengl.GLES20.glDeleteTextures(1, arr, 0)
    }

    fun drawFullscreenQuad(tex: Int) {
        android.opengl.GLES20.glBindTexture(android.opengl.GLES20.GL_TEXTURE_2D, tex)
        val verts = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val vb = java.nio.ByteBuffer.allocateDirect(verts.size * 4).order(java.nio.ByteOrder.nativeOrder())
        vb.asFloatBuffer().put(verts)
        val texCoords = floatArrayOf(0f, 1f, 1f, 1f, 0f, 0f, 1f, 0f)
        val tb = java.nio.ByteBuffer.allocateDirect(texCoords.size * 4).order(java.nio.ByteOrder.nativeOrder())
        tb.asFloatBuffer().put(texCoords)
        android.opengl.GLES20.glDrawArrays(android.opengl.GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }
}

/**
 * Foreground service for export work. Survives app backgrounding.
 */
class RenderExportService : android.app.Service() {
    override fun onBind(intent: Intent?): android.os.IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = android.app.Notification.Builder(this, "export")
            .setContentTitle("DEVXAN Export")
            .setContentText("Rendering animation…")
            .setSmallIcon(android.R.drawable.ic_menu_save)
            .build()
        startForeground(1, notification)
        return START_NOT_STICKY
    }
}

/**
 * Scripting / macro engine. Allows users to record UI actions as a script
 * and replay them. Scripts are stored as a list of [Action] entries which
 * are serialized to JSON via kotlinx-serialization.
 */
class MacroEngine {

    @kotlinx.serialization.Serializable
    sealed class Action {
        @kotlinx.serialization.Serializable
        data class SelectLayer(val layerId: String) : Action()
        @kotlinx.serialization.Serializable
        data class SetTransform(val layerId: String, val tx: Float, val ty: Float,
                                val rotation: Float, val sx: Float, val sy: Float) : Action()
        @kotlinx.serialization.Serializable
        data class SetBoneRotation(val skeletonId: String, val boneIdx: Int, val radians: Float) : Action()
        @kotlinx.serialization.Serializable
        data class SetKeyframe(val targetId: String, val channel: String, val frame: Int, val value: Float) : Action()
        @kotlinx.serialization.Serializable
        data class Play(val fromFrame: Int) : Action()
        @kotlinx.serialization.Serializable
        object Pause : Action()
        @kotlinx.serialization.Serializable
        data class GoToFrame(val frame: Int) : Action()
    }

    private val script = mutableListOf<Action>()

    fun record(action: Action) { script.add(action) }
    fun clear() { script.clear() }
    fun count(): Int = script.size
    fun actions(): List<Action> = script.toList()

    fun toJson(): String = kotlinx.serialization.json.Json.encodeToString(
        kotlinx.serialization.builtins.ListSerializer(Action.serializer()), script)

    fun fromJson(json: String) {
        script.clear()
        script.addAll(kotlinx.serialization.json.Json.decodeFromString(
            kotlinx.serialization.builtins.ListSerializer(Action.serializer()), json))
    }
}
