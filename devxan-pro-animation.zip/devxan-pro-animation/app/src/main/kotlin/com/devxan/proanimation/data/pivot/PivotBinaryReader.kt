package com.devxan.proanimation.data.pivot

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.Inflater
import java.util.zip.InflaterInputStream

/**
 * Low-level binary reader used by the Pivot format parsers.
 *
 * Pivot files are stored little-endian. Several numeric fields are written
 * as variable-length integers (mostly in v4/v5); we implement the same
 * algorithm Pivot itself uses internally.
 *
 * Strings: v2/v3 use ASCII null-terminated; v4/v5 use length-prefixed
 * little-endian 16-bit integers + UTF-8.
 *
 * Compression: v3+ may prefix the payload with a zlib stream after a 4-byte
 * uncompressed-length header.
 */
class PivotBinaryReader(private val stream: InputStream) {

    private val buf = ByteArray(8)
    private var position = 0L

    /** Total bytes consumed so far. */
    fun position(): Long = position

    fun available(): Int = stream.available()

    /** Reads a single unsigned byte. */
    fun readUByte(): Int {
        val v = stream.read()
        if (v < 0) throw IOException("EOF")
        position += 1
        return v
    }

    fun readByte(): Int {
        val v = readUByte()
        return if (v >= 128) v - 256 else v
    }

    fun readBoolean(): Boolean = readUByte() != 0

    fun readBytes(count: Int): ByteArray {
        val out = ByteArray(count)
        var off = 0
        while (off < count) {
            val n = stream.read(out, off, count - off)
            if (n < 0) throw IOException("EOF reading $count bytes")
            off += n
        }
        position += count
        return out
    }

    /** Reads little-endian Int16. */
    fun readInt16(): Int {
        readBytes(2).also { buf ->
            return (buf[0].toInt() and 0xFF) or ((buf[1].toInt() and 0xFF) shl 8)
        }
    }

    /** Reads little-endian Int32. */
    fun readInt32(): Int {
        readBytes(4).also { b ->
            return (b[0].toInt() and 0xFF) or
                    ((b[1].toInt() and 0xFF) shl 8) or
                    ((b[2].toInt() and 0xFF) shl 16) or
                    ((b[3].toInt() and 0xFF) shl 24)
        }
    }

    /** Reads little-endian UInt32 as Long. */
    fun readUInt32(): Long = readInt32().toLong() and 0xFFFFFFFFL

    /** Reads little-endian float (IEEE 754). */
    fun readFloat(): Float {
        readBytes(4).also { b ->
            return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).float
        }
    }

    /** Reads little-endian double (IEEE 754). */
    fun readDouble(): Double {
        readBytes(8).also { b ->
            return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).double
        }
    }

    /**
     * Variable-length integer (ULEB128 / Pivot's variant).
     * Each byte carries 7 bits of payload; the MSB is set when more
     * bytes follow.
     */
    fun readVarInt(): Long {
        var result = 0L
        var shift = 0
        var b: Int
        do {
            b = readUByte()
            result = result or ((b and 0x7F).toLong() shl shift)
            shift += 7
        } while ((b and 0x80) != 0 && shift < 64)
        return result
    }

    /** Reads length-prefixed (LE Int16) ASCII / Latin1 string. */
    fun readAsciiString(): String {
        val len = readInt16()
        if (len < 0 || len > 65_535) throw IOException("Bad string length: $len")
        return String(readBytes(len), Charsets.ISO_8859_1)
    }

    /** Reads null-terminated ASCII string. */
    fun readNullTerminatedString(): String {
        val sb = StringBuilder()
        while (true) {
            val b = readUByte()
            if (b == 0) break
            sb.append(b.toChar())
        }
        return sb.toString()
    }

    /** Reads length-prefixed (LE Int32) UTF-8 string (v4/v5 style). */
    fun readUtf8String(): String {
        val len = readInt32()
        if (len < 0 || len > 10_000_000) throw IOException("Bad UTF-8 string length: $len")
        return String(readBytes(len), Charsets.UTF_8)
    }

    /**
     * When a Pivot file body is zlib-compressed, the file first stores the
     * uncompressed length (LE Int32), then a zlib stream. This reads the
     * uncompressed length, decompresses the rest, and returns a new reader
     * over the decompressed buffer.
     */
    fun readZlibBody(): PivotBinaryReader {
        val expectedLen = readInt32()
        if (expectedLen <= 0) return PivotBinaryReader(ByteArrayInputStream(ByteArray(0)))
        val inflater = InflaterInputStream(stream, Inflater())
        val out = ByteArrayOutputStream(expectedLen + 64)
        val chunk = ByteArray(8192)
        var n: Int
        while (true) {
            n = inflater.read(chunk)
            if (n < 0) break
            out.write(chunk, 0, n)
        }
        val data = out.toByteArray()
        if (data.size != expectedLen) {
            // Pivot sometimes stores a slightly different length - we log but tolerate.
            // The DEFLATE stream will have terminated at the actual end.
        }
        return PivotBinaryReader(ByteArrayInputStream(data))
    }

    /** Peek at the next byte without consuming it. */
    fun peekUByte(): Int {
        stream.mark(1)
        val v = stream.read()
        if (v >= 0) stream.reset()
        return v
    }

    fun skip(n: Int) {
        var remaining = n
        while (remaining > 0) {
            val s = stream.skip(remaining.toLong()).toInt()
            if (s <= 0) break
            remaining -= s
        }
        position += (n - remaining)
    }

    fun close() { stream.close() }
}
