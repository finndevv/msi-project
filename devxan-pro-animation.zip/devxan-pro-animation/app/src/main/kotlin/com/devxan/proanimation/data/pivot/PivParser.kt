package com.devxan.proanimation.data.pivot

import com.devxan.proanimation.data.models.Vec2
import java.io.IOException
import java.io.InputStream

/**
 * Native .piv (Pivot Animator project) parser supporting versions 2, 3, 4, and 5.
 *
 * The .piv format describes a full animation project:
 *   - header (version byte + project metadata)
 *   - figure definitions (one or more .stk figures embedded inline)
 *   - background image (PNG bytes if present)
 *   - frame list, where each frame stores per-figure transforms and
 *     per-segment rotations
 *
 * Layout summary (v2-v5):
 *
 *   - Byte 0: version major (2..5)
 *   - Int16  frame width, height (v3+)
 *   - For v4/v5: a zlib-compressed body containing the rest
 *   - Utf8String background image name (or empty)
 *   - Int32 background image bytes length + raw PNG
 *   - Int16 figure count
 *   - For each figure: inline .stk stream (parsed via [StkParser])
 *   - Int32 frame count
 *   - For each frame:
 *       - Int32 figure count in this frame (may differ from scene figs)
 *       - For each figure: Int16 figureId, Int32 x/y translation,
 *         Float32 scale, Float32 rotation, Int16 layer depth,
 *         Int16 segment count, Per segment: Float32 rotation
 *       - For v4/v5: optional marker / audio track references
 *
 * Returned [PivotProject] exposes frame-by-frame data in a neutral
 * representation that the DEVXAN timeline can ingest.
 */
class PivParser {

    fun parse(stream: InputStream): PivotProject {
        val outer = PivotBinaryReader(stream)
        val version = outer.readUByte()
        if (version !in listOf(2, 3, 4, 5)) {
            throw IOException("Unsupported .piv version: $version")
        }
        // Frame size present in v3+
        val frameWidth  = if (version >= 3) outer.readInt32().coerceAtLeast(64) else 640
        val frameHeight = if (version >= 3) outer.readInt32().coerceAtLeast(64) else 480
        val bgColor     = if (version >= 3) outer.readUInt32() else 0xFFFFFFFFL

        val bodyReader = if (version >= 4) outer.readZlibBody() else outer

        // Background image (optional)
        val bgName = if (version >= 4) bodyReader.readUtf8String() else bodyReader.readNullTerminatedString()
        val bgLen  = bodyReader.readInt32()
        val bgBytes = if (bgLen > 0 && bgLen < 50_000_000) bodyReader.readBytes(bgLen) else ByteArray(0)

        // Figure library
        val figureCount = if (version >= 4) bodyReader.readInt32() else bodyReader.readInt16()
        if (figureCount < 0 || figureCount > 1024) throw IOException("Bad figure count: $figureCount")
        val figures = ArrayList<PivotFigure>(figureCount)
        for (i in 0 until figureCount) {
            // Embedded .stk stream: re-enter the [StkParser] logic by
            // creating a sub-reader that starts with the version byte.
            // We do that by reading the next byte as the version, then
            // dispatching to the same internal code paths.
            val subReader = bodyReader
            val subVersion = subReader.readUByte()
            val figure = when (subVersion) {
                2, 3 -> parseStkSubV2V3(subReader, subVersion)
                4, 5 -> parseStkSubV4V5(subReader, subVersion)
                else -> throw IOException("Unknown embedded stk version: $subVersion")
            }
            figures.add(figure)
        }

        // Frame list
        val frameCount = if (version >= 4) bodyReader.readInt32() else bodyReader.readInt16()
        if (frameCount < 0 || frameCount > 100_000) throw IOException("Bad frame count: $frameCount")
        val frames = ArrayList<PivotFrame>(frameCount)
        for (i in 0 until frameCount) {
            frames.add(parseFrame(bodyReader, version, figures))
        }

        // Audio tracks (v5 only)
        val audioTracks = if (version >= 5) parseAudioTracks(bodyReader) else emptyList()

        return PivotProject(
            version = version,
            frameWidth = frameWidth,
            frameHeight = frameHeight,
            backgroundColor = bgColor,
            backgroundImageName = bgName,
            backgroundImageBytes = bgBytes,
            figures = figures,
            frames = frames,
            audioTracks = audioTracks,
        )
    }

    private fun parseFrame(r: PivotBinaryReader, version: Int, figures: List<PivotFigure>): PivotFrame {
        val figCount = if (version >= 4) r.readInt32() else r.readInt16()
        if (figCount < 0 || figCount > 1024) throw IOException("Bad frame figure count: $figCount")
        val figureStates = ArrayList<PivotFigureState>(figCount)
        for (j in 0 until figCount) {
            val figureId = if (version >= 4) r.readInt32() else r.readInt16()
            val x = r.readInt32().toFloat()
            val y = r.readInt32().toFloat()
            val scale = if (version >= 4) r.readFloat() else 1f
            val rotation = if (version >= 4) r.readFloat() else 0f
            val layerDepth = r.readInt16()

            val segCount = if (version >= 4) r.readInt32() else r.readInt16()
            if (segCount < 0 || segCount > 8192) throw IOException("Bad seg count in frame: $segCount")
            val segRotations = FloatArray(segCount)
            for (k in 0 until segCount) {
                segRotations[k] = if (version >= 4) r.readFloat() else r.readInt16().toFloat() / 1000f
            }
            figureStates.add(PivotFigureState(
                figureId = figureId,
                translation = Vec2(x, y),
                scale = scale,
                rotation = rotation,
                layerDepth = layerDepth,
                segmentRotations = segRotations,
            ))
        }
        val marker = if (version >= 4) r.readUtf8String() else ""
        return PivotFrame(figureStates = figureStates, marker = marker)
    }

    private fun parseAudioTracks(r: PivotBinaryReader): List<PivotAudioTrack> {
        val count = r.readInt32()
        if (count < 0 || count > 256) return emptyList()
        val out = ArrayList<PivotAudioTrack>(count)
        for (i in 0 until count) {
            val name = r.readUtf8String()
            val startFrame = r.readInt32()
            val endFrame   = r.readInt32()
            val dataLen = r.readInt32()
            val data = if (dataLen > 0 && dataLen < 50_000_000) r.readBytes(dataLen) else ByteArray(0)
            out.add(PivotAudioTrack(name, startFrame, endFrame, data))
        }
        return out
    }

    // ── Re-routed .stk sub-parsers ───────────────────────────────────────────
    // The .piv parser needs to call into the same .stk parsing routines but
    // cannot re-open the stream. We re-implement the routines here as private
    // helpers so they consume from the existing body reader.
    // ─────────────────────────────────────────────────────────────────────────

    private fun parseStkSubV2V3(r: PivotBinaryReader, version: Int): PivotFigure {
        // Same layout as StkParser.parseV2V3 but without the leading version byte
        val name = r.readNullTerminatedString().ifEmpty { "pivot_v${version}_figure" }
        val nodeCount = r.readInt16()
        if (nodeCount < 0 || nodeCount > 8192) throw IOException("Bad node count: $nodeCount")

        val nodes = ArrayList<PivotNode>(nodeCount)
        var originIdx = -1
        for (i in 0 until nodeCount) {
            val x = r.readInt32().toFloat()
            val y = r.readInt32().toFloat()
            val typeByte = r.readUByte()
            val isOrigin = r.readBoolean()
            if (isOrigin) originIdx = i
            val type = when (typeByte) {
                0 -> PivotNode.NodeType.Regular
                1 -> PivotNode.NodeType.Handle
                2 -> PivotNode.NodeType.Origin
                3 -> PivotNode.NodeType.Circle
                4 -> PivotNode.NodeType.PolygonVertex
                5 -> PivotNode.NodeType.StaticHandle
                else -> PivotNode.NodeType.Regular
            }
            nodes.add(PivotNode(type, x, y, isOrigin))
        }
        if (originIdx >= 0) {
            nodes[originIdx] = nodes[originIdx].copy(type = PivotNode.NodeType.Origin)
        }
        val segCount = r.readInt16()
        if (segCount < 0 || segCount > 8192) throw IOException("Bad segment count: $segCount")

        val segments = ArrayList<PivotSegment>(segCount)
        for (i in 0 until segCount) {
            val a = r.readInt16()
            val b = r.readInt16()
            val colorByte = r.readUByte()
            val thickness = r.readUByte()
            val isDashed = r.readBoolean()
            val isCircle = r.readBoolean()
            segments.add(PivotSegment(
                nodeA = a, nodeB = b,
                color = colorByte.toLong() or 0xFF000000L,
                thickness = thickness,
                isDashed = isDashed,
                isCircle = isCircle,
            ))
        }
        val fillColor    = r.readInt32().toLong() and 0xFFFFFFFFL
        val outlineColor = r.readInt32().toLong() and 0xFFFFFFFFL
        val outlineWidth = r.readInt16()
        val isFilled     = r.readBoolean()
        val isStatic     = if (version >= 3) r.readBoolean() else false

        return PivotFigure(
            version = version, name = name, nodes = nodes, segments = segments,
            fillColor = fillColor, outlineColor = outlineColor,
            outlineWidth = outlineWidth, isFilled = isFilled, isStatic = isStatic,
        )
    }

    private fun parseStkSubV4V5(r: PivotBinaryReader, version: Int): PivotFigure {
        // Note: in a .piv file, the embedded .stk body is NOT independently
        // zlib-compressed (the parent .piv stream already is). So we read
        // the .stk layout directly from `r`.
        val name = try { r.readUtf8String() } catch (_: IOException) {
            r.readNullTerminatedString()
        }.ifEmpty { "pivot_v${version}_figure" }
        val nodeCount = r.readInt32()
        if (nodeCount < 0 || nodeCount > 8192) throw IOException("Bad node count: $nodeCount")

        val nodes = ArrayList<PivotNode>(nodeCount)
        var originIdx = -1
        for (i in 0 until nodeCount) {
            val x = r.readFloat()
            val y = r.readFloat()
            val typeByte = r.readUByte()
            val flags = r.readUByte()
            val isOrigin = (flags and 0x01) != 0
            if (isOrigin) originIdx = i
            val type = when (typeByte) {
                0 -> PivotNode.NodeType.Regular
                1 -> PivotNode.NodeType.Handle
                2 -> PivotNode.NodeType.Origin
                3 -> PivotNode.NodeType.Circle
                4 -> PivotNode.NodeType.PolygonVertex
                5 -> PivotNode.NodeType.StaticHandle
                else -> PivotNode.NodeType.Regular
            }
            nodes.add(PivotNode(type, x, y, isOrigin))
        }
        if (originIdx >= 0) {
            nodes[originIdx] = nodes[originIdx].copy(type = PivotNode.NodeType.Origin)
        }
        val segCount = r.readInt32()
        if (segCount < 0 || segCount > 8192) throw IOException("Bad segment count: $segCount")
        val segments = ArrayList<PivotSegment>(segCount)
        for (i in 0 until segCount) {
            val a = r.readInt32()
            val b = r.readInt32()
            val color = r.readUInt32()
            val thickness = r.readUByte()
            val flags = r.readUByte()
            val isDashed = (flags and 0x01) != 0
            val isCircle = (flags and 0x02) != 0
            segments.add(PivotSegment(
                nodeA = a, nodeB = b, color = color, thickness = thickness,
                isDashed = isDashed, isCircle = isCircle,
            ))
        }
        val fillColor    = r.readUInt32()
        val outlineColor = r.readUInt32()
        val outlineWidth = r.readFloat()
        val isFilled     = r.readBoolean()
        val isStatic     = r.readBoolean()

        val hasRestrictions = if (version >= 5) r.readBoolean() else false
        if (hasRestrictions) {
            for (i in 0 until segCount) {
                r.readInt16() // restriction angle, currently unused
            }
        }
        val metadata = if (version >= 5 && r.available() > 4) {
            val pairs = r.readInt32()
            val out = HashMap<String, String>(pairs.coerceAtLeast(0))
            for (i in 0 until pairs.coerceAtLeast(0)) {
                val k = r.readUtf8String()
                val v = r.readUtf8String()
                out[k] = v
            }
            out
        } else emptyMap()

        return PivotFigure(
            version = version, name = name, nodes = nodes, segments = segments,
            fillColor = fillColor, outlineColor = outlineColor,
            outlineWidth = outlineWidth.toInt(), isFilled = isFilled,
            isStatic = isStatic, metadata = metadata,
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Public data model
// ─────────────────────────────────────────────────────────────────────────────

data class PivotProject(
    val version: Int,
    val frameWidth: Int,
    val frameHeight: Int,
    val backgroundColor: Long,
    val backgroundImageName: String,
    val backgroundImageBytes: ByteArray,
    val figures: List<PivotFigure>,
    val frames: List<PivotFrame>,
    val audioTracks: List<PivotAudioTrack>,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PivotProject) return false
        return version == other.version &&
                frameWidth == other.frameWidth &&
                frameHeight == other.frameHeight &&
                backgroundColor == other.backgroundColor &&
                backgroundImageName == other.backgroundImageName &&
                figures == other.figures &&
                frames == other.frames
    }
    override fun hashCode(): Int {
        var result = version
        result = 31 * result + frameWidth
        result = 31 * result + frameHeight
        result = 31 * result + backgroundColor.hashCode()
        result = 31 * result + backgroundImageName.hashCode()
        result = 31 * result + figures.hashCode()
        result = 31 * result + frames.hashCode()
        return result
    }
}

data class PivotFrame(
    val figureStates: List<PivotFigureState>,
    val marker: String = "",
)

data class PivotFigureState(
    val figureId: Int,
    val translation: Vec2,
    val scale: Float,
    val rotation: Float,
    val layerDepth: Int,
    val segmentRotations: FloatArray,
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is PivotFigureState) return false
        return figureId == other.figureId &&
                translation == other.translation &&
                scale == other.scale &&
                rotation == other.rotation &&
                layerDepth == other.layerDepth &&
                segmentRotations.contentEquals(other.segmentRotations)
    }
    override fun hashCode(): Int {
        var r = figureId
        r = 31 * r + translation.hashCode()
        r = 31 * r + scale.hashCode()
        r = 31 * r + rotation.hashCode()
        r = 31 * r + layerDepth
        r = 31 * r + segmentRotations.contentHashCode()
        return r
    }
}

data class PivotAudioTrack(
    val name: String,
    val startFrame: Int,
    val endFrame: Int,
    val audioBytes: ByteArray,
)
