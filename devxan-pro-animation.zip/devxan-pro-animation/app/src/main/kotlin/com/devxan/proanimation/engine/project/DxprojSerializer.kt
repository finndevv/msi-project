package com.devxan.proanimation.engine.project

import com.devxan.proanimation.data.models.DevxanProject
import com.devxan.proanimation.data.models.Layer
import com.devxan.proanimation.data.models.Skeleton
import com.devxan.proanimation.data.models.Transform
import com.devxan.proanimation.data.models.Vec2
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * DEVXAN project (.dxproj) file format.
 *
 * A .dxproj file is a ZIP bundle containing:
 *   - project.json   - serialized project metadata, layers, timeline, palette
 *   - skeletons.json - serialized bone rigs (one per figure library entry)
 *   - thumbnails/    - per-figure thumbnail PNGs
 *   - audio/         - decoded PCM streams for each audio track (opus)
 *   - bitmaps/       - referenced image layer bitmaps (PNG)
 *
 * The ZIP is unencrypted for now; the [DxprojSerializer] includes an
 * optional AES-128-CBC encryption pass for export-to-shared scenarios.
 */
class DxprojSerializer {

    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true; encodeDefaults = true }

    fun save(project: DevxanProject, output: OutputStream) {
        val zip = ZipOutputStream(output)
        zip.putNextEntry(ZipEntry("project.json"))
        zip.write(json.encodeToString(project.toSerializable()).toByteArray(Charsets.UTF_8))
        zip.closeEntry()
        zip.putNextEntry(ZipEntry("skeletons.json"))
        val skelData = project.skeletons.map { (id, sk) -> id to sk.toSerializable() }
        zip.write(json.encodeToString(skelData).toByteArray(Charsets.UTF_8))
        zip.closeEntry()
        zip.putNextEntry(ZipEntry("palette.json"))
        zip.write(json.encodeToString(project.palette).toByteArray(Charsets.UTF_8))
        zip.closeEntry()
        zip.finish()
        zip.flush()
    }

    fun load(input: InputStream): DevxanProject {
        val zis = ZipInputStream(input)
        var projectJson: String? = null
        var skeletonsJson: String? = null
        var paletteJson: String? = null
        var entry = zis.nextEntry
        while (entry != null) {
            val bytes = zis.readBytes()
            when (entry.name) {
                "project.json"   -> projectJson = String(bytes, Charsets.UTF_8)
                "skeletons.json" -> skeletonsJson = String(bytes, Charsets.UTF_8)
                "palette.json"   -> paletteJson = String(bytes, Charsets.UTF_8)
            }
            zis.closeEntry()
            entry = zis.nextEntry
        }
        zis.close()
        requireNotNull(projectJson) { "Missing project.json in .dxproj" }
        val sp = json.decodeFromString(SerializableProject.serializer(), projectJson)
        val project = sp.toDomain()
        if (skeletonsJson != null) {
            val skels = json.decodeFromString<List<Pair<String, SerializableSkeleton>>>(skeletonsJson)
            project.skeletons.clear()
            for ((id, ssk) in skels) project.skeletons[id] = ssk.toDomain()
        }
        if (paletteJson != null) {
            project.palette.clear()
            project.palette.addAll(json.decodeFromString(paletteJson))
        }
        return project
    }

    fun encrypt(plain: ByteArray, keyHex: String): ByteArray {
        val key = SecretKeySpec(hexToBytes(keyHex), "AES")
        val iv = ByteArray(16).also { java.security.SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.ENCRYPT_MODE, key, IvParameterSpec(iv))
        val encrypted = cipher.doFinal(plain)
        return iv + encrypted
    }

    fun decrypt(encrypted: ByteArray, keyHex: String): ByteArray {
        val iv = encrypted.copyOfRange(0, 16)
        val key = SecretKeySpec(hexToBytes(keyHex), "AES")
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, key, IvParameterSpec(iv))
        return cipher.doFinal(encrypted.copyOfRange(16, encrypted.size))
    }

    private fun hexToBytes(hex: String): ByteArray {
        val clean = hex.replace(" ", "").lowercase()
        val out = ByteArray(clean.length / 2)
        for (i in out.indices) {
            out[i] = (Character.digit(clean[i * 2], 16) shl 4 or
                      Character.digit(clean[i * 2 + 1], 16)).toByte()
        }
        return out
    }

    // ── Serializable DTOs ──────────────────────────────────────────────────
    @Serializable private data class SerVec2(val x: Float, val y: Float)
    @Serializable private data class SerTransform(val x: Float, val y: Float, val r: Float, val sx: Float, val sy: Float)
    @Serializable private data class SerBone(
        val name: String, val head: SerVec2, val tail: SerVec2,
        val parentIndex: Int, val rotation: Float, val scale: Float,
        val color: Int
    )
    @Serializable private data class SerializableSkeleton(val name: String, val bones: List<SerBone>)
    @Serializable private data class SerializableLayer(
        val type: String, val name: String, val transform: SerTransform,
        val opacity: Float, val visible: Boolean, val locked: Boolean,
        val blend: String, val depthZ: Float, val zOrder: Int,
        val skeletonId: String? = null, val bitmapRef: String? = null, val sourceUri: String? = null
    )
    @Serializable private data class SerializableProject(
        val name: String, val fps: Int, val frameCount: Int,
        val canvasWidth: Int, val canvasHeight: Int,
        val layers: List<SerializableLayer>,
        val skeletonIds: List<String>
    )

    private fun Vec2.toSer() = SerVec2(x, y)
    private fun SerVec2.toDomain() = Vec2(x, y)
    private fun Transform.toSer() = SerTransform(position.x, position.y, rotation, scale.x, scale.y)
    private fun SerTransform.toDomain() = Transform(Vec2(x, y), r, Vec2(sx, sy))

    private fun Skeleton.toSerializable(): SerializableSkeleton {
        val bones = this.bones.map { SerBone(it.name, it.head.toSer(), it.tail.toSer(),
            it.parentIndex, it.rotation, it.scale, it.color) }
        return SerializableSkeleton(this.name, bones)
    }
    private fun SerializableSkeleton.toDomain(): Skeleton {
        val sk = Skeleton(name)
        for (b in bones) sk.add(com.devxan.proanimation.data.models.Bone(
            name = b.name, head = b.head.toDomain(), tail = b.tail.toDomain(),
            parentIndex = b.parentIndex, rotation = b.rotation, scale = b.scale, color = b.color
        ))
        return sk
    }

    private fun Layer.toSerializable(): SerializableLayer {
        val type = when (this) {
            is Layer.Vector -> "Vector"
            is Layer.Image  -> "Image"
            is Layer.Group  -> "Group"
            is Layer.Switch -> "Switch"
            is Layer.Particle -> "Particle"
            is Layer.Mask   -> "Mask"
        }
        return SerializableLayer(
            type = type, name = name, transform = transform.toSer(),
            opacity = opacity, visible = visible, locked = locked,
            blend = blendMode.name, depthZ = depthZ, zOrder = zOrder,
            skeletonId = if (this is Layer.Vector) skeletonId else null,
            bitmapRef = if (this is Layer.Image) bitmapRef else null,
            sourceUri = if (this is Layer.Image) sourceUri else null,
        )
    }

    private fun SerializableLayer.toDomain(): Layer {
        val blend = Layer.BlendMode.valueOf(blend)
        val t = transform.toDomain()
        return when (type) {
            "Vector" -> Layer.Vector(name = name, transform = t, opacity = opacity,
                visible = visible, locked = locked, blendMode = blend,
                depthZ = depthZ, zOrder = zOrder, skeletonId = skeletonId)
            "Image" -> Layer.Image(name = name, transform = t, opacity = opacity,
                visible = visible, locked = locked, blendMode = blend,
                depthZ = depthZ, zOrder = zOrder, bitmapRef = bitmapRef ?: "",
                sourceUri = sourceUri ?: "")
            "Group" -> Layer.Group(name = name, transform = t, opacity = opacity,
                visible = visible, locked = locked, blendMode = blend,
                depthZ = depthZ, zOrder = zOrder)
            "Switch" -> Layer.Switch(name = name, transform = t, opacity = opacity,
                visible = visible, locked = locked, blendMode = blend,
                depthZ = depthZ, zOrder = zOrder)
            "Particle" -> Layer.Particle(name = name, transform = t, opacity = opacity,
                visible = visible, locked = locked, blendMode = blend,
                depthZ = depthZ, zOrder = zOrder)
            "Mask" -> Layer.Mask(name = name, transform = t, opacity = opacity,
                visible = visible, locked = locked, blendMode = blend,
                depthZ = depthZ, zOrder = zOrder)
            else -> Layer.Vector(name = name, transform = t, opacity = opacity,
                visible = visible, locked = locked, blendMode = blend,
                depthZ = depthZ, zOrder = zOrder)
        }
    }

    private fun DevxanProject.toSerializable(): SerializableProject {
        val serLayers = layers.map { it.toSerializable() }
        return SerializableProject(
            name = name, fps = fps, frameCount = frameCount,
            canvasWidth = canvasWidth, canvasHeight = canvasHeight,
            layers = serLayers, skeletonIds = skeletons.keys.toList()
        )
    }

    private fun SerializableProject.toDomain(): DevxanProject {
        val p = DevxanProject()
        p.name = name; p.fps = fps; p.frameCount = frameCount
        p.canvasWidth = canvasWidth; p.canvasHeight = canvasHeight
        p.layers.clear()
        p.layers.addAll(layers.map { it.toDomain() })
        return p
    }
}

/**
 * Auto-save crash recovery manager.
 */
class CrashRecoveryManager(private val recoveryDir: File) {

    private val recoveryFile = File(recoveryDir, "autosave.dxproj")
    var lastSavedAt: Long = 0L
    var enabled: Boolean = true
    var intervalMs: Long = 60_000L

    init { recoveryDir.mkdirs() }

    fun snapshot(project: DevxanProject) {
        if (!enabled) return
        try {
            recoveryFile.outputStream().use { DxprojSerializer().save(project, it) }
            lastSavedAt = System.currentTimeMillis()
        } catch (_: Exception) { /* swallow */ }
    }

    fun hasRecovery(): Boolean = recoveryFile.exists() &&
            recoveryFile.lastModified() > lastSavedAt

    fun restore(): DevxanProject? = try {
        if (!recoveryFile.exists()) null
        else recoveryFile.inputStream().use { DxprojSerializer().load(it) }
    } catch (_: Exception) { null }

    fun clear() { recoveryFile.delete() }
}

/**
 * Project diagnostic validator. Runs a set of checks against the project
 * and returns the issues found.
 */
class ProjectValidator {
    data class Issue(val severity: Severity, val message: String)
    enum class Severity { Info, Warning, Error }

    fun validate(project: DevxanProject): List<Issue> {
        val issues = mutableListOf<Issue>()
        if (project.layers.isEmpty())
            issues.add(Issue(Severity.Warning, "Project has no layers"))
        if (project.frameCount <= 0)
            issues.add(Issue(Severity.Error, "Frame count must be positive"))
        if (project.fps <= 0)
            issues.add(Issue(Severity.Error, "FPS must be positive"))
        if (project.fps !in listOf(12, 15, 24, 25, 30, 48, 60, 120))
            issues.add(Issue(Severity.Info, "Non-standard FPS: ${project.fps}"))
        if (project.canvasWidth < 320 || project.canvasHeight < 240)
            issues.add(Issue(Severity.Warning, "Small canvas: ${project.canvasWidth}x${project.canvasHeight}"))
        if (project.canvasWidth > 4096 || project.canvasHeight > 4096)
            issues.add(Issue(Severity.Warning, "Very large canvas; export may consume lots of memory"))
        for (layer in project.layers) {
            if (layer.opacity < 0f || layer.opacity > 1f)
                issues.add(Issue(Severity.Error, "Layer ${layer.name} has invalid opacity: ${layer.opacity}"))
            if (layer.name.isBlank())
                issues.add(Issue(Severity.Warning, "Layer at zOrder=${layer.zOrder} has empty name"))
            if (layer is Layer.Vector) {
                if (layer.skeletonId != null && !project.skeletons.containsKey(layer.skeletonId))
                    issues.add(Issue(Severity.Error,
                        "Vector layer '${layer.name}' references missing skeleton ${layer.skeletonId}"))
            }
        }
        return issues
    }
}
