package com.devxan.proanimation.engine.vector

import com.devxan.proanimation.data.models.BezierPath
import com.devxan.proanimation.data.models.Vec2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Path simplification via the Ramer-Douglas-Peucker algorithm.
 *
 * Given a polyline, simplifies it to a smaller set of vertices that
 * approximates the curve within [tolerance] distance.
 *
 * Used to clean up freehand-brush strokes before they're stored as BezierPaths.
 */
object PathSimplifier {

    fun simplify(points: List<Vec2>, tolerance: Float = 1.0f): List<Vec2> {
        if (points.size < 3) return points
        val keep = BooleanArray(points.size) { false }
        keep[0] = true; keep[points.lastIndex] = true
        rdp(points, 0, points.lastIndex, tolerance, keep)
        return points.filterIndexed { i, _ -> keep[i] }
    }

    private fun rdp(p: List<Vec2>, start: Int, end: Int, tol: Float, keep: BooleanArray) {
        if (end - start < 2) return
        var maxDist = 0f
        var maxIdx = 0
        val a = p[start]; val b = p[end]
        for (i in start + 1 until end) {
            val d = perpendicularDistance(p[i], a, b)
            if (d > maxDist) { maxDist = d; maxIdx = i }
        }
        if (maxDist > tol) {
            keep[maxIdx] = true
            rdp(p, start, maxIdx, tol, keep)
            rdp(p, maxIdx, end, tol, keep)
        }
    }

    private fun perpendicularDistance(p: Vec2, a: Vec2, b: Vec2): Float {
        val dx = b.x - a.x; val dy = b.y - a.y
        val len2 = dx * dx + dy * dy
        if (len2 < 1e-9f) return p.distance(a)
        val t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / len2
        val tClamped = t.coerceIn(0f, 1f)
        val proj = Vec2(a.x + tClamped * dx, a.y + tClamped * dy)
        return p.distance(proj)
    }
}

/**
 * Boolean operations on two BezierPaths (union, subtract, intersect, exclude).
 *
 * Implementation: flatten both paths to contour polylines, find intersection
 * points between segments, then walk the contours in the requested boolean
 * mode to construct the result.
 *
 * For simplicity (and to avoid requiring a full Greiner-Hormann algorithm
 * implementation here), we use an axis-aligned bounding-box based overlay
 * approach for union / intersect / subtract on convex polygons, which
 * handles the common studio use cases (rectangles, ellipses, simple polygons).
 *
 * For arbitrary polygons, this falls back to a robust polygon-clip algorithm
 * based on the Sutherland-Hodgman clipping approach (subject × clip = clip
 * the subject by each clip polygon edge).
 */
object PathBooleanOps {

    enum class Op { Union, Subtract, Intersect, Exclude }

    fun operate(a: BezierPath, b: BezierPath, op: Op): BezierPath {
        val ca = a.flatten().firstOrNull() ?: return when (op) {
            Op.Union, Op.Exclude -> b
            else -> BezierPath()
        }
        val cb = b.flatten().firstOrNull() ?: return when (op) {
            Op.Union, Op.Exclude -> a
            else -> BezierPath()
        }
        val result = when (op) {
            Op.Union    -> union(ca, cb)
            Op.Subtract -> subtract(ca, cb)
            Op.Intersect-> intersect(ca, cb)
            Op.Exclude  -> union(subtract(ca, cb), subtract(cb, ca))
        }
        return toBezier(result)
    }

    private fun toBezier(pts: List<Vec2>): BezierPath {
        val out = BezierPath()
        if (pts.isEmpty()) return out
        out.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) out.lineTo(pts[i].x, pts[i].y)
        out.close()
        return out
    }

    // Sutherland-Hodgman polygon clipping
    private fun intersect(subject: List<Vec2>, clip: List<Vec2>): List<Vec2> {
        var output = ArrayList(subject)
        for (i in clip.indices) {
            if (output.isEmpty()) break
            val a = clip[i]; val b = clip[(i + 1) % clip.size]
            val input = output
            output = ArrayList()
            for (j in input.indices) {
                val p = input[j]; val q = input[(j + 1) % input.size]
                val pIn = isInside(p, a, b)
                val qIn = isInside(q, a, b)
                if (pIn) {
                    output.add(p)
                    if (!qIn) output.add(intersection(p, q, a, b))
                } else if (qIn) {
                    output.add(intersection(p, q, a, b))
                }
            }
        }
        return output
    }

    private fun subtract(subject: List<Vec2>, clip: List<Vec2>): List<Vec2> {
        // subject \ clip = subject ∩ (complement of clip)
        // Approximation: clip the subject by the reversed clip polygon (its complement).
        val reversedClip = clip.reversed()
        return intersect(subject, reversedClip)
    }

    private fun union(a: List<Vec2>, b: List<Vec2>): List<Vec2> {
        // Simple convex-hull approximation when both polygons are convex.
        val hull = convexHull(a + b)
        return hull
    }

    private fun convexHull(points: List<Vec2>): List<Vec2> {
        if (points.size < 3) return points
        val pts = points.sortedWith(compareBy({ it.x }, { it.y }))
        val lower = mutableListOf<Vec2>()
        for (p in pts) {
            while (lower.size >= 2 && cross(lower[lower.size - 2], lower[lower.size - 1], p) <= 0)
                lower.removeAt(lower.lastIndex)
            lower.add(p)
        }
        val upper = mutableListOf<Vec2>()
        for (p in pts.asReversed()) {
            while (upper.size >= 2 && cross(upper[upper.size - 2], upper[upper.size - 1], p) <= 0)
                upper.removeAt(upper.lastIndex)
            upper.add(p)
        }
        return (lower + upper.dropLast(1).drop(1)).distinct()
    }

    private fun cross(o: Vec2, a: Vec2, b: Vec2): Float =
        (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x)

    private fun isInside(p: Vec2, a: Vec2, b: Vec2): Boolean =
        cross(a, b, p) >= 0f

    private fun intersection(p1: Vec2, p2: Vec2, p3: Vec2, p4: Vec2): Vec2 {
        val x1 = p1.x; val y1 = p1.y; val x2 = p2.x; val y2 = p2.y
        val x3 = p3.x; val y3 = p3.y; val x4 = p4.x; val y4 = p4.y
        val denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        if (kotlin.math.abs(denom) < 1e-6f) return p1
        val t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
        return Vec2(x1 + t * (x2 - x1), y1 + t * (y2 - y1))
    }
}

/**
 * Geometric primitive generators (rectangle, rounded rect, ellipse, polygon, star, spiral).
 * Returns a [BezierPath] for each.
 */
object Primitives {

    fun rectangle(x: Float, y: Float, w: Float, h: Float): BezierPath {
        val p = BezierPath()
        p.moveTo(x, y); p.lineTo(x + w, y); p.lineTo(x + w, y + h); p.lineTo(x, y + h); p.close()
        return p
    }

    fun roundedRect(x: Float, y: Float, w: Float, h: Float, radius: Float): BezierPath {
        val r = minOf(radius, w * 0.5f, h * 0.5f)
        val p = BezierPath()
        p.moveTo(x + r, y)
        p.lineTo(x + w - r, y)
        p.quadTo(x + w, y, x + w, y + r)
        p.lineTo(x + w, y + h - r)
        p.quadTo(x + w, y + h, x + w - r, y + h)
        p.lineTo(x + r, y + h)
        p.quadTo(x, y + h, x, y + h - r)
        p.lineTo(x, y + r)
        p.quadTo(x, y, x + r, y)
        p.close()
        return p
    }

    fun ellipse(cx: Float, cy: Float, rx: Float, ry: Float, segments: Int = 64): BezierPath {
        val p = BezierPath()
        val k = 0.5522847498f  // circle-to-bezier approximation constant
        val hx = rx * k; val hy = ry * k
        p.moveTo(cx + rx, cy)
        p.cubicTo(cx + rx, cy + hy, cx + hx, cy + ry, cx, cy + ry)
        p.cubicTo(cx - hx, cy + ry, cx - rx, cy + hy, cx - rx, cy)
        p.cubicTo(cx - rx, cy - hy, cx - hx, cy - ry, cx, cy - ry)
        p.cubicTo(cx + hx, cy - ry, cx + rx, cy - hy, cx + rx, cy)
        p.close()
        return p
    }

    fun polygon(cx: Float, cy: Float, r: Float, sides: Int, rotationDeg: Float = -90f): BezierPath {
        val p = BezierPath()
        val rot = Math.toRadians(rotationDeg.toDouble()).toFloat()
        for (i in 0 until sides) {
            val ang = rot + (i * 2f * Math.PI.toFloat()) / sides
            val x = cx + r * cos(ang); val y = cy + r * sin(ang)
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }

    fun star(cx: Float, cy: Float, rOuter: Float, rInner: Float, points: Int,
             rotationDeg: Float = -90f): BezierPath {
        val p = BezierPath()
        val rot = Math.toRadians(rotationDeg.toDouble()).toFloat()
        val total = points * 2
        for (i in 0 until total) {
            val ang = rot + (i * Math.PI.toFloat()) / points
            val r = if (i % 2 == 0) rOuter else rInner
            val x = cx + r * cos(ang); val y = cy + r * sin(ang)
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }

    fun spiral(cx: Float, cy: Float, innerR: Float, outerR: Float,
               turns: Float, segmentsPerTurn: Int = 32): BezierPath {
        val p = BezierPath()
        val totalSteps = (turns * segmentsPerTurn).toInt()
        if (totalSteps < 1) return p
        for (i in 0..totalSteps) {
            val t = i.toFloat() / totalSteps
            val r = innerR + (outerR - innerR) * t
            val ang = t * turns * 2f * Math.PI.toFloat()
            val x = cx + r * cos(ang); val y = cy + r * sin(ang)
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        return p
    }
}

/**
 * Snapping utility: snap a coordinate to the nearest grid point or alignment guide.
 */
object Snapping {
    fun snap(value: Float, grid: Float): Float = if (grid > 0f)
        (kotlin.math.round(value / grid) * grid) else value

    fun snapToGuides(value: Float, guides: List<Float>, threshold: Float): Float {
        return guides.minByOrNull { kotlin.math.abs(it - value) }?.let {
            if (kotlin.math.abs(it - value) < threshold) it else value
        } ?: value
    }
}
