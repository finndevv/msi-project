package com.devxan.proanimation.engine.bones

import com.devxan.proanimation.data.models.AffineTransform
import com.devxan.proanimation.data.models.Bone
import com.devxan.proanimation.data.models.BoneWorldPose
import com.devxan.proanimation.data.models.ForwardKinematics
import com.devxan.proanimation.data.models.Skeleton
import com.devxan.proanimation.data.models.Transform
import com.devxan.proanimation.data.models.Vec2
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Automatic skinning: assigns each vertex to a set of nearby bones with
 * weights proportional to distance (linear blend skinning).
 *
 * Supports:
 *  - Rigid binding (one bone per vertex, the strongest)
 *  - Flexi-binding  (N bones per vertex, blended by weight)
 *  - Manual binding overrides (per-vertex bone assignments)
 */
class AutoRigger(val skeleton: Skeleton, val maxBonesPerVertex: Int = 4) {

    data class VertexBinding(
        val boneIndices: IntArray,
        val weights: FloatArray,
    )

    /**
     * Build skinning weights for a vertex cloud.
     *
     * @param vertexPositions list of (vertexIndex -> rest position in skeleton-local space)
     * @param manualOverrides override table: vertex index -> list of (boneIndex, weight)
     */
    fun buildWeights(
        vertexPositions: List<Vec2>,
        manualOverrides: Map<Int, List<Pair<Int, Float>>> = emptyMap()
    ): List<VertexBinding> = vertexPositions.mapIndexed { vIdx, pos ->
        manualOverrides[vIdx]?.let { manual ->
            val totalW = manual.sumOf { it.second.toDouble() }.toFloat().coerceAtLeast(1e-6f)
            val bones = manual.map { it.first }.toIntArray()
            val w = manual.map { it.second / totalW }.toFloatArray()
            return@mapIndexed VertexBinding(bones, w)
        }

        val fk = ForwardKinematics(skeleton)
        val poses = fk.solve()
        val boneCenterDistances = poses.mapIndexed { idx, pose ->
            val center = (pose.headWorld + pose.tailWorld) * 0.5f
            val dist = pos.distance(center)
            idx to dist
        }

        val topBones = boneCenterDistances.sortedBy { it.second }.take(maxBonesPerVertex)
        val totalW = topBones.sumOf { 1.0 / (1.0 + it.second.toDouble()) }
        val weights = topBones.map { (1.0 / (1.0 + it.second.toDouble()) / totalW).toFloat() }
        VertexBinding(topBones.map { it.first }.toIntArray(), weights.toFloatArray())
    }

    /**
     * Apply Linear Blend Skinning to a vertex given bindings + current poses.
     */
    fun lbs(restPos: Vec2, binding: VertexBinding, poses: List<BoneWorldPose>): Vec2 {
        var sumX = 0f; var sumY = 0f
        var sumW = 0f
        for (i in binding.boneIndices.indices) {
            val boneIdx = binding.boneIndices[i]
            if (boneIdx < 0 || boneIdx >= poses.size) continue
            val w = binding.weights[i]
            val pose = poses[boneIdx]
            // Skin transform = inverse(bone rest) * current pose, applied to rest pos
            val boneRest = skeleton[boneIdx]
            val restTransform = AffineTransform.translate(boneRest.head).rotate(boneRest.restAngle)
            val inverseRest = restTransform.inverse()
            val localRest = inverseRest.transform(restPos)
            val skinned = pose.worldTransform.transform(localRest)
            sumX += skinned.x * w
            sumY += skinned.y * w
            sumW += w
        }
        return if (sumW > 1e-6f) Vec2(sumX / sumW, sumY / sumW) else restPos
    }
}

/**
 * Smart-warp mesh cage: a triangulated grid whose vertices are skinned to
 * bones for organic deformation (e.g., torso breathing, facial expressions).
 */
class SmartWarpMesh(
    val gridX: Int = 16,
    val gridY: Int = 16,
    val bounds: com.devxan.proanimation.data.models.Rect,
) {
    val vertices: List<Vec2> = buildList {
        for (j in 0 until gridY) for (i in 0 until gridX) {
            val x = bounds.x + bounds.w * i.toFloat() / (gridX - 1)
            val y = bounds.y + bounds.h * j.toFloat() / (gridY - 1)
            add(Vec2(x, y))
        }
    }

    val triangles: IntArray = buildList {
        for (j in 0 until (gridY - 1)) for (i in 0 until (gridX - 1)) {
            val a = j * gridX + i
            val b = j * gridX + i + 1
            val c = (j + 1) * gridX + i
            val d = (j + 1) * gridX + i + 1
            add(a); add(c); add(b)
            add(b); add(c); add(d)
        }
    }.toIntArray()

    fun deform(rigger: AutoRigger, bindings: List<AutoRigger.VertexBinding>,
               poses: List<BoneWorldPose>): List<Vec2> =
        vertices.mapIndexed { idx, v -> rigger.lbs(v, bindings[idx], poses) }
}
