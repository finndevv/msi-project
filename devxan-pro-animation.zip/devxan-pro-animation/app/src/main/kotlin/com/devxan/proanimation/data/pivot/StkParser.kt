package com.devxan.proanimation.data.pivot

import com.devxan.proanimation.data.models.Bone
import com.devxan.proanimation.data.models.Skeleton
import java.io.IOException
import java.io.InputStream

/**
 * Native .stk (Pivot Animator figure) parser supporting versions 2, 3, 4, and 5.
 *
 * The .stk format is structured as:
 *
 *   v2/v3 layout (uncompressed text-friendly binary):
 *     - magic byte (version major)
 *     - figure type string (null-terminated, ASCII)
 *     - Int16 node count
 *     - Per node: 2x Int32 (x, y), 1 byte type, 1 byte isOrigin
 *     - Int16 segment count
 *     - Per segment: 2x Int16 (nodeA, nodeB), 1 byte color, 1 byte thickness
 *     - Int32 fill color, Int32 outline color, Int16 outline width, 1 byte isFilled
 *
 *   v4/v5 layout (compressed body):
 *     - magic byte (4 or 5)
 *     - Int32 uncompressed length
 *     - zlib-compressed stream of:
 *       - Utf8String figure type
 *       - Int32 node count, Per node: 2x Float32 (x, y), 1 byte type, 1 byte flags
 *       - Int32 segment count, Per segment: 2x Int32, 1 byte color, 1 byte thickness
 *       - Int64 fill color (RGBA), Int64 outline color, Float32 outline width
 *       - 1 byte isFilled, 1 byte isStatic, 1 byte hasRestrictions
 *       - If hasRestrictions: per-segment Int16 restrictionAngle
 *     - Optional metadata block (key/value pairs at the end)
 *
 * We tolerate reasonable format variations - real-world Pivot files can mix
 * Int16 and Int32 sizing depending on platform build.
 */
class StkParser {

    /**
     * Parses a .stk figure file from the given InputStream.
     * Returns the converted DEVXAN skeleton + the raw figure data.
     */
    fun parse(stream: InputStream): ParseResult {
        val outer = PivotBinaryReader(stream)
        val version = outer.readUByte()
        if (version !in listOf(2, 3, 4, 5)) {
            throw IOException("Unsupported .stk version: $version")
        }

        val figure: PivotFigure = when (version) {
            2, 3 -> parseV2V3(outer, version)
            4, 5 -> parseV4V5(outer, version)
            else -> throw IOException("Version $version not implemented")
        }
        val skeleton = figure.toSkeleton()
        return ParseResult(figure, skeleton)
    }

    data class ParseResult(
        val figure: PivotFigure,
        val skeleton: Skeleton,
    )

    private fun parseV2V3(r: PivotBinaryReader, version: Int): PivotFigure {
        // v2/v3 figures are stored uncompressed with the original 8-bit per node layout
        val name = r.readNullTerminatedString().ifEmpty { "pivot_v${version}_figure" }
        val nodeCount = r.readInt16()
        if (nodeCount < 0 || nodeCount > 8192) throw IOException("Bad node count: $nodeCount")

        val nodes = ArrayList<PivotNode>(nodeCount)
        var originIdx = -1
        for (i in 0 until nodeCount) {
            val x = r.readInt32().toFloat()
            val y = r.readInt32().toFloat()
            val typeByte = r.readUByte()
            val isOrigin = r.readBoolean()
            if (isOrigin) originIdx = i
            val type = when (typeByte) {
                0 -> PivotNode.NodeType.Regular
                1 -> PivotNode.NodeType.Handle
                2 -> PivotNode.NodeType.Origin
                3 -> PivotNode.NodeType.Circle
                4 -> PivotNode.NodeType.PolygonVertex
                5 -> PivotNode.NodeType.StaticHandle
                else -> PivotNode.NodeType.Regular
            }
            nodes.add(PivotNode(type, x, y, isOrigin))
        }
        if (originIdx >= 0 && nodes[originIdx].type != PivotNode.NodeType.Origin) {
            nodes[originIdx] = nodes[originIdx].copy(type = PivotNode.NodeType.Origin)
        }

        val segCount = r.readInt16()
        if (segCount < 0 || segCount > 8192) throw IOException("Bad segment count: $segCount")

        val segments = ArrayList<PivotSegment>(segCount)
        for (i in 0 until segCount) {
            val a = r.readInt16()
            val b = r.readInt16()
            val colorByte = r.readUByte()
            val thickness = r.readUByte()
            val isDashed = r.readBoolean()
            val isCircle = r.readBoolean()
            segments.add(PivotSegment(
                nodeA = a, nodeB = b,
                color = colorByte.toLong() or 0xFF000000L,
                thickness = thickness,
                isDashed = isDashed,
                isCircle = isCircle,
            ))
        }

        val fillColor   = r.readInt32().toLong() and 0xFFFFFFFFL
        val outlineColor= r.readInt32().toLong() and 0xFFFFFFFFL
        val outlineWidth= r.readInt16()
        val isFilled    = r.readBoolean()
        val isStatic    = if (version >= 3) r.readBoolean() else false

        return PivotFigure(
            version = version,
            name = name,
            nodes = nodes,
            segments = segments,
            fillColor = fillColor,
            outlineColor = outlineColor,
            outlineWidth = outlineWidth,
            isFilled = isFilled,
            isStatic = isStatic,
        )
    }

    private fun parseV4V5(r: PivotBinaryReader, version: Int): PivotFigure {
        // Read the zlib-compressed body
        val inner = r.readZlibBody()
        val name = try { inner.readUtf8String() } catch (_: IOException) {
            inner.readNullTerminatedString()
        }.ifEmpty { "pivot_v${version}_figure" }

        val nodeCount = inner.readInt32()
        if (nodeCount < 0 || nodeCount > 8192) throw IOException("Bad node count: $nodeCount")

        val nodes = ArrayList<PivotNode>(nodeCount)
        var originIdx = -1
        for (i in 0 until nodeCount) {
            val x = inner.readFloat()
            val y = inner.readFloat()
            val typeByte = inner.readUByte()
            val flags = inner.readUByte()
            val isOrigin = (flags and 0x01) != 0
            if (isOrigin) originIdx = i
            val type = when (typeByte) {
                0 -> PivotNode.NodeType.Regular
                1 -> PivotNode.NodeType.Handle
                2 -> PivotNode.NodeType.Origin
                3 -> PivotNode.NodeType.Circle
                4 -> PivotNode.NodeType.PolygonVertex
                5 -> PivotNode.NodeType.StaticHandle
                else -> PivotNode.NodeType.Regular
            }
            nodes.add(PivotNode(type, x, y, isOrigin))
        }
        if (originIdx >= 0 && nodes[originIdx].type != PivotNode.NodeType.Origin) {
            nodes[originIdx] = nodes[originIdx].copy(type = PivotNode.NodeType.Origin)
        }

        val segCount = inner.readInt32()
        if (segCount < 0 || segCount > 8192) throw IOException("Bad segment count: $segCount")
        val segments = ArrayList<PivotSegment>(segCount)
        for (i in 0 until segCount) {
            val a = inner.readInt32()
            val b = inner.readInt32()
            val color = inner.readUInt32()
            val thickness = inner.readUByte()
            val flags = inner.readUByte()
            val isDashed = (flags and 0x01) != 0
            val isCircle = (flags and 0x02) != 0
            segments.add(PivotSegment(
                nodeA = a, nodeB = b,
                color = color,
                thickness = thickness,
                isDashed = isDashed,
                isCircle = isCircle,
            ))
        }

        val fillColor    = inner.readUInt32()
        val outlineColor = inner.readUInt32()
        val outlineWidth = inner.readFloat()
        val isFilled     = inner.readBoolean()
        val isStatic     = inner.readBoolean()

        val hasRestrictions = if (version >= 5) inner.readBoolean() else false
        if (hasRestrictions) {
            // Per-segment restriction angle - apply to bone constraints later
            for (i in 0 until segCount) {
                val restrictionDeg = inner.readInt16()
                if (i < segments.size) {
                    // We don't store restrictions in the PivotSegment model itself;
                    // the consumer (toSkeleton) can apply them later if needed.
                }
            }
        }

        // Optional metadata block (v5+)
        val metadata = if (version >= 5 && inner.available() > 4) {
            val pairs = inner.readInt32()
            val out = HashMap<String, String>(pairs)
            for (i in 0 until pairs) {
                val k = inner.readUtf8String()
                val v = inner.readUtf8String()
                out[k] = v
            }
            out
        } else emptyMap()

        return PivotFigure(
            version = version,
            name = name,
            nodes = nodes,
            segments = segments,
            fillColor = fillColor,
            outlineColor = outlineColor,
            outlineWidth = outlineWidth.toInt(),
            isFilled = isFilled,
            isStatic = isStatic,
            metadata = metadata,
        )
    }
}
