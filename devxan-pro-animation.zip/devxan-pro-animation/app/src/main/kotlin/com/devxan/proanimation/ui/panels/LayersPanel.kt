package com.devxan.proanimation.ui.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.devxan.proanimation.data.models.Layer
import com.devxan.proanimation.ui.theme.*
import com.devxan.proanimation.viewmodel.StudioViewModel

/**
 * Layers panel: shows the project's layer stack with visibility, lock, and
 * blend mode toggles. Clicking a layer makes it the active layer.
 */
@Composable
fun LayersPanel(vm: StudioViewModel) {
    val project = vm.project
    val activeLayer by vm.activeLayer.collectAsState()
    var expandedBlendLayer by remember { mutableStateOf<Layer?>(null) }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(4.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Layers", color = DarkPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.addVectorLayer() }, modifier = Modifier.size(20.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "Add", tint = DarkPrimary,
                        modifier = Modifier.size(14.dp))
                }
            }
        }
        itemsIndexed(project.layers) { _, layer ->
            LayerRow(
                layer = layer,
                isActive = activeLayer === layer,
                onClick = { vm.selectLayer(layer) },
                onToggleVisible = { vm.setLayerVisibility(layer, !layer.visible) },
                onDuplicate = { vm.duplicateLayer(layer) },
                onDelete = { vm.deleteLayer(layer) }
            )
        }
        item { Divider(color = DarkOutline, thickness = 0.5.dp) }
        item {
            Text("Add Layer:", color = DarkMuted, fontSize = 10.sp,
                modifier = Modifier.padding(4.dp), fontWeight = FontWeight.Bold)
        }
        item { MiniButton("Vector")   { vm.addVectorLayer() } }
        item { MiniButton("Group")    { vm.addGroupLayer() } }
        item { MiniButton("Switch")   { vm.addSwitchLayer() } }
        item { MiniButton("Particle") { vm.addParticleLayer() } }
    }
}

@Composable
private fun LayerRow(
    layer: Layer,
    isActive: Boolean,
    onClick: () -> Unit,
    onToggleVisible: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    val bg = if (isActive) DarkBackground else DarkSurfaceAlt
    Row(
        modifier = Modifier.fillMaxWidth().background(bg)
            .clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.DragHandle, contentDescription = null,
            tint = DarkMuted, modifier = Modifier.size(12.dp))
        Spacer(Modifier.width(4.dp))
        Icon(
            when (layer) {
                is Layer.Vector -> Icons.Default.Edit
                is Layer.Image -> Icons.Default.Image
                is Layer.Group -> Icons.Default.Folder
                is Layer.Switch -> Icons.Default.SwapHoriz
                is Layer.Particle -> Icons.Default.Grain
                is Layer.Mask -> Icons.Default.Visibility
            },
            contentDescription = null,
            tint = DarkPrimary,
            modifier = Modifier.size(14.dp)
        )
        Spacer(Modifier.width(6.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(layer.name, color = DarkOnBackground, fontSize = 11.sp)
            Text("${layer.blendMode.name} • ${(layer.opacity * 100).toInt()}%",
                color = DarkMuted, fontSize = 9.sp)
        }
        IconButton(onClick = onToggleVisible, modifier = Modifier.size(20.dp)) {
            Icon(
                if (layer.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                contentDescription = "Visibility",
                tint = if (layer.visible) DarkPrimary else DarkMuted,
                modifier = Modifier.size(14.dp)
            )
        }
        IconButton(onClick = onDuplicate, modifier = Modifier.size(20.dp)) {
            Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate",
                tint = DarkMuted, modifier = Modifier.size(14.dp))
        }
        IconButton(onClick = onDelete, modifier = Modifier.size(20.dp)) {
            Icon(Icons.Default.Delete, contentDescription = "Delete",
                tint = DarkError, modifier = Modifier.size(14.dp))
        }
    }
}

@Composable
private fun MiniButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text, fontSize = 10.sp)
    }
}
