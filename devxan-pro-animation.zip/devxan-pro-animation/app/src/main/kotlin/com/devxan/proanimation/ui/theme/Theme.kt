package com.devxan.proanimation.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.Typography
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// DEVXAN Pro Animation design tokens.
// A modern dark theme optimized for creative work: high-contrast canvas with
// accent cyan/yellow/pink for selection and timeline markers.

val DarkBackground  = Color(0xFF0F1115)
val DarkSurface     = Color(0xFF161922)
val DarkSurfaceAlt  = Color(0xFF1E2230)
val DarkPrimary     = Color(0xFF22D3EE)  // cyan-400
val DarkSecondary   = Color(0xFFFACC15)  // yellow-400
val DarkTertiary    = Color(0xFFF472B6)  // pink-400
val DarkOutline     = Color(0xFF334155)
val DarkOnBackground= Color(0xFFE2E8F0)
val DarkOnSurface   = Color(0xFFF1F5F9)
val DarkError       = Color(0xFFEF4444)
val DarkMuted       = Color(0xFF94A3B8)

val ColorScheme = darkColorScheme(
    primary = DarkPrimary,
    secondary = DarkSecondary,
    tertiary = DarkTertiary,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = DarkSurfaceAlt,
    onBackground = DarkOnBackground,
    onSurface = DarkOnSurface,
    error = DarkError,
    outline = DarkOutline
)

val Typography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        color = DarkOnBackground
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 18.sp,
        color = DarkOnBackground
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        color = DarkOnBackground
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        color = DarkOnBackground
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 11.sp,
        color = DarkMuted
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 10.sp,
        color = DarkOnBackground
    )
)
