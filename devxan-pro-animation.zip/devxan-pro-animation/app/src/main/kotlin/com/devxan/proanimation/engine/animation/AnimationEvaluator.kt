package com.devxan.proanimation.engine.animation

import com.devxan.proanimation.data.models.Keyframe
import com.devxan.proanimation.data.models.Timeline
import com.devxan.proanimation.data.models.Transform
import com.devxan.proanimation.data.models.Vec2
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * Per-frame animation evaluator that, given a Timeline + current frame,
 * produces per-target (layer / bone) sampled values.
 */
class AnimationEvaluator(val timeline: Timeline) {

    data class SampledBoneRotations(val targetId: String, val rotations: Map<Int, Float>)
    data class SampledTransform(val targetId: String, val transform: Transform)

    fun sampleBoneRotations(targetId: String, frame: Int): Map<Int, Float> {
        val v = timeline.sample(targetId, "bone_rotations", frame)
            as? Keyframe.KeyframeValue.BoneRotations ?: return emptyMap()
        return v.rotations
    }

    fun samplePosition(targetId: String, frame: Int): Vec2 {
        return (timeline.sample(targetId, "position", frame) as? Keyframe.KeyframeValue.Vec2V)?.v
            ?: Vec2.Zero
    }

    fun sampleScale(targetId: String, frame: Int): Float {
        return (timeline.sample(targetId, "scale", frame) as? Keyframe.KeyframeValue.FloatV)?.v
            ?: 1f
    }

    fun sampleRotation(targetId: String, frame: Int): Float {
        return (timeline.sample(targetId, "rotation", frame) as? Keyframe.KeyframeValue.FloatV)?.v
            ?: 0f
    }

    fun sampleOpacity(targetId: String, frame: Int): Float {
        return (timeline.sample(targetId, "opacity", frame) as? Keyframe.KeyframeValue.FloatV)?.v
            ?: 1f
    }

    fun sampleTransform(targetId: String, frame: Int): Transform = Transform(
        position = samplePosition(targetId, frame),
        rotation = sampleRotation(targetId, frame),
        scale = Vec2(sampleScale(targetId, frame), sampleScale(targetId, frame))
    )
}

/**
 * Onion skinning configuration. Past frames trail before the playhead,
 * future frames trail after, both with configurable tint & opacity.
 */
data class OnionSkinConfig(
    val enabled: Boolean = false,
    val pastFrames: Int = 3,
    val futureFrames: Int = 3,
    val pastTint: Int = 0xFFE5A4FF.toInt(),
    val futureTint: Int = 0xFF4FE3FF.toInt(),
    val baseOpacity: Float = 0.45f,
    val opacityFalloff: Float = 0.7f,  // multiplied per frame distance
)

/**
 * Playback controller. Drives the current frame forward in real time
 * synchronized with the audio engine, supports loop, ping-pong, scrub.
 */
class PlaybackController(
    var fps: Int = 24,
    var loopMode: LoopMode = LoopMode.Loop,
    var frameRange: IntRange = 0..120,
) {
    enum class LoopMode { Once, Loop, PingPong }

    private var currentFrame: Float = 0f
    private var playing = false
    private var direction = 1
    private var lastNanos = 0L

    fun play() {
        playing = true
        lastNanos = System.nanoTime()
    }

    fun pause() { playing = false }
    fun isPlaying(): Boolean = playing
    fun stop() { playing = false; currentFrame = frameRange.first.toFloat() }

    fun seek(frame: Int) {
        currentFrame = frame.toFloat().coerceIn(frameRange.first.toFloat(), frameRange.last.toFloat())
    }

    fun currentFrameInt(): Int = currentFrame.toInt()

    /** Advance playback by the time delta; returns the new integer frame. */
    fun tick(nowNanos: Long): Int {
        if (!playing) return currentFrame.toInt()
        if (lastNanos == 0L) { lastNanos = nowNanos; return currentFrame.toInt() }
        val dtSec = (nowNanos - lastNanos) / 1_000_000_000.0f
        lastNanos = nowNanos

        val frameAdvance = dtSec * fps * direction
        currentFrame += frameAdvance

        when (loopMode) {
            LoopMode.Once -> {
                if (currentFrame >= frameRange.last) {
                    currentFrame = frameRange.last.toFloat()
                    playing = false
                } else if (currentFrame < frameRange.first) {
                    currentFrame = frameRange.first.toFloat()
                }
            }
            LoopMode.Loop -> {
                if (currentFrame >= frameRange.last) {
                    currentFrame = frameRange.first + (currentFrame - frameRange.last)
                } else if (currentFrame < frameRange.first) {
                    currentFrame = frameRange.last - (frameRange.first - currentFrame)
                }
            }
            LoopMode.PingPong -> {
                if (currentFrame >= frameRange.last) {
                    currentFrame = frameRange.last.toFloat()
                    direction = -1
                } else if (currentFrame <= frameRange.first) {
                    currentFrame = frameRange.first.toFloat()
                    direction = 1
                }
            }
        }
        return currentFrame.toInt()
    }
}

/**
 * Cycle modifiers - applied to a sampled value to repeat / ping-pong it
 * outside its keyframe range.
 */
object CycleModifiers {
    fun apply(t: Float, mode: Mode, period: Float = 1f): Float = when (mode) {
        Mode.None -> t
        Mode.Repeat -> t % period
        Mode.PingPong -> {
            val p = t % (2f * period)
            if (p < period) p else 2f * period - p
        }
        Mode.Loop -> {
            // Same as Repeat
            t % period
        }
    }
    enum class Mode { None, Repeat, PingPong, Loop }
}

/**
 * Ease preset library (Bounce / Elastic / Exponential / Sine / etc.)
 * Each takes t in [0,1] and returns eased t.
 */
object EasePresets {
    fun linear(t: Float): Float = t

    fun sineIn(t: Float)  = 1f - cos((t * PI).toFloat() / 2f)
    fun sineOut(t: Float) = sin((t * PI).toFloat() / 2f)
    fun sineInOut(t: Float) = -(cos(PI.toFloat() * t).toFloat() - 1f) / 2f

    fun quadIn(t: Float) = t * t
    fun quadOut(t: Float) = 1f - (1f - t) * (1f - t)

    fun cubicIn(t: Float)  = t * t * t
    fun cubicOut(t: Float) = 1f - (1f - t) * (1f - t) * (1f - t)

    fun bounceOut(t: Float): Float {
        val n1 = 7.5625f; val d1 = 2.75f
        var tt = t
        return when {
            tt < 1f / d1   -> n1 * tt * tt
            tt < 2f / d1   -> { tt -= 1.5f / d1; n1 * tt * tt + 0.75f }
            tt < 2.5f / d1 -> { tt -= 2.25f / d1; n1 * tt * tt + 0.9375f }
            else           -> { tt -= 2.625f / d1; n1 * tt * tt + 0.984375f }
        }
    }

    fun elasticOut(t: Float): Float {
        val c4 = (2f * PI.toFloat()) / 3f
        if (t == 0f) return 0f
        if (t == 1f) return 1f
        return pow(2f, -10f * t) * sin((t * 10f - 0.75f) * c4) + 1f
    }

    fun expoOut(t: Float): Float = if (t == 0f) 0f else 1f - pow(2f, -10f * t)

    fun backOut(t: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        return 1f + c3 * pow(t - 1f, 3f) + c1 * pow(t - 1f, 2f)
    }

    fun preset(name: String): (Float) -> Float = when (name.lowercase()) {
        "linear" -> ::linear
        "sinein" -> ::sineIn
        "sineout" -> ::sineOut
        "sineinout" -> ::sineInOut
        "quadin" -> ::quadIn
        "quadout" -> ::quadOut
        "cubicin" -> ::cubicIn
        "cubicout" -> ::cubicOut
        "bounce" -> ::bounceOut
        "elastic" -> ::elasticOut
        "expoout" -> ::expoOut
        "backout" -> ::backOut
        else -> ::linear
    }
}

/**
 * F-Curve graph representation. A channel's keyframes produce a piecewise
 * function of frame -> value. The graph editor renders each channel as a
 * curve in 2D space (frame = X, value = Y).
 */
data class FCurve(
    val channelName: String,
    val targetId: String,
    val values: List<Pair<Int, Float>>,
    val color: Int = 0xFF22D3EE.toInt(),
) {
    fun sample(frame: Int): Float {
        if (values.isEmpty()) return 0f
        if (frame <= values.first().first) return values.first().second
        if (frame >= values.last().first) return values.last().second
        var lo = 0; var hi = values.size - 1
        while (lo + 1 < hi) {
            val mid = (lo + hi) / 2
            if (values[mid].first <= frame) lo = mid else hi = mid
        }
        val (f0, v0) = values[lo]; val (f1, v1) = values[hi]
        val t = (frame - f0).toFloat() / (f1 - f0).toFloat()
        return v0 + (v1 - v0) * EasePresets.cubicInOut(t)
    }
}
