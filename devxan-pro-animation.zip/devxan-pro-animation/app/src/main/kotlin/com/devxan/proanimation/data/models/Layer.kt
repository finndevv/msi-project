package com.devxan.proanimation.data.models

import com.devxan.proanimation.data.pivot.PivotFigureState
import com.devxan.proanimation.data.pivot.PivotProject
import com.devxan.proanimation.engine.ik.CcdIkSolver
import com.devxan.proanimation.engine.ik.FabrikSolver
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Layer types in the DEVXAN studio. Each layer has a transform, opacity,
 * blend mode, visibility, and a payload appropriate to its type.
 */
sealed class Layer {
    abstract var name: String
    abstract var transform: Transform
    abstract var opacity: Float
    abstract var visible: Boolean
    abstract var locked: Boolean
    abstract var blendMode: BlendMode
    abstract var depthZ: Float       // 3D depth for camera parallax
    abstract var zOrder: Int         // layer stack order

    enum class BlendMode {
        Normal, Multiply, Screen, Overlay, Add, Darken, Lighten, Difference
    }

    data class Vector(
        override var name: String = "Vector",
        override var transform: Transform = Transform.Identity,
        override var opacity: Float = 1f,
        override var visible: Boolean = true,
        override var locked: Boolean = false,
        override var blendMode: BlendMode = BlendMode.Normal,
        override var depthZ: Float = 0f,
        override var zOrder: Int = 0,
        val paths: MutableList<PathObject> = mutableListOf(),
        val skeletonId: String? = null,
    ) : Layer()

    data class Image(
        override var name: String = "Image",
        override var transform: Transform = Transform.Identity,
        override var opacity: Float = 1f,
        override var visible: Boolean = true,
        override var locked: Boolean = false,
        override var blendMode: BlendMode = BlendMode.Normal,
        override var depthZ: Float = 0f,
        override var zOrder: Int = 0,
        val bitmapRef: String = "",
        val sourceUri: String = "",
    ) : Layer()

    data class Group(
        override var name: String = "Group",
        override var transform: Transform = Transform.Identity,
        override var opacity: Float = 1f,
        override var visible: Boolean = true,
        override var locked: Boolean = false,
        override var blendMode: BlendMode = BlendMode.Normal,
        override var depthZ: Float = 0f,
        override var zOrder: Int = 0,
        val children: MutableList<Layer> = mutableListOf(),
    ) : Layer()

    /** Switch layer swaps between child layers based on the current frame. */
    data class Switch(
        override var name: String = "Switch",
        override var transform: Transform = Transform.Identity,
        override var opacity: Float = 1f,
        override var visible: Boolean = true,
        override var locked: Boolean = false,
        override var blendMode: BlendMode = BlendMode.Normal,
        override var depthZ: Float = 0f,
        override var zOrder: Int = 0,
        val children: MutableList<Layer> = mutableListOf(),
        val activeChildIndex: Int = 0,
    ) : Layer()

    data class Particle(
        override var name: String = "Particle",
        override var transform: Transform = Transform.Identity,
        override var opacity: Float = 1f,
        override var visible: Boolean = true,
        override var locked: Boolean = false,
        override var blendMode: BlendMode = BlendMode.Normal,
        override var depthZ: Float = 0f,
        override var zOrder: Int = 0,
        val config: com.devxan.proanimation.engine.physics.ParticleSystem.Config =
            com.devxan.proanimation.engine.physics.ParticleSystem.Config(),
    ) : Layer()

    data class Mask(
        override var name: String = "Mask",
        override var transform: Transform = Transform.Identity,
        override var opacity: Float = 1f,
        override var visible: Boolean = true,
        override var locked: Boolean = false,
        override var blendMode: BlendMode = BlendMode.Normal,
        override var depthZ: Float = 0f,
        override var zOrder: Int = 0,
        val maskPath: BezierPath = BezierPath(),
        val invertMask: Boolean = false,
        val featherRadius: Float = 4f,
    ) : Layer()
}

/**
 * A single vector path object on a vector layer with its own fill/stroke/effect.
 */
data class PathObject(
    val path: BezierPath = BezierPath(),
    val fill: FillStyle = FillStyle.None,
    val stroke: StrokeStyle = StrokeStyle(),
    val effects: EffectStyle = EffectStyle(),
    val name: String = "path",
    val id: String = java.util.UUID.randomUUID().toString(),
)

/**
 * Top-level DEVXAN project: layers, skeletons, audio tracks, FPS, frame range.
 */
class DevxanProject(
    var name: String = "Untitled Project",
    var fps: Int = 24,
    var frameCount: Int = 120,
    var canvasWidth: Int = 1920,
    var canvasHeight: Int = 1080,
    var layers: MutableList<Layer> = mutableListOf(),
    var skeletons: MutableMap<String, Skeleton> = mutableMapOf(),
    var figureLibrary: FigureLibrary = FigureLibrary(),
    var audioTracks: MutableList<AudioTrackRef> = mutableListOf(),
    var palette: MutableList<Int> = defaultPalette.toMutableList(),
    var postFx: PostFx = PostFx(),
    var environment: com.devxan.proanimation.engine.physics.Environment =
        com.devxan.proanimation.engine.physics.Environment(),
) {
    val timeline: Timeline = Timeline()

    companion object {
        val defaultPalette = listOf(
            0xFF0F1115.toInt(), 0xFF22D3EE.toInt(), 0xFFFACC15.toInt(),
            0xFFF472B6.toInt(), 0xFF34D399.toInt(), 0xFFA78BFA.toInt(),
            0xFFFB7185.toInt(), 0xFFFFFFFF.toInt(), 0xFF94A3B8.toInt(),
        )
    }

    fun totalDurationSeconds(): Float = frameCount.toFloat() / fps.toFloat()
}

data class PostFx(
    val brightness: Float = 1f,
    val contrast: Float = 1f,
    val hueShift: Float = 0f,
    val saturation: Float = 1f,
)

/**
 * Reference to an audio clip on the timeline. The actual PCM buffer lives in
 * the native audio engine; we just keep the metadata here.
 */
data class AudioTrackRef(
    var name: String,
    var startFrame: Int,
    var endFrame: Int,
    var volume: Float = 1f,
    var muted: Boolean = false,
    var loop: Boolean = false,
    var sourceUri: String,
    var nativeTrackId: Int = -1,
    var envelope: MutableList<VolumePoint> = mutableListOf(),
)

data class VolumePoint(val frame: Int, val volume: Float)

/**
 * Figure library entry: a parsed .stk figure or DEVXAN-native figure
 * available for spawning into any project.
 */
class FigureLibrary {
    private val entries = mutableListOf<Entry>()

    data class Entry(
        val id: String,
        val name: String,
        val source: String,         // "pivot_v3", "pivot_v5", "native"
        val pivotVersion: Int,
        val skeleton: Skeleton,
        val figure: com.devxan.proanimation.data.pivot.PivotFigure?,
        val thumbnailBytes: ByteArray? = null,
        val importedAt: Long = System.currentTimeMillis(),
    )

    fun add(entry: Entry) { entries.add(entry) }
    fun remove(id: String) { entries.removeAll { it.id == id } }
    fun all(): List<Entry> = entries.toList()
    fun find(id: String): Entry? = entries.firstOrNull { it.id == id }
    fun size(): Int = entries.size

    /**
     * Import a Pivot .stk file. Returns the added entry.
     */
    fun importStk(stream: java.io.InputStream, name: String): Entry {
        val result = com.devxan.proanimation.data.pivot.StkParser().parse(stream)
        val entry = Entry(
            id = java.util.UUID.randomUUID().toString(),
            name = name,
            source = "pivot_v${result.figure.version}",
            pivotVersion = result.figure.version,
            skeleton = result.skeleton,
            figure = result.figure,
        )
        add(entry)
        return entry
    }

    /**
     * Import a Pivot .piv project. Returns the figure entries added to the
     * library plus a fully constructed [DevxanProject] that mirrors the .piv
     * contents.
     */
    fun importPiv(
        stream: java.io.InputStream,
        into: DevxanProject,
        onError: (String) -> Unit = {}
    ): List<Entry> {
        val project = try {
            com.devxan.proanimation.data.pivot.PivParser().parse(stream)
        } catch (e: Exception) {
            onError("Failed to parse .piv: ${e.message}")
            return emptyList()
        }
        into.fps = 24
        into.frameCount = project.frames.size.coerceAtLeast(1)
        into.canvasWidth = project.frameWidth
        into.canvasHeight = project.frameHeight

        val addedEntries = ArrayList<Entry>()
        for ((idx, fig) in project.figures.withIndex()) {
            val skeleton = fig.toSkeleton()
            val entry = Entry(
                id = java.util.UUID.randomUUID().toString(),
                name = "${fig.name.ifEmpty { "figure_$idx" }}",
                source = "pivot_v${fig.version}",
                pivotVersion = fig.version,
                skeleton = skeleton,
                figure = fig,
            )
            add(entry)
            addedEntries.add(entry)
            into.skeletons[entry.id] = skeleton
            into.layers.add(Layer.Vector(
                name = entry.name,
                zOrder = idx,
                skeletonId = entry.id,
            ))
        }

        for ((frameIdx, frame) in project.frames.withIndex()) {
            for (state in frame.figureStates) {
                if (state.figureId < 0 || state.figureId >= addedEntries.size) continue
                val entry = addedEntries[state.figureId]
                val boneOverrides = HashMap<Int, Float>()
                val skel = entry.skeleton
                for ((boneIdx, _) in skel.bones.withIndex()) {
                    val segIdx = boneIdx - 1
                    if (segIdx >= 0 && segIdx < state.segmentRotations.size) {
                        boneOverrides[boneIdx] = state.segmentRotations[segIdx]
                    }
                }
                into.timeline.keyframeSet(entry.id, frameIdx, boneOverrides, state.translation, state.scale, state.rotation)
            }
        }
        return addedEntries
    }
}

/**
 * Keyframe entry on a single channel of a single target.
 */
data class Keyframe(
    val frame: Int,
    val value: KeyframeValue,
    val interpolation: Interpolation = Interpolation.Bezier(),
    val easing: Easing = Easing.EaseInOut,
) {
    sealed class Interpolation {
        object Linear : Interpolation()
        data class Bezier(val handleIn: Vec2 = Vec2(-0.3f, 0f), val handleOut: Vec2 = Vec2(0.3f, 0f)) : Interpolation()
        object Hold   : Interpolation()
        object Step   : Interpolation()
    }
    enum class Easing { Linear, EaseIn, EaseOut, EaseInOut, Bounce, Elastic, Exponential, Hold }

    sealed class KeyframeValue {
        data class FloatV(val v: Float) : KeyframeValue()
        data class Vec2V(val v: Vec2) : KeyframeValue()
        data class TransformV(val v: Transform) : KeyframeValue()
        data class BoneRotations(val rotations: Map<Int, Float>) : KeyframeValue()
    }
}

/**
 * Top-level timeline. Stores keyframes per (layerId / boneId / channel).
 */
class Timeline {
    /** Map: targetId -> list of channels, each channel has a sorted list of keyframes. */
    private val data = HashMap<String, MutableMap<String, MutableList<Keyframe>>>()

    fun keyframeSet(targetId: String, frame: Int, boneRotations: Map<Int, Float>,
                    translation: Vec2, scale: Float, rotation: Float) {
        val channels = data.getOrPut(targetId) { mutableMapOf() }
        val rotationsChannel = channels.getOrPut("bone_rotations") { mutableListOf() }
        replaceOrInsert(rotationsChannel, Keyframe(frame,
            Keyframe.KeyframeValue.BoneRotations(boneRotations),
            Keyframe.Interpolation.Bezier()))
        val posChannel = channels.getOrPut("position") { mutableListOf() }
        replaceOrInsert(posChannel, Keyframe(frame, Keyframe.KeyframeValue.Vec2V(translation)))
        val scaleChannel = channels.getOrPut("scale") { mutableListOf() }
        replaceOrInsert(scaleChannel, Keyframe(frame, Keyframe.KeyframeValue.FloatV(scale)))
        val rotChannel = channels.getOrPut("rotation") { mutableListOf() }
        replaceOrInsert(rotChannel, Keyframe(frame, Keyframe.KeyframeValue.FloatV(rotation)))
    }

    fun setKeyframe(targetId: String, channel: String, keyframe: Keyframe) {
        val channels = data.getOrPut(targetId) { mutableMapOf() }
        val list = channels.getOrPut(channel) { mutableListOf() }
        replaceOrInsert(list, keyframe)
    }

    fun removeKeyframe(targetId: String, channel: String, frame: Int) {
        data[targetId]?.get(channel)?.removeAll { it.frame == frame }
    }

    fun keyframes(targetId: String, channel: String): List<Keyframe> =
        data[targetId]?.get(channel)?.toList() ?: emptyList()

    fun targets(): Set<String> = data.keys
    fun channels(targetId: String): Set<String> = data[targetId]?.keys ?: emptySet()

    /**
     * Sample a channel at a given frame. Returns null if no keyframes exist
     * or if all keyframes are after [frame] (no past data).
     */
    fun sample(targetId: String, channel: String, frame: Int): Keyframe.KeyframeValue? {
        val list = data[targetId]?.get(channel) ?: return null
        if (list.isEmpty()) return null
        if (frame <= list.first().frame) return list.first().value
        if (frame >= list.last().frame) return list.last().value
        var lo = 0; var hi = list.size - 1
        while (lo + 1 < hi) {
            val mid = (lo + hi) / 2
            if (list[mid].frame <= frame) lo = mid else hi = mid
        }
        val k0 = list[lo]; val k1 = list[hi]
        val t = (frame - k0.frame).toFloat() / (k1.frame - k0.frame).toFloat()
        val eased = applyEasing(t, k1.easing)
        return interpolateValue(k0.value, k1.value, eased, k1.interpolation)
    }

    private fun replaceOrInsert(list: MutableList<Keyframe>, kf: Keyframe) {
        val idx = list.indexOfFirst { it.frame == kf.frame }
        if (idx >= 0) list[idx] = kf else {
            list.add(kf)
            list.sortBy { it.frame }
        }
    }

    private fun applyEasing(t: Float, easing: Keyframe.Easing): Float = when (easing) {
        Keyframe.Easing.Linear -> t
        Keyframe.Easing.EaseIn -> t * t * t
        Keyframe.Easing.EaseOut -> 1f - (1f - t) * (1f - t) * (1f - t)
        Keyframe.Easing.EaseInOut -> if (t < 0.5f) 4f * t * t * t else 1f - ((-2f * t + 2f).let { it * it * it }) / 2f
        Keyframe.Easing.Bounce -> {
            val n1 = 7.5625f; val d1 = 2.75f
            var tt = t
            when {
                tt < 1f / d1 -> n1 * tt * tt
                tt < 2f / d1 -> { tt -= 1.5f / d1; n1 * tt * tt + 0.75f }
                tt < 2.5f / d1 -> { tt -= 2.25f / d1; n1 * tt * tt + 0.9375f }
                else -> { tt -= 2.625f / d1; n1 * tt * tt + 0.984375f }
            }
        }
        Keyframe.Easing.Elastic -> {
            val c4 = (2f * PI.toFloat()) / 3f
            if (t == 0f) 0f else if (t == 1f) 1f
            else kotlin.math.pow(2f, -10f * t) * kotlin.math.sin((t * 10f - 0.75f) * c4) + 1f
        }
        Keyframe.Easing.Exponential -> {
            if (t == 0f) 0f else kotlin.math.pow(2f, 10f * (t - 1f))
        }
        Keyframe.Easing.Hold -> if (t < 1f) 0f else 1f
    }

    private fun interpolateValue(
        a: Keyframe.KeyframeValue, b: Keyframe.KeyframeValue, t: Float,
        interp: Keyframe.Interpolation
    ): Keyframe.KeyframeValue = when (interp) {
        Keyframe.Interpolation.Hold -> a
        Keyframe.Interpolation.Step -> if (t < 1f) a else b
        else -> when {
            a is Keyframe.KeyframeValue.FloatV && b is Keyframe.KeyframeValue.FloatV ->
                Keyframe.KeyframeValue.FloatV(a.v + (b.v - a.v) * t)
            a is Keyframe.KeyframeValue.Vec2V && b is Keyframe.KeyframeValue.Vec2V ->
                Keyframe.KeyframeValue.Vec2V(a.v.lerp(b.v, t))
            a is Keyframe.KeyframeValue.TransformV && b is Keyframe.KeyframeValue.TransformV ->
                Keyframe.KeyframeValue.TransformV(a.v.lerp(b.v, t))
            a is Keyframe.KeyframeValue.BoneRotations && b is Keyframe.KeyframeValue.BoneRotations -> {
                val out = HashMap<Int, Float>(a.rotations.size)
                for ((k, v0) in a.rotations) {
                    val v1 = b.rotations[k] ?: v0
                    out[k] = v0 + ((v1 - v0 + PI.toFloat()) % (2 * PI.toFloat()) - PI.toFloat()) * t
                }
                Keyframe.KeyframeValue.BoneRotations(out)
            }
            else -> a
        }
    }
}

/**
 * Frame-thumbnail cache (LRU) for the timeline scrubber.
 */
class ThumbnailCache(val capacity: Int = 60) {
    private val cache = object : LinkedHashMap<Int, ByteArray>(capacity, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Int, ByteArray>?): Boolean {
            return size > capacity
        }
    }
    @Synchronized fun get(frame: Int): ByteArray? = cache[frame]
    @Synchronized fun put(frame: Int, data: ByteArray) { cache[frame] = data }
    @Synchronized fun clear() { cache.clear() }
}
