package com.devxan.proanimation.data.pivot

import com.devxan.proanimation.data.models.Bone
import com.devxan.proanimation.data.models.Skeleton

/**
 * In-memory representation of a Pivot Animator figure (.stk).
 *
 * The Pivot format stores figures as:
 *  - A version header (2, 3, 4, or 5)
 *  - A figure-type definition describing the segments, node types
 *    (regular node, handle node, origin node, circle node, etc.)
 *  - Per-node: position in local figure space + per-node styles (color,
 *    thickness, fill, etc.)
 *  - Variable length restrictions / metadata blocks per version
 *
 * This representation keeps the imported figure as a list of nodes + segments,
 * and we expose a [toSkeleton] conversion to plug into DEVXAN's bone rig.
 */
data class PivotFigure(
    val version: Int,
    val name: String,
    val nodes: List<PivotNode>,
    val segments: List<PivotSegment>,
    val fillColor: Long,
    val outlineColor: Long,
    val outlineWidth: Int,
    val isFilled: Boolean,
    val isStatic: Boolean,
    val metadata: Map<String, String> = emptyMap(),
)

/**
 * Pivot node types:
 *  - Regular: a joint between segments (can be moved in animator)
 *  - Handle  : a non-joint endpoint that doesn't show on canvas
 *  - Origin  : the figure's local origin (one per figure)
 *  - Circle  : a node whose segment forms a closed circle
 *  - Polygon : a filled polygon vertex
 */
data class PivotNode(
    val type: NodeType,
    val x: Float,
    val y: Float,
    val isOrigin: Boolean,
) {
    enum class NodeType { Regular, Handle, Origin, Circle, PolygonVertex, StaticHandle }
}

/**
 * Pivot segment - a line between two node indices.
 */
data class PivotSegment(
    val nodeA: Int,
    val nodeB: Int,
    val color: Long,
    val thickness: Int,
    val isDashed: Boolean = false,
    val isCircle: Boolean = false,
)

/**
 * Convert a Pivot figure to a DEVXAN skeleton. Each segment becomes a bone;
 * shared nodes connect into a single hierarchy. The origin node becomes
 * the root bone's head.
 */
fun PivotFigure.toSkeleton(): Skeleton {
    val origin = nodes.firstOrNull { it.isOrigin } ?: nodes.firstOrNull()
    ?: return Skeleton(name = name)

    // Build bones from segments. Each segment -> one bone.
    val bones = mutableListOf<Bone>()
    val nodeToBoneIndex = mutableMapOf<Int, Int>()
    val originNodeIdx = nodes.indexOf(origin)

    // Root bone: zero-length anchor at origin position
    val rootBone = Bone(
        name = "${name}_root",
        head = origin,
        tail = origin,
        parentIndex = -1,
        constraints = com.devxan.proanimation.data.models.Constraints(lockRotation = true, lockTranslation = true)
    )
    bones.add(rootBone)

    for ((segIdx, seg) in segments.withIndex()) {
        val aNode = nodes.getOrNull(seg.nodeA)
        val bNode = nodes.getOrNull(seg.nodeB)
        if (aNode == null || bNode == null) continue

        val parentIdx = nodeToBoneIndex[seg.nodeA] ?: 0
        val boneIdx = bones.size
        val bone = Bone(
            name = "${name}_seg$segIdx",
            head = aNode,
            tail = bNode,
            parentIndex = parentIdx,
            color = 0xFF22D3EE.toInt(),
            constraints = com.devxan.proanimation.data.models.Constraints(
                angleMin = -Math.PI.toFloat(),
                angleMax =  Math.PI.toFloat(),
                strengthRadius = (bNode - aNode).length(),
            ),
        )
        bones.add(bone)
        if (seg.nodeA == originNodeIdx) {
            nodeToBoneIndex[seg.nodeB] = boneIdx
        } else if (seg.nodeB == originNodeIdx) {
            nodeToBoneIndex[seg.nodeA] = boneIdx
        } else {
            nodeToBoneIndex[seg.nodeB] = boneIdx
        }
    }
    return Skeleton(name = name, bones = bones.toMutableList())
}
