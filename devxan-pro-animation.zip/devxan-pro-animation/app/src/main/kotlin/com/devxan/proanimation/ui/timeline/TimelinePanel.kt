package com.devxan.proanimation.ui.timeline

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.devxan.proanimation.data.models.Keyframe
import com.devxan.proanimation.ui.theme.*
import com.devxan.proanimation.viewmodel.StudioViewModel

/**
 * Timeline panel: track list on the left, frame ruler + keyframe grid on
 * the right, with a graph editor tab for F-Curve editing.
 *
 * Multi-track timeline supporting frame-by-frame & tweening workflows.
 */
@Composable
fun TimelinePanel(vm: StudioViewModel, modifier: Modifier) {
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Timeline", "Graph Editor", "Audio")
    Column(modifier.background(DarkSurface)) {
        TabRow(selectedTabIndex = tab, containerColor = DarkSurfaceAlt) {
            tabs.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i },
                    text = { Text(t, fontSize = 10.sp) })
            }
        }
        when (tab) {
            0 -> TimelineTrackView(vm, Modifier.weight(1f))
            1 -> GraphEditor(vm, Modifier.weight(1f))
            2 -> AudioTimelineView(vm, Modifier.weight(1f))
        }
        TimelineRuler(vm, modifier = Modifier.fillMaxWidth().height(28.dp))
    }
}

@Composable
private fun TimelineTrackView(vm: StudioViewModel, modifier: Modifier) {
    val project = vm.project
    val currentFrame by vm.currentFrame.collectAsState()
    var scrubFrame by remember { mutableStateOf(currentFrame) }

    Row(modifier) {
        // Track list
        LazyColumn(modifier = Modifier.width(180.dp).fillMaxHeight()
            .background(DarkSurfaceAlt)) {
            items(project.layers) { layer ->
                TrackRow(layer.name, layer::class.simpleName ?: "Layer",
                    isVisible = layer.visible,
                    onToggleVisible = { vm.setLayerVisibility(layer, !layer.visible) })
            }
            item {
                Divider(color = DarkOutline, thickness = 0.5.dp)
                Text("Skeletons", color = DarkPrimary, fontSize = 10.sp,
                    modifier = Modifier.padding(4.dp), fontWeight = FontWeight.Bold)
            }
            items(project.skeletons.keys.toList()) { skId ->
                val sk = project.skeletons[skId]!!
                TrackRow(sk.name, "Skeleton", isVisible = true, onToggleVisible = {})
            }
            item {
                Divider(color = DarkOutline, thickness = 0.5.dp)
                Text("Audio Tracks", color = DarkPrimary, fontSize = 10.sp,
                    modifier = Modifier.padding(4.dp), fontWeight = FontWeight.Bold)
            }
            items(project.audioTracks) { track ->
                TrackRow(track.name, "Audio ${track.startFrame}-${track.endFrame}",
                    isVisible = !track.muted,
                    onToggleVisible = { vm.setAudioVolume(track, if (track.muted) 1f else 0f) })
            }
        }

        // Keyframe grid
        Box(modifier = Modifier.fillMaxSize().pointerInput(Unit) {
            detectTapGestures(onTap = { offset ->
                val frame = (offset.x / 8f).toInt().coerceIn(0, project.frameCount - 1)
                vm.setCurrentFrame(frame)
            })
            detectDragGestures(onDrag = { change, _ ->
                val frame = (change.position.x / 8f).toInt().coerceIn(0, project.frameCount - 1)
                vm.setCurrentFrame(frame)
            })
        }) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Background
                drawRect(DarkBackground.copy(alpha = 0.5f), Offset.Zero, size)
                // Per-row stripes
                val rowHeight = 24.dp.toPx()
                var y = 0f
                for (i in 0 until project.layers.size + 1) {
                    if (i % 2 == 0)
                        drawRect(DarkSurface.copy(alpha = 0.4f),
                            Offset(0f, y), Size(size.width, rowHeight))
                    y += rowHeight
                }
                // Frame markers every 10 frames
                val frameWidth = 8.dp.toPx()
                var x = 0f
                var frame = 0
                while (frame < project.frameCount) {
                    if (frame % 10 == 0) {
                        drawLine(DarkMuted.copy(alpha = 0.4f),
                            Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
                    }
                    x += frameWidth
                    frame++
                }
                // Keyframe diamonds
                val timeline = project.timeline
                for ((targetId, channels) in timeline.targets().associateWith { timeline.channels(it) }) {
                    val rowIdx = project.layers.indexOfFirst { it.name == targetId }.coerceAtLeast(0)
                    val rowY = rowIdx * rowHeight + rowHeight / 2
                    for (channel in channels) {
                        for (kf in timeline.keyframes(targetId, channel)) {
                            val kfx = kf.frame * frameWidth
                            drawKeyframeDiamond(kfx, rowY, DarkSecondary)
                        }
                    }
                }
                // Playhead
                val phX = currentFrame * frameWidth
                drawLine(DarkError, Offset(phX, 0f), Offset(phX, size.height), strokeWidth = 2f)
                drawRect(DarkError.copy(alpha = 0.2f),
                    Offset(phX - 2f, 0f), Size(4f, size.height))
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawKeyframeDiamond(
    cx: Float, cy: Float, color: Color
) {
    val s = 4f
    val path = Path().apply {
        moveTo(cx, cy - s)
        lineTo(cx + s, cy)
        lineTo(cx, cy + s)
        lineTo(cx - s, cy)
        close()
    }
    drawPath(path, color)
}

@Composable
private fun TrackRow(
    name: String,
    kind: String,
    isVisible: Boolean,
    onToggleVisible: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Icon(Icons.Default.DragHandle, contentDescription = null,
            tint = DarkMuted, modifier = Modifier.size(12.dp))
        Spacer(Modifier.width(4.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(name, color = DarkOnBackground, fontSize = 11.sp)
            Text(kind, color = DarkMuted, fontSize = 9.sp)
        }
        IconButton(onClick = onToggleVisible, modifier = Modifier.size(20.dp)) {
            Icon(
                if (isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                contentDescription = "Visibility",
                tint = if (isVisible) DarkPrimary else DarkMuted,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
fun TimelineRuler(vm: StudioViewModel, modifier: Modifier) {
    val project = vm.project
    val currentFrame by vm.currentFrame.collectAsState()
    Canvas(modifier = modifier.background(DarkSurfaceAlt)) {
        val frameWidth = 8.dp.toPx()
        var x = 0f
        var frame = 0
        while (frame < project.frameCount) {
            if (frame % 5 == 0) {
                val tickHeight = if (frame % 10 == 0) 12.dp.toPx() else 6.dp.toPx()
                drawLine(DarkOnBackground, Offset(x, 0f), Offset(x, tickHeight), strokeWidth = 1f)
                if (frame % 30 == 0) {
                    // Note: drawing text requires a drawWithCache + nativeCanvas; we
                    // render ticks only to keep the canvas lightweight.
                }
            }
            x += frameWidth
            frame++
        }
        // Playhead
        val phX = currentFrame * frameWidth
        drawRect(DarkError, Offset(phX - 1f, 0f), Size(3f, size.height))
    }
}

@Composable
private fun GraphEditor(vm: StudioViewModel, modifier: Modifier) {
    val project = vm.project
    val currentFrame by vm.currentFrame.collectAsState()
    var selectedChannel by remember { mutableStateOf<String?>(null) }

    Column(modifier.fillMaxSize()) {
        Row(modifier = Modifier.fillMaxWidth().padding(4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Channel:", color = DarkMuted, fontSize = 10.sp)
            Spacer(Modifier.width(8.dp))
            val channels = project.timeline.targets().flatMap { t ->
                project.timeline.channels(t).map { "$t.$it" }
            }
            if (channels.isNotEmpty()) {
                var expanded by remember { mutableStateOf(false) }
                Box {
                    TextButton(onClick = { expanded = true }) {
                        Text(selectedChannel ?: channels.first(), fontSize = 10.sp)
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        channels.forEach { c ->
                            DropdownMenuItem(text = { Text(c, fontSize = 10.sp) },
                                onClick = { selectedChannel = c; expanded = false })
                        }
                    }
                }
            }
        }
        Canvas(modifier = Modifier.fillMaxSize().background(DarkBackground)) {
            val w = size.width
            val h = size.height
            // Grid
            for (i in 0..10) {
                val x = w * i / 10
                drawLine(DarkMuted.copy(alpha = 0.2f), Offset(x, 0f), Offset(x, h), strokeWidth = 0.5f)
            }
            for (i in 0..6) {
                val y = h * i / 6
                drawLine(DarkMuted.copy(alpha = 0.2f), Offset(0f, y), Offset(w, y), strokeWidth = 0.5f)
            }
            // Zero line
            drawLine(DarkMuted.copy(alpha = 0.4f), Offset(0f, h / 2f), Offset(w, h / 2f), strokeWidth = 1f)

            // Draw F-curve for selected channel
            val channel = selectedChannel ?: return@Canvas
            val parts = channel.split(".", limit = 2)
            if (parts.size != 2) return@Canvas
            val targetId = parts[0]; val chName = parts[1]
            val kfs = project.timeline.keyframes(targetId, chName)
            if (kfs.size < 2) return@Canvas

            val minV = kfs.mapNotNull {
                (it.value as? Keyframe.KeyframeValue.FloatV)?.v
            }.minOrNull() ?: -1f
            val maxV = kfs.mapNotNull {
                (it.value as? Keyframe.KeyframeValue.FloatV)?.v
            }.maxOrNull() ?: 1f
            val range = (maxV - minV).coerceAtLeast(0.001f)
            val maxFrame = kfs.maxOf { it.frame }.coerceAtLeast(1)

            val path = Path()
            for ((idx, kf) in kfs.withIndex()) {
                val x = kf.frame.toFloat() / maxFrame * w
                val v = (kf.value as? Keyframe.KeyframeValue.FloatV)?.v ?: 0f
                val y = h - (v - minV) / range * h
                if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, DarkPrimary, style = Stroke(width = 2f))
            // Keyframe dots
            for (kf in kfs) {
                val x = kf.frame.toFloat() / maxFrame * w
                val v = (kf.value as? Keyframe.KeyframeValue.FloatV)?.v ?: 0f
                val y = h - (v - minV) / range * h
                drawCircle(DarkSecondary, radius = 4f, center = Offset(x, y))
            }
            // Playhead
            val phX = currentFrame.toFloat() / maxFrame * w
            drawLine(DarkError, Offset(phX, 0f), Offset(phX, h), strokeWidth = 1f)
        }
    }
}

@Composable
private fun AudioTimelineView(vm: StudioViewModel, modifier: Modifier) {
    val project = vm.project
    val currentFrame by vm.currentFrame.collectAsState()
    Column(modifier.fillMaxSize()) {
        Text("Audio Timeline", color = DarkPrimary, fontSize = 12.sp,
            modifier = Modifier.padding(8.dp), fontWeight = FontWeight.Bold)
        Canvas(modifier = Modifier.fillMaxSize().background(DarkBackground)) {
            val frameWidth = 8.dp.toPx()
            for ((idx, track) in project.audioTracks.withIndex()) {
                val y = idx * 40f + 10f
                // Audio track background
                drawRect(DarkSurfaceAlt, Offset(track.startFrame * frameWidth, y),
                    Size((track.endFrame - track.startFrame) * frameWidth, 30f))
                // Fake waveform
                val w = 256
                for (i in 0 until w) {
                    val height = 4 + (Math.sin(i * 0.13 + idx) * 10 + 10).toFloat()
                    val x = track.startFrame * frameWidth + i.toFloat() / w *
                            (track.endFrame - track.startFrame) * frameWidth
                    drawLine(DarkPrimary, Offset(x, y + 15 - height / 2),
                        Offset(x, y + 15 + height / 2), strokeWidth = 1f)
                }
            }
            // Playhead
            val phX = currentFrame * frameWidth
            drawLine(DarkError, Offset(phX, 0f), Offset(phX, size.height), strokeWidth = 1f)
        }
    }
}
