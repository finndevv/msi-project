package com.devxan.proanimation.ui.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.devxan.proanimation.ui.theme.*
import com.devxan.proanimation.viewmodel.StudioViewModel

/**
 * Figure library panel - shows all imported .stk / .piv figures and allows
 * spawning them into the active project.
 */
@Composable
fun FigureLibraryPanel(vm: StudioViewModel) {
    val project = vm.project
    var showSpawnDialog by remember {
        mutableStateOf<com.devxan.proanimation.data.models.FigureLibrary.Entry?>(null)
    }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(4.dp)) {
        item {
            Text("Figure Library", color = DarkPrimary, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
        }
        item {
            Text("${project.figureLibrary.size()} figures imported",
                color = DarkMuted, fontSize = 10.sp, modifier = Modifier.padding(4.dp))
        }
        items(project.figureLibrary.all()) { entry ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                    .clickable { showSpawnDialog = entry }
            ) {
                Column(Modifier.padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(36.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(DarkBackground)) {
                            Icon(Icons.Default.LinearScale, contentDescription = null,
                                tint = DarkPrimary, modifier = Modifier.size(24.dp).padding(2.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(entry.name, color = DarkOnBackground, fontSize = 11.sp,
                                fontWeight = FontWeight.Medium)
                            Text("${entry.source} • ${entry.skeleton.size} bones",
                                color = DarkMuted, fontSize = 9.sp)
                        }
                        Icon(Icons.Default.Add, contentDescription = "Spawn",
                            tint = DarkSecondary, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(8.dp))
            Text("Spawn a figure to add it to the active project as a new vector layer.",
                color = DarkMuted, fontSize = 9.sp, modifier = Modifier.padding(4.dp))
        }
    }

    showSpawnDialog?.let { entry ->
        AlertDialog(
            onDismissRequest = { showSpawnDialog = null },
            confirmButton = {
                TextButton(onClick = {
                    val layer = com.devxan.proanimation.data.models.Layer.Vector(
                        name = entry.name + "_spawn",
                        skeletonId = entry.id
                    )
                    project.layers.add(layer)
                    project.skeletons[entry.id] = entry.skeleton.copy()
                    showSpawnDialog = null
                }) { Text("Spawn") }
            },
            dismissButton = { TextButton(onClick = { showSpawnDialog = null }) { Text("Cancel") } },
            title = { Text("Spawn Figure: ${entry.name}") },
            text = {
                Column {
                    Text("Source: ${entry.source}", color = DarkMuted, fontSize = 11.sp)
                    Text("Bones: ${entry.skeleton.size}", color = DarkMuted, fontSize = 11.sp)
                    Text("Pivot version: ${entry.pivotVersion}", color = DarkMuted, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("A new Vector layer will be added with this skeleton attached.",
                        color = DarkOnBackground, fontSize = 11.sp)
                }
            }
        )
    }
}
