package com.devxan.proanimation.engine.render

import android.view.Surface

/**
 * Kotlin-side JNI bridge to the C++ OpenGL ES renderer.
 *
 * The native side manages its own EGL context + render thread; the Kotlin
 * side just submits render commands and synchronizes lifecycle.
 */
class NativeRenderer {

    private var handle: Long = 0L

    fun init(surface: Surface, width: Int, height: Int): Boolean {
        handle = nativeCreate(surface, width, height)
        return handle != 0L
    }

    fun destroy() {
        if (handle != 0L) nativeDestroy(handle)
        handle = 0L
    }

    fun resize(width: Int, height: Int) {
        if (handle != 0L) nativeResize(handle, width, height)
    }

    fun setPostFx(brightness: Float, contrast: Float, hue: Float, saturation: Float) {
        if (handle != 0L) nativeSetPostFx(handle, brightness, contrast, hue, saturation)
    }

    /** Render one frame. Called from the Compose render loop at the project FPS. */
    fun renderFrame() {
        if (handle != 0L) nativeRenderFrame(handle)
    }

    fun fps(): Int = if (handle != 0L) nativeFps(handle) else 0

    // Mesh pool management - mirrors Mesh objects in C++
    fun createMesh(): Int = nativeCreateMesh(handle)
    fun meshClear(meshId: Int) { nativeMeshClear(handle, meshId) }
    fun meshAddRect(meshId: Int, x0: Float, y0: Float, x1: Float, y1: Float,
                    r: Float, g: Float, b: Float, a: Float) {
        nativeMeshAddRect(handle, meshId, x0, y0, x1, y1, r, g, b, a)
    }
    fun meshAddEllipse(meshId: Int, cx: Float, cy: Float, rx: Float, ry: Float,
                       segments: Int, r: Float, g: Float, b: Float, a: Float) {
        nativeMeshAddEllipse(handle, meshId, cx, cy, rx, ry, segments, r, g, b, a)
    }
    fun meshUpload(meshId: Int, dynamic: Boolean) { nativeMeshUpload(handle, meshId, dynamic) }

    private external fun nativeCreate(surface: Surface, width: Int, height: Int): Long
    private external fun nativeDestroy(handle: Long)
    private external fun nativeResize(handle: Long, width: Int, height: Int)
    private external fun nativeSetPostFx(handle: Long, b: Float, c: Float, h: Float, s: Float)
    private external fun nativeRenderFrame(handle: Long)
    private external fun nativeFps(handle: Long): Int
    private external fun nativeCreateMesh(handle: Long): Int
    private external fun nativeMeshClear(handle: Long, meshId: Int)
    private external fun nativeMeshAddRect(handle: Long, meshId: Int,
                                          x0: Float, y0: Float, x1: Float, y1: Float,
                                          r: Float, g: Float, b: Float, a: Float)
    private external fun nativeMeshAddEllipse(handle: Long, meshId: Int,
                                              cx: Float, cy: Float, rx: Float, ry: Float, segments: Int,
                                              r: Float, g: Float, b: Float, a: Float)
    private external fun nativeMeshUpload(handle: Long, meshId: Int, dynamic: Boolean)

    companion object {
        init {
            System.loadLibrary("devxan_native")
        }
    }
}
