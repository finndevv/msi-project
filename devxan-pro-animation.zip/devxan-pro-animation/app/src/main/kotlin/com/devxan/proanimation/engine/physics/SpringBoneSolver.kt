package com.devxan.proanimation.engine.physics

import com.devxan.proanimation.data.models.BoneWorldPose
import com.devxan.proanimation.data.models.Dynamics
import com.devxan.proanimation.data.models.Skeleton
import com.devxan.proanimation.data.models.Vec2
import com.devxan.proanimation.data.models.ForwardKinematics
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI

/**
 * Spring-bone physics simulator: applies critically damped spring motion
 * to bones flagged with [Dynamics.enabled]=true.
 *
 * Bone tails lag behind their kinematically-driven heads by [spring]
 * stiffness and [damping]; [bounce] adds an additional elastic overshoot;
 * [gravity] applies a downward bias per bone.
 *
 * Implementation: each dynamic bone stores a "lag tail" position in world
 * space. Each frame we integrate the spring force pulling lag tail toward
 * the FK tail.
 */
class SpringBoneSolver(val skeleton: Skeleton) {

    private data class LagState(
        val boneIndex: Int,
        var pos: Vec2,
        var vel: Vec2,
        var initRot: Float,
    )

    private val states = mutableMapOf<Int, LagState>()
    private var lastTimeMs = -1L

    fun reset() {
        states.clear()
        val fk = ForwardKinematics(skeleton)
        val poses = fk.solve()
        for (i in 0 until skeleton.size) {
            val b = skeleton[i]
            if (b.dynamics.enabled) {
                states[i] = LagState(i, poses[i].tailWorld, Vec2.Zero, b.rotation)
            }
        }
    }

    /**
     * Step physics forward by dt seconds using [drivenRotations] as the
     * kinematically-driven bone rotations (e.g., from the timeline).
     * Returns the per-bone spring-applied rotation deltas.
     */
    fun step(drivenRotations: Map<Int, Float>, dt: Float): Map<Int, Float> {
        if (dt <= 0f) return emptyMap()

        val fk = ForwardKinematics(skeleton)
        val basePoses = fk.solve(drivenRotations)

        val result = drivenRotations.toMutableMap()
        for ((boneIdx, state) in states.toMap()) {
            val b = skeleton[boneIdx]
            val pose = basePoses[boneIdx]
            val target = pose.tailWorld
            // Spring force: F = -k * (pos - target) - c * vel
            val k = b.dynamics.spring * 60f      // stiffness
            val c = b.dynamics.damping * 8f      // damping
            val bounce = b.dynamics.bounce

            val delta = state.pos - target
            val force = Vec2(
                -k * delta.x - c * state.vel.x,
                -k * delta.y - c * state.vel.y
            )
            // Gravity bias
            val g = Vec2(0f, b.dynamics.gravity * b.dynamics.mass)

            state.vel = Vec2(
                state.vel.x + (force.x + g.x) * dt,
                state.vel.y + (force.y + g.y) * dt
            )
            state.pos = Vec2(
                state.pos.x + state.vel.x * dt * (1f + bounce),
                state.pos.y + state.vel.y * dt * (1f + bounce)
            )

            // Convert lag tail position to a rotation offset for this bone.
            // The bone rotates so its tail points at state.pos.
            val toTail = state.pos - pose.headWorld
            val fkToTail = target - pose.headWorld
            val ang1 = kotlin.math.atan2(toTail.y, toTail.x)
            val ang2 = kotlin.math.atan2(fkToTail.y, fkToTail.x)
            val deltaRot = ((ang1 - ang2 + PI).toFloat() % (2 * PI.toFloat())) - PI.toFloat()

            result[boneIdx] = (drivenRotations[boneIdx] ?: 0f) + deltaRot
        }
        return result
    }
}

/**
 * Particle simulator for snow/dust/rain/fire effects.
 * Verlet integration with gravity, wind, turbulence, lifespan, color phases.
 */
class ParticleSystem(
    val maxParticles: Int = 5000,
) {
    enum class Kind { Snow, Dust, Rain, Fire, Smoke }

    data class Particle(
        var x: Float, var y: Float,
        var vx: Float, var vy: Float,
        var age: Float,
        var lifespan: Float,
        var size: Float,
        var rotation: Float,
        var seed: Int,
    )

    data class Config(
        val kind: Kind = Kind.Snow,
        val emitterX: Float = 0f,
        val emitterY: Float = 0f,
        val emitterWidth: Float = 100f,
        val emitterRate: Float = 200f,     // particles per second
        val initialVelocity: Float = 80f,
        val spread: Float = 0.3f,           // radians around vertical
        val gravity: Float = 200f,
        val wind: Float = 0f,
        val turbulence: Float = 1f,
        val lifespan: Float = 5f,
        val minSize: Float = 2f,
        val maxSize: Float = 6f,
        val colorStart: Int = 0xFFFFFFFF.toInt(),
        val colorEnd: Int = 0x88FFFFFF.toInt(),
    )

    private val particles = ArrayList<Particle>(maxParticles)
    private var emitAccumulator = 0f
    private var seedCounter = 0

    val count: Int get() = particles.size

    fun emit(cfg: Config, dt: Float) {
        emitAccumulator += cfg.emitterRate * dt
        while (emitAccumulator >= 1f && particles.size < maxParticles) {
            emitAccumulator -= 1f
            val rng = java.util.Random((seedCounter++).toLong())
            val angle = when (cfg.kind) {
                Kind.Rain, Kind.Snow, Kind.Fire -> -PI.toFloat() / 2f + (rng.nextFloat() - 0.5f) * cfg.spread
                Kind.Dust, Kind.Smoke -> (rng.nextFloat() * 2f - 1f) * cfg.spread
            }
            val speed = cfg.initialVelocity * (0.7f + 0.6f * rng.nextFloat())
            val x = cfg.emitterX + (rng.nextFloat() - 0.5f) * cfg.emitterWidth
            val y = cfg.emitterY
            particles.add(Particle(
                x, y,
                vx = (java.lang.Math.cos(angle.toDouble())).toFloat() * speed,
                vy = (java.lang.Math.sin(angle.toDouble())).toFloat() * speed,
                age = 0f,
                lifespan = cfg.lifespan * (0.7f + 0.6f * rng.nextFloat()),
                size = cfg.minSize + (cfg.maxSize - cfg.minSize) * rng.nextFloat(),
                rotation = (rng.nextFloat() * 2f - 1f) * PI.toFloat(),
                seed = seedCounter,
            ))
        }
    }

    fun step(cfg: Config, dt: Float) {
        emit(cfg, dt)
        val it = particles.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.age += dt
            if (p.age >= p.lifespan) { it.remove(); continue }
            // Apply forces
            val t = (p.x * 0.013f + p.y * 0.017f + p.age * 0.5f)
            val turbX = kotlin.math.sin(t) * cfg.turbulence * 30f
            val turbY = kotlin.math.cos(t * 1.3f) * cfg.turbulence * 30f
            p.vx += (cfg.wind + turbX) * dt
            p.vy += cfg.gravity * dt + turbY * dt * 0.2f
            // Drag (for rain & snow, fire rises without drag)
            val drag = when (cfg.kind) {
                Kind.Rain, Kind.Snow -> 0.6f
                Kind.Fire, Kind.Smoke -> 0.85f
                Kind.Dust -> 0.4f
            }
            p.vx *= drag.pow(dt)
            p.vy *= drag.pow(dt)
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.rotation += dt * 1.5f
        }
    }

    fun snapshot(): List<Particle> = particles.toList()

    /** Render alpha for a particle based on age/lifespan. */
    fun particleAlpha(p: Particle): Float {
        val t = p.age / p.lifespan
        return when {
            t < 0.1f -> t / 0.1f
            t > 0.8f -> (1f - t) / 0.2f
            else -> 1f
        }
    }

    private fun Float.pow(e: Float): Float = Math.pow(this.toDouble(), e.toDouble()).toFloat()
}

/**
 * Global environment: gravity vector, wind, turbulence.
 */
data class Environment(
    val gravity: Vec2 = Vec2(0f, 9.81f * 100f),   // cm/s^2 visual scale
    val wind: Vec2 = Vec2.Zero,
    val turbulence: Float = 0.1f,
) {
    fun applyTo(v: Vec2, mass: Float, dt: Float): Vec2 {
        val ax = (gravity.x + wind.x) / mass
        val ay = (gravity.y + wind.y) / mass
        return Vec2(v.x + ax * dt, v.y + ay * dt)
    }
}
