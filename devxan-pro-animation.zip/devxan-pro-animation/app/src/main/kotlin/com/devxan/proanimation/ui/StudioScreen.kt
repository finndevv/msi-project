package com.devxan.proanimation.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.livedata.observeAsState
import java.io.File
import java.io.FileOutputStream
import com.devxan.proanimation.data.models.Layer
import com.devxan.proanimation.data.models.Vec2
import com.devxan.proanimation.ui.canvas.CanvasViewport
import com.devxan.proanimation.ui.panels.FigureLibraryPanel
import com.devxan.proanimation.ui.panels.LayersPanel
import com.devxan.proanimation.ui.panels.PropertiesPanel
import com.devxan.proanimation.ui.panels.ColorPanel
import com.devxan.proanimation.ui.timeline.TimelinePanel
import com.devxan.proanimation.ui.toolbar.Toolbar
import com.devxan.proanimation.viewmodel.StudioViewModel
import com.devxan.proanimation.ui.theme.*

/**
 * The main studio screen: top toolbar + side panels + canvas + bottom timeline.
 *
 * Layout (landscape):
 *   ┌──────────────────────────────────────────┐
 *   │ Toolbar (tools, undo, project actions)    │
 *   ├──────┬──────────────────────────┬────────┤
 *   │ Left │       Canvas Viewport    │ Right  │
 *   │ Pnl  │   (Compose canvas / GL)  │ Panel  │
 *   ├──────┴──────────────────────────┴────────┤
 *   │ Timeline + Graph Editor                  │
 *   └──────────────────────────────────────────┘
 *
 * In portrait, side panels collapse into a bottom sheet.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(intent: Intent?) {
    val vm: StudioViewModel = viewModel()
    val isPlaying by vm.isPlaying.collectAsState()
    val currentFrame by vm.currentFrame.collectAsState()
    val activeLayer by vm.activeLayer.collectAsState()
    val selectedTool by vm.selectedTool.collectAsState()
    val onionSkin by vm.onionSkin.collectAsState()
    val autoKey by vm.autoKeyframe.collectAsState()
    val fps by vm.fps.collectAsState()
    val palette by vm.palette.collectAsState()
    val status by vm.statusMessage.observeAsState("Ready")
    val issues by vm.issues.observeAsState(emptyList())
    val frameCount = vm.project.frameCount

    var showImportSheet by remember { mutableStateOf(false) }
    var showExportSheet by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    // Open file launcher
    val openStkLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { vm.importStk(it, "imported_figure") } }

    val openPivLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { vm.importPiv(it) } }

    val openProjectLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            try {
                val ctx = (vm.getApplication() as com.devxan.proanimation.DevxanApplication)
                val tempFile = File(ctx.cacheDir, "loaded.dxproj")
                ctx.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tempFile).use { input.copyTo(it) }
                }
                vm.loadProject(tempFile)
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    val createDocLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri: Uri? ->
        uri?.let {
            try {
                val ctx = (vm.getApplication() as com.devxan.proanimation.DevxanApplication)
                val tempFile = File(ctx.cacheDir, "save.dxproj")
                vm.saveProject(tempFile)
                ctx.contentResolver.openOutputStream(uri)?.use { out ->
                    tempFile.inputStream().use { it.copyTo(out) }
                }
            } catch (_: Exception) {}
        }
    }

    // Handle incoming VIEW intents (e.g., user tapped a .stk file)
    LaunchedEffect(intent) {
        intent?.data?.let { uri ->
            val name = uri.lastPathSegment ?: "imported"
            when {
                name.endsWith(".stk", ignoreCase = true) -> vm.importStk(uri, name)
                name.endsWith(".piv", ignoreCase = true) -> vm.importPiv(uri)
                name.endsWith(".dxproj", ignoreCase = true) -> {
                    val ctx = (vm.getApplication() as com.devxan.proanimation.DevxanApplication)
                    val tempFile = File(ctx.cacheDir, "intent.dxproj")
                    ctx.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(tempFile).use { input.copyTo(it) }
                    }
                    vm.loadProject(tempFile)
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DEVXAN PRO ANIMATION", fontWeight = FontWeight.Bold, color = DarkPrimary) },
                navigationIcon = {
                    IconButton(onClick = { showImportSheet = true }) {
                        Icon(Icons.Default.FolderOpen, contentDescription = "Open")
                    }
                },
                actions = {
                    IconButton(onClick = { vm.undo() }) {
                        Icon(Icons.Default.Undo, contentDescription = "Undo")
                    }
                    IconButton(onClick = { vm.redo() }) {
                        Icon(Icons.Default.Redo, contentDescription = "Redo")
                    }
                    IconButton(onClick = { createDocLauncher.launch(arrayOf("application/zip")) }) {
                        Icon(Icons.Default.Save, contentDescription = "Save")
                    }
                    IconButton(onClick = { showExportSheet = true }) {
                        Icon(Icons.Default.VideoFile, contentDescription = "Export")
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = DarkPrimary
                )
            )
        },
        bottomBar = {
            StatusBar(status = status, fps = fps, frame = currentFrame, total = frameCount, issues = issues)
        }
    ) { padding ->
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .background(DarkBackground)) {

            // Toolbar
            Toolbar(
                selectedTool = selectedTool,
                onToolSelected = { vm.setTool(it) },
                isPlaying = isPlaying,
                onPlayPause = { if (isPlaying) vm.pause() else vm.play() },
                onStop = { vm.stop() },
                onPrev = { vm.setCurrentFrame((currentFrame - 1).coerceAtLeast(0)) },
                onNext = { vm.setCurrentFrame((currentFrame + 1).coerceAtMost(frameCount - 1)) },
                onFirst = { vm.setCurrentFrame(0) },
                onLast = { vm.setCurrentFrame(frameCount - 1) },
                onionSkinEnabled = onionSkin.enabled,
                onToggleOnionSkin = { vm.toggleOnionSkin() },
                autoKeyframe = autoKey,
                onToggleAutoKeyframe = { vm.toggleAutoKeyframe() }
            )

            // Main work area: left panel | canvas | right panel
            Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                // Left panel: Layers + Figure library (tabbed)
                LeftPanelTabs(
                    modifier = Modifier.width(280.dp).fillMaxHeight().background(DarkSurface),
                    vm = vm
                )

                // Canvas viewport (the actual drawing surface)
                CanvasViewport(
                    vm = vm,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )

                // Right panel: Properties + Color
                RightPanelTabs(
                    modifier = Modifier.width(280.dp).fillMaxHeight().background(DarkSurface),
                    vm = vm,
                    palette = palette
                )
            }

            // Bottom: Timeline + Graph Editor
            TimelinePanel(vm = vm, modifier = Modifier.height(240.dp).fillMaxWidth())
        }
    }

    if (showImportSheet) {
        ModalBottomSheet(onDismissRequest = { showImportSheet = false }) {
            Column(modifier = Modifier.padding(16.dp)) {
                ListItem(
                    headlineContent = { Text("Import .stk Figure") },
                    modifier = Modifier.clickable {
                        showImportSheet = false
                        openStkLauncher.launch(arrayOf("*/*"))
                    }
                )
                ListItem(
                    headlineContent = { Text("Import .piv Animation") },
                    modifier = Modifier.clickable {
                        showImportSheet = false
                        openPivLauncher.launch(arrayOf("*/*"))
                    }
                )
                ListItem(
                    headlineContent = { Text("Open .dxproj Project") },
                    modifier = Modifier.clickable {
                        showImportSheet = false
                        openProjectLauncher.launch(arrayOf("application/zip", "*/*"))
                    }
                )
            }
        }
    }

    if (showExportSheet) {
        ModalBottomSheet(onDismissRequest = { showExportSheet = false }) {
            Column(modifier = Modifier.padding(16.dp)) {
                ListItem(
                    headlineContent = { Text("Export MP4 (H.264)") },
                    supportingContent = { Text("Hardware-encoded, up to 4K") }
                )
                ListItem(
                    headlineContent = { Text("Export PNG Sequence") },
                    supportingContent = { Text("Per-frame PNGs for compositing") }
                )
                ListItem(
                    headlineContent = { Text("Export Audio Mix") },
                    supportingContent = { Text("OPUS / MP3 / AAC") }
                )
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("OK") } },
            title = { Text("Project Settings") },
            text = {
                Column {
                    Text("FPS: ${vm.project.fps}")
                    Text("Resolution: ${vm.project.canvasWidth}×${vm.project.canvasHeight}")
                    Text("Frames: ${vm.project.frameCount}")
                    Text("Layers: ${vm.project.layers.size}")
                    Text("Skeletons: ${vm.project.skeletons.size}")
                    Text("Figures in library: ${vm.project.figureLibrary.size()}")
                }
            }
        )
    }
}

@Composable
private fun LeftPanelTabs(modifier: Modifier, vm: StudioViewModel) {
    var tab by remember { mutableStateOf(0) }
    val tabTitles = listOf("Layers", "Figures", "Actions")
    Column(modifier) {
        TabRow(selectedTabIndex = tab, containerColor = DarkSurfaceAlt) {
            tabTitles.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i },
                    text = { Text(t, fontSize = 11.sp) })
            }
        }
        when (tab) {
            0 -> LayersPanel(vm)
            1 -> FigureLibraryPanel(vm)
            2 -> ActionsPanel(vm)
        }
    }
}

@Composable
private fun RightPanelTabs(modifier: Modifier, vm: StudioViewModel, palette: List<Int>) {
    var tab by remember { mutableStateOf(0) }
    val tabTitles = listOf("Properties", "Color", "Audio")
    Column(modifier) {
        TabRow(selectedTabIndex = tab, containerColor = DarkSurfaceAlt) {
            tabTitles.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i },
                    text = { Text(t, fontSize = 11.sp) })
            }
        }
        when (tab) {
            0 -> PropertiesPanel(vm)
            1 -> ColorPanel(palette = palette)
            2 -> AudioPanel(vm)
        }
    }
}

@Composable
private fun ActionsPanel(vm: StudioViewModel) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        item { Text("Action Library", color = DarkPrimary, fontWeight = FontWeight.Bold) }
        item { Spacer(Modifier.height(8.dp)) }
        item { ActionButton("New Vector Layer") { vm.addVectorLayer() } }
        item { ActionButton("New Group") { vm.addGroupLayer() } }
        item { ActionButton("New Switch Layer") { vm.addSwitchLayer() } }
        item { ActionButton("New Particle Layer") { vm.addParticleLayer() } }
        item { Spacer(Modifier.height(8.dp)) }
        item { Text("Scripting", color = DarkPrimary, fontWeight = FontWeight.Bold) }
        item { ActionButton("Record Macro") { /* vm.macroEngine */ } }
        item { ActionButton("Play Macro") { } }
        item { Text("Recorded actions: ${vm.macroEngine.count()}", color = DarkMuted, fontSize = 10.sp) }
    }
}

@Composable
private fun ActionButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(text, fontSize = 12.sp)
    }
}

@Composable
private fun AudioPanel(vm: StudioViewModel) {
    val ctx = LocalContext.current
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.addAudioTrack(it, uri.lastPathSegment ?: "audio", 0) }
    }
    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        Text("Audio Tracks", color = DarkPrimary, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Button(onClick = { pickAudio.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text("+ Add Audio Track")
        }
        Spacer(Modifier.height(8.dp))
        vm.project.audioTracks.forEach { track ->
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                Column(Modifier.padding(8.dp)) {
                    Text(track.name, color = DarkOnBackground, fontSize = 12.sp)
                    Text("Frames ${track.startFrame}-${track.endFrame}",
                        color = DarkMuted, fontSize = 10.sp)
                    Slider(
                        value = track.volume,
                        onValueChange = { vm.setAudioVolume(track, it) },
                        valueRange = 0f..2f
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusBar(
    status: String,
    fps: Int,
    frame: Int,
    total: Int,
    issues: List<com.devxan.proanimation.engine.project.ProjectValidator.Issue>
) {
    Surface(color = DarkSurfaceAlt, tonalElevation = 2.dp) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(status, color = DarkMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))
            if (issues.isNotEmpty()) {
                val errors = issues.count { it.severity == com.devxan.proanimation.engine.project.ProjectValidator.Severity.Error }
                if (errors > 0) {
                    Icon(Icons.Default.Warning, contentDescription = "Issues", tint = DarkError,
                         modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("$errors errors", color = DarkError, fontSize = 11.sp)
                    Spacer(Modifier.width(12.dp))
                }
            }
            Text("Frame: $frame / $total", color = DarkOnBackground, fontSize = 11.sp)
            Spacer(Modifier.width(12.dp))
            Text("FPS: $fps", color = DarkPrimary, fontSize = 11.sp)
        }
    }
}
