package com.devxan.proanimation.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.devxan.proanimation.data.models.Layer
import com.devxan.proanimation.ui.theme.*
import com.devxan.proanimation.viewmodel.StudioViewModel

/**
 * Properties panel for the active layer: transform, opacity, blend mode,
 * stroke & fill style, bone rig properties.
 */
@Composable
fun PropertiesPanel(vm: StudioViewModel) {
    val activeLayer by vm.activeLayer.collectAsState()
    val layer = activeLayer ?: return
    val project = vm.project
    var expandedBlend by remember { mutableStateOf(false) }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        item {
            Text(layer.name, color = DarkPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(layer::class.simpleName ?: "Layer", color = DarkMuted, fontSize = 10.sp)
            Divider(modifier = Modifier.padding(vertical = 6.dp), color = DarkOutline)
        }
        item {
            Text("Opacity", color = DarkMuted, fontSize = 10.sp)
            Slider(
                value = layer.opacity,
                onValueChange = { vm.setLayerOpacity(layer, it) },
                valueRange = 0f..1f,
                modifier = Modifier.fillMaxWidth()
            )
            Text("${(layer.opacity * 100).toInt()}%", color = DarkOnBackground, fontSize = 10.sp)
        }
        item {
            Text("Blend Mode", color = DarkMuted, fontSize = 10.sp,
                modifier = Modifier.padding(top = 8.dp))
            Box {
                TextButton(onClick = { expandedBlend = true }) {
                    Text(layer.blendMode.name, color = DarkOnBackground, fontSize = 11.sp)
                }
                DropdownMenu(expanded = expandedBlend, onDismissRequest = { expandedBlend = false }) {
                    Layer.BlendMode.values().forEach { mode ->
                        DropdownMenuItem(
                            text = { Text(mode.name, fontSize = 11.sp) },
                            onClick = { vm.setLayerBlendMode(layer, mode); expandedBlend = false }
                        )
                    }
                }
            }
        }
        if (layer is Layer.Vector) {
            item {
                Divider(modifier = Modifier.padding(vertical = 6.dp), color = DarkOutline)
                Text("Paths", color = DarkSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("${layer.paths.size} path(s)", color = DarkMuted, fontSize = 10.sp)
            }
            item {
                Text("Skeleton: ${layer.skeletonId ?: "none"}",
                    color = DarkMuted, fontSize = 10.sp)
                if (layer.skeletonId != null) {
                    val sk = project.skeletons[layer.skeletonId]
                    if (sk != null) {
                        Text("Bones: ${sk.size}", color = DarkMuted, fontSize = 10.sp)
                    }
                }
            }
        }
        if (layer is Layer.Particle) {
            item {
                Divider(modifier = Modifier.padding(vertical = 6.dp), color = DarkOutline)
                Text("Particle Config", color = DarkSecondary, fontSize = 11.sp,
                    fontWeight = FontWeight.Bold)
                Text("Kind: ${layer.config.kind.name}", color = DarkMuted, fontSize = 10.sp)
                Text("Rate: ${layer.config.emitterRate}/s", color = DarkMuted, fontSize = 10.sp)
                Text("Lifespan: ${layer.config.lifespan}s", color = DarkMuted, fontSize = 10.sp)
                Text("Gravity: ${layer.config.gravity}", color = DarkMuted, fontSize = 10.sp)
                Text("Wind: ${layer.config.wind}", color = DarkMuted, fontSize = 10.sp)
                Text("Particles: ${vm.particleSystem.count}", color = DarkMuted, fontSize = 10.sp)
            }
        }
        item {
            Divider(modifier = Modifier.padding(vertical = 6.dp), color = DarkOutline)
            Text("Transform", color = DarkSecondary, fontSize = 11.sp,
                fontWeight = FontWeight.Bold)
            Text("Position: (${layer.transform.position.x}, ${layer.transform.position.y})",
                color = DarkMuted, fontSize = 10.sp)
            Text("Rotation: ${Math.toDegrees(layer.transform.rotation.toDouble()).toInt()}°",
                color = DarkMuted, fontSize = 10.sp)
            Text("Scale: (${layer.transform.scale.x}, ${layer.transform.scale.y})",
                color = DarkMuted, fontSize = 10.sp)
        }
    }
}
