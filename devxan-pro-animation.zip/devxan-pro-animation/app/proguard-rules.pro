# Keep Compose runtime & UI internals
-dontobfuscate
-keepattributes SourceFile,LineNumberTable,Signature,InnerClasses,EnclosingMethod

# Compose
-keep class androidx.compose.** { *; }
-keep class androidx.compose.runtime.** { *; }
-keep class androidx.compose.ui.** { *; }

# Kotlin metadata
-keep class kotlin.Metadata { *; }
-keepclassmembers class kotlin.Metadata { *; }

# NDK bridge - JNI entry points must be preserved
-keep class com.devxan.proanimation.engine.render.NativeRenderer { *; }
-keep class com.devxan.proanimation.engine.audio.NativeAudioEngine { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}

# Project / Pivot models used by serialization
-keep class com.devxan.proanimation.data.models.** { *; }
-keep class com.devxan.proanimation.data.pivot.** { *; }

# Room entities & DAOs
-keep class com.devxan.proanimation.data.project.** { *; }
