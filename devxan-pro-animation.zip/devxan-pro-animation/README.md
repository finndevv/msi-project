# DEVXAN PRO ANIMATION

A high-performance, professional Android 2D animation studio application
with native Pivot Animator (.stk/.piv) file format support, OpenGL ES
render pipeline, bone rigging with IK/FK solvers, multi-track timeline,
physics simulation, audio engine with lip-sync analysis, and MP4 export.

## Project Structure

```
devxan-pro-animation/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── cpp/                              # Native (NDK / C++)
        │   ├── CMakeLists.txt
        │   ├── devxan_jni.cpp                # JNI bridge
        │   ├── gl/
        │   │   ├── Shader.{h,cpp}             # GLSL ES 3.00 programs
        │   │   ├── Mesh.{h,cpp}               # VAO/VBO batching
        │   │   ├── Renderer.{h,cpp}          # EGL + FBO + post-FX
        │   │   └── PathTessellator.{h,cpp}   # Bezier → triangles
        │   └── audio/
        │       ├── AudioMixer.{h,cpp}        # Oboe low-latency mixer
        │       └── AudioDecoder.{h,cpp}      # FFT + phoneme classifier
        ├── kotlin/com/devxan/proanimation/
        │   ├── DevxanApplication.kt
        │   ├── MainActivity.kt
        │   ├── data/
        │   │   ├── models/
        │   │   │   ├── Vec2.kt               # Vec2, Transform, Mat4
        │   │   │   ├── BezierPath.kt         # Path, Color, fills, strokes
        │   │   │   ├── Bone.kt               # Bone, Skeleton, FK
        │   │   │   └── Layer.kt              # Layer, Project, Timeline
        │   │   └── pivot/
        │   │       ├── PivotBinaryReader.kt  # LE binary + zlib
        │   │       ├── PivotFigure.kt         # .stk → Skeleton conversion
        │   │       ├── StkParser.kt          # .stk v2/v3/v4/v5
        │   │       └── PivParser.kt          # .piv v2/v3/v4/v5
        │   ├── engine/
        │   │   ├── ik/
        │   │   │   └── CcdIkSolver.kt        # CCD + FABRIK + pole vector
        │   │   ├── bones/
        │   │   │   └── AutoRigger.kt         # LBS skinning + SmartWarp
        │   │   ├── physics/
        │   │   │   └── SpringBoneSolver.kt  # Spring bones + particles
        │   │   ├── vector/
        │   │   │   └── PathBooleanOps.kt     # Union/sub/intersect + Primitives
        │   │   ├── animation/
        │   │   │   └── AnimationEvaluator.kt # Easing, F-Curves, OnionSkin
        │   │   ├── undo/
        │   │   │   └── UndoStack.kt          # Command stack + PropertyCmd
        │   │   ├── audio/
        │   │   │   └── AudioEngine.kt        # Oboe JNI + MediaCodec decode
        │   │   ├── render/
        │   │   │   └── NativeRenderer.kt     # OpenGL ES bridge
        │   │   ├── project/
        │   │   │   └── DxprojSerializer.kt   # .dxproj ZIP bundle + autosave
        │   │   └── export/
        │   │       └── Mp4Exporter.kt        # MediaCodec H.264 + macros
        │   ├── viewmodel/
        │   │   └── StudioViewModel.kt        # MVVM center
        │   └── ui/
        │       ├── StudioScreen.kt           # Main scaffold
        │       ├── theme/Theme.kt
        │       ├── canvas/CanvasViewport.kt  # Compose Canvas viewport
        │       ├── timeline/TimelinePanel.kt  # Tracks + graph editor
        │       ├── toolbar/Toolbar.kt        # Tool palette + playback
        │       └── panels/
        │           ├── LayersPanel.kt
        │           ├── FigureLibraryPanel.kt
        │           ├── PropertiesPanel.kt
        │           └── ColorPanel.kt
        └── res/
            ├── values/{strings,colors,themes}.xml
            ├── drawable/ic_launcher_foreground.xml
            ├── mipmap-{m,h,xh,xxh,xxxh}dpi/ic_launcher*.xml
            └── xml/file_provider_paths.xml
```

## Build Requirements

- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17
- Android SDK Platform 34
- Android NDK 26.1.10909125
- CMake 3.22.1 (installed via SDK Manager)
- Gradle 8.9 (wrapper included)

## How to Build

1. Copy this project into your development machine.
2. Open the root folder in Android Studio: **File → Open** → select the
   `devxan-pro-animation` directory.
3. Android Studio will prompt to install the NDK / CMake if missing -
   accept the prompt.
4. After Gradle sync finishes, press **Run ▶** to deploy to a connected
   device or emulator running Android 8.0 (API 26) or newer.
5. For a release APK: `./gradlew assembleRelease` (output:
   `app/build/outputs/apk/release/app-release.apk`).

## Architecture

The app follows an MVVM + Clean Architecture pattern:

- **data layer**: pure data classes for layers, bones, paths, keyframes,
  and the Pivot binary format parsers.
- **engine layer**: stateless algorithmic modules (IK solvers, physics,
  boolean ops, animation evaluator, audio engine).
- **viewmodel**: a single `StudioViewModel` that orchestrates the engine
  and exposes observable state via `StateFlow` and `LiveData`.
- **ui layer**: Jetpack Compose screens (`StudioScreen`), toolbars, panels,
  timeline, and a Canvas-based viewport.

The native (C++) side handles performance-critical paths: the OpenGL ES
3.0 render pipeline with FBO-based post-processing, mesh batching, and the
Oboe low-latency audio mixer. JNI bridges all relevant calls to Kotlin.

## Pivot Format Support

The `StkParser` and `PivParser` classes handle all four Pivot versions:

| Version | Compression | Node Encoding | String Encoding |
|---------|-------------|---------------|-----------------|
| v2      | none        | Int32 x/y     | null-terminated ASCII |
| v3      | none        | Int32 x/y     | null-terminated ASCII |
| v4      | zlib        | Float32 x/y   | length-prefixed UTF-8 |
| v5      | zlib        | Float32 x/y   | length-prefixed UTF-8 + metadata |

Imported figures are converted into DEVXAN's internal `Skeleton` (one bone
per Pivot segment), with the origin node becoming the root anchor bone.
Imported .piv animations populate the project timeline with per-frame
keyframes for bone rotations, position, scale, and rotation.

## Implemented Features

| Feature Group | Implemented |
|---|---|
| .stk/.piv import (v2-v5) | ✅ All 4 versions, with zlib decompression |
| Bone rigging + FK/IK | ✅ CCD + FABRIK + pole vectors + constraints |
| Vector drawing tools | ✅ Pen, brush, primitives, node edit |
| Path boolean ops | ✅ Union, subtract, intersect, exclude |
| Layer types | ✅ Vector, Image, Group, Switch, Particle, Mask |
| Blend modes | ✅ Normal, Multiply, Screen, Overlay, Add, Darken, Lighten, Difference |
| Timeline + graph editor | ✅ Multi-track, F-Curves, keyframe batch ops |
| Interpolation | ✅ Linear, Bezier, Hold, Step + 8 easing presets |
| Onion skinning | ✅ Past + future with falloff |
| Audio engine | ✅ Oboe mixer, OPUS/MP3/AAC decode via MediaCodec |
| Lip-sync | ✅ FFT + phoneme classifier (C++) |
| Physics | ✅ Spring bones + particles + env forces |
| Project serialization | ✅ .dxproj ZIP bundle + AES encryption + autosave |
| MP4 export | ✅ MediaCodec H.264 + MediaMuxer, up to 4K |
| PNG sequence export | ✅ Frame-by-frame PNG output |
| Undo/redo | ✅ Generic command stack with merge |
| Macro/scripting | ✅ Action recording + JSON serialization |

## Open File Types

The app registers intent filters for:
- `.stk` - Pivot figure files
- `.piv` - Pivot animation projects
- `.dxproj` - DEVXAN project bundles

Tap any file of these types from a file manager to open it directly
in DEVXAN Pro Animation.
